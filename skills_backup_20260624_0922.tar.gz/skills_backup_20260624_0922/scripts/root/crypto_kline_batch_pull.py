#!/usr/bin/env python3
"""
批量拉取历史 K 线全量数据（过去一年）
逐步翻页拉取，不限制 100 根上限
"""
import sqlite3, json, subprocess, time
from datetime import datetime, timezone, timedelta

DB_PATH = "/root/crypto_kline.db"
OKX_BASE = "https://www.okx.com/api/v5"

SYMBOLS = ["BTC-USDT-SWAP", "ETH-USDT-SWAP"]

# 各时间框架拉取目标（约一年数据量）
PULL_PLAN = {
    # tf: [目标K线数, 一年理论数, 每次拉取数]
    "1m":  [5000,   525600, 100],
    "5m":  [10000,  105120, 100],
    "30m": [5000,   17520,  100],
    "1H":  [3000,   8760,   100],
    "4H":  [1500,   2190,   100],
    "1D":  [365,    365,    100],
    "1W":  [52,     52,     100, "1W"],
    "1mo": [12,     12,     100, "1M"],
}

BJT = timezone(timedelta(hours=8))


def okx_get(endpoint):
    url = f"{OKX_BASE}{endpoint}"
    for attempt in range(3):
        r = subprocess.run(
            ["curl", "-s", "--max-time", "15", url],
            capture_output=True, text=True
        )
        try:
            data = json.loads(r.stdout)
            return data
        except json.JSONDecodeError:
            print(f"  ⚠️ retry {attempt+1}...")
            time.sleep(0.5)
    return {"code": "-1", "msg": "JSON decode failed"}


def pull_all(symbol, tf, target_count, bar_param=None):
    """翻页拉取直到达到目标数或数据到尽头"""
    table = f"kline_{tf}"
    bar = bar_param if bar_param else tf
    conn = sqlite3.connect(DB_PATH)
    
    total = 0
    after = ""
    batch = 0
    
    while total < target_count:
        batch += 1
        url = f"/market/candles?instId={symbol}&bar={bar}&limit=100"
        if after:
            url += f"&after={after}"
        
        resp = okx_get(url)
        if resp.get("code") != "0" or "data" not in resp:
            print(f"  ⚠️ {tf} batch #{batch}: {resp.get('msg', 'unknown')}")
            break
        
        candles = resp["data"]
        if not candles:
            print(f"  ⚠️ {tf} batch #{batch}: empty")
            break
        
        inserted = 0
        for c in candles:
            ts = int(c[0])
            o, h, l, clo, vol = (float(c[1]), float(c[2]), float(c[3]),
                                float(c[4]), float(c[5]))
            confirm = int(c[8]) if len(c) > 8 else 1
            
            try:
                conn.execute(
                    f"""INSERT OR IGNORE INTO {table}
                        (symbol, ts, open, high, low, close, volume, confirm)
                        VALUES (?,?,?,?,?,?,?,?)""",
                    (symbol, ts, o, h, l, clo, vol, confirm)
                )
                if conn.execute("SELECT changes()").fetchone()[0] > 0:
                    inserted += 1
            except Exception as e:
                pass
        
        conn.commit()
        total += inserted
        
        if batch % 5 == 0:
            print(f"    batch #{batch}: +{inserted} (total {total}/{target_count})")
        
        if len(candles) < 100:
            break  # 数据到尽头
        
        # 下一页游标：最后一个蜡烛的时间戳 - 1ms
        after = str(int(candles[-1][0]) - 1)
        time.sleep(0.15)  # 温和控速
    
    conn.close()
    return total


def verify_table(conn, table, symbol):
    """验证数据正确性"""
    # 1. 检查时间戳是否严格递增
    rows = conn.execute(
        f"SELECT ts FROM {table} WHERE symbol = ? ORDER BY ts",
        (symbol,)
    ).fetchall()
    
    tss = [r[0] for r in rows]
    ascending = all(tss[i] < tss[i+1] for i in range(len(tss)-1)) if len(tss) > 1 else True
    
    # 2. 检查是否有重复
    dup_check = conn.execute(
        f"SELECT ts, COUNT(*) FROM {table} WHERE symbol = ? GROUP BY ts HAVING COUNT(*) > 1",
        (symbol,)
    ).fetchall()
    
    # 3. 检查 OHLC 是否合理
    anomalies = conn.execute(
        f"""SELECT COUNT(*) FROM {table}
            WHERE symbol = ?
            AND (high < low OR high < open OR high < close OR low > open OR low > close)""",
        (symbol,)
    ).fetchone()[0]
    
    return {
        "count": len(tss),
        "ascending": ascending,
        "duplicates": len(dup_check),
        "ohlc_anomalies": anomalies,
        "first_ts": datetime.fromtimestamp(tss[0]/1000, BJT).strftime("%Y-%m-%d %H:%M") if tss else "N/A",
        "last_ts": datetime.fromtimestamp(tss[-1]/1000, BJT).strftime("%Y-%m-%d %H:%M") if tss else "N/A",
    }


def main():
    print("=" * 70)
    print("📡 批量拉取历史 K 线数据（约一年）")
    print(f"  数据库: {DB_PATH}")
    print(f"  开始时间: {datetime.now(BJT).strftime('%Y-%m-%d %H:%M:%S BJT')}")
    print("=" * 70)
    
    grand_total = 0
    
    for symbol in SYMBOLS:
        print(f"\n{'#'*70}")
        print(f"# {symbol}")
        print(f"{'#'*70}")
        
        for tf, (target, _, _, *rest) in PULL_PLAN.items():
            table = f"kline_{tf}"
            bar_param = rest[0] if rest else None
            
            # 先检查现有数据量
            conn = sqlite3.connect(DB_PATH)
            existing = conn.execute(
                f"SELECT COUNT(*) FROM {table} WHERE symbol = ?", (symbol,)
            ).fetchone()[0]
            conn.close()
            
            need = max(0, target - existing)
            if need == 0:
                print(f"\n  {tf}: 已有 {existing} 根，跳过 (目标 {target})")
                continue
            
            print(f"\n  {tf}: 现有 {existing}，需补充 {need} 根 (目标 {target})...")
            start = time.time()
            added = pull_all(symbol, tf, target, bar_param)
            elapsed = time.time() - start
            print(f"  ✅ {tf}: +{added} 根，{elapsed:.1f}s")
            grand_total += added
    
    # === 验证 ===
    print(f"\n{'='*70}")
    print("🔍 数据验证")
    print(f"{'='*70}")
    
    conn = sqlite3.connect(DB_PATH)
    all_ok = True
    
    for symbol in SYMBOLS:
        print(f"\n  {symbol}:")
        for tf in PULL_PLAN:
            table = f"kline_{tf}"
            v = verify_table(conn, table, symbol)
            status = "✅" if (v["ascending"] and v["duplicates"] == 0 and v["ohlc_anomalies"] == 0) else "⚠️"
            if status == "⚠️":
                all_ok = False
            print(f"    {status} {tf}: {v['count']} 根 | {v['first_ts']} ~ {v['last_ts']} | "
                  f"递增:{'Y' if v['ascending'] else 'N'} 重复:{v['duplicates']} 异常:{v['ohlc_anomalies']}")
    
    conn.close()
    
    print(f"\n{'='*70}")
    print(f"📊 总计新增: {grand_total} 根 K 线")
    print(f"   验证结果: {'✅ 全部通过' if all_ok else '⚠️ 存在异常'}")
    db_size = subprocess.run(["du", "-h", DB_PATH], capture_output=True, text=True).stdout.split()[0]
    print(f"   数据库大小: {db_size}")
    print(f"   完成时间: {datetime.now(BJT).strftime('%Y-%m-%d %H:%M:%S BJT')}")
    print("=" * 70)


if __name__ == "__main__":
    main()
