#!/usr/bin/env python3
"""
K线定时拉取 + 验证脚本
用法: python3 pull_verify.py <timeframe>   # 如 1D, 1W, 1mo
"""
import sqlite3, json, subprocess, time, sys
from datetime import datetime, timezone, timedelta

DB_DIR = "/root"
OKX = "https://www.okx.com/api/v5"
BJT = timezone(timedelta(hours=8))

# 内部 key → OKX API bar 参数
BAR_MAP = {"1m":"1m","5m":"5m","30m":"30m","1H":"1H","4H":"4H",
           "1D":"1D","1W":"1W","1mo":"1M","3M":"3M"}
SYMBOLS = ["BTC-USDT-SWAP", "ETH-USDT-SWAP"]

tf = sys.argv[1] if len(sys.argv) > 1 else "1D"
bar = BAR_MAP.get(tf, tf)

def okx_get(path):
    r = subprocess.run(["curl","-s","--max-time","10","-H","User-Agent: Mozilla/5.0",f"{OKX}{path}"],
                       capture_output=True, text=True)
    return json.loads(r.stdout)

def verify(conn, table):
    """验证连续性、去重、OHLC 正确"""
    rows = conn.execute(f"SELECT ts,open,high,low,close FROM {table} ORDER BY ts").fetchall()
    issues = []
    
    if not rows:
        return ["空表"]
    
    # 1. 重复检查
    tss = [r[0] for r in rows]
    if len(tss) != len(set(tss)):
        issues.append("存在重复时间戳")
    
    # 2. OHLC 合理性
    ohlc_bad = 0
    for r in rows:
        ts,o,h,l,c = r
        if h < l or h < o or h < c or l > o or l > c:
            ohlc_bad += 1
    if ohlc_bad > 0:
        issues.append(f"{ohlc_bad}根K线OHLC异常")
    
    # 3. 连续性（检查时间间隔是否合理，允许1根缺失）
    gaps = 0
    for i in range(1, len(tss)):
        diff = tss[i] - tss[i-1]
        gaps += 1 if diff != expected_interval(tf) else 0
    if gaps > 0:
        issues.append(f"{gaps}处时间不连续")
    
    return issues if issues else ["OK"]

def expected_interval(tf):
    """期望的时间间隔(ms)"""
    m = {"1m":60000,"5m":300000,"30m":1800000,"1H":3600000,
         "4H":14400000,"1D":86400000,"1W":604800000,"1mo":0}  # 月线间隔不固定
    return m.get(tf, 0)

now = datetime.now(BJT).strftime("%Y-%m-%d %H:%M:%S BJT")
print(f"📡 {tf} 定时拉取 | {now}")

for sym in SYMBOLS:
    pfx = "BTC" if "BTC" in sym else "ETH"
    db = f"{DB_DIR}/{pfx}_Kline.db"
    conn = sqlite3.connect(db)
    
    # 确保表存在
    conn.execute(f"""CREATE TABLE IF NOT EXISTS kline_{tf} (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        ts INTEGER NOT NULL, open REAL, high REAL, low REAL,
        close REAL, volume REAL, confirm INTEGER DEFAULT 0, UNIQUE(ts))""")
    conn.commit()
    
    # 获取最新时间戳
    last = conn.execute(f"SELECT MAX(ts) FROM kline_{tf}").fetchone()[0]
    
    # 拉取最新数据
    added = 0
    after = ""
    while True:
        u = f"/market/candles?instId={sym}&bar={bar}&limit=100"
        if after: u += f"&after={after}"
        r = okx_get(u)
        if r.get("code") != "0" or not r.get("data"): break
        
        candles = r["data"]
        batch_added = 0
        for c in candles:
            ts = int(c[0])
            if last and ts <= last: continue
            o,h,l,cl,vol = float(c[1]),float(c[2]),float(c[3]),float(c[4]),float(c[5])
            cf = int(c[8]) if len(c) > 8 else 1
            conn.execute(f"INSERT OR IGNORE INTO kline_{tf} VALUES (NULL,?,?,?,?,?,?,?)",
                        (ts,o,h,l,cl,vol,cf))
            if conn.execute("SELECT changes()").fetchone()[0] > 0:
                batch_added += 1
        
        conn.commit()
        added += batch_added
        
        if len(candles) < 100 or not after:  # 首轮后如果全是旧数据就停
            if last and batch_added == 0:
                break
        if batch_added == 0 and after:
            break
        
        after = str(int(candles[-1][0]) - 1)
        time.sleep(0.1)
    
    # 验证
    total = conn.execute(f"SELECT COUNT(*) FROM kline_{tf}").fetchone()[0]
    v = verify(conn, f"kline_{tf}")
    
    first = conn.execute(f"SELECT MIN(ts) FROM kline_{tf}").fetchone()[0]
    last_ts = conn.execute(f"SELECT MAX(ts) FROM kline_{tf}").fetchone()[0]
    a = time.strftime("%Y-%m-%d", time.gmtime(first/1000)) if first else "N/A"
    b = time.strftime("%Y-%m-%d", time.gmtime(last_ts/1000)) if last_ts else "N/A"
    
    status = "✅" if v == ["OK"] else "⚠️"
    print(f"  {pfx}: +{added} | 总计{total}根 ({a}~{b}) | {status} {'; '.join(v)}")
    conn.close()

print("完成")
