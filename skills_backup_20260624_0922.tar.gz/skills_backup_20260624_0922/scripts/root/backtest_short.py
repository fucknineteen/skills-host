#!/usr/bin/env python3
"""
Short-term BTC strategy backtester v4 — final optimization pass.
"""
import sqlite3, numpy as np
from datetime import datetime, timezone
from collections import defaultdict

DB = "/root/.hermes/trade_review/okx_klines.db"
FEE = 0.0014

def load_klines(timeframe):
    conn = sqlite3.connect(DB)
    rows = conn.execute(
        "SELECT ts, open, high, low, close, volume FROM klines WHERE coin='BTC' AND timeframe=? ORDER BY ts ASC",
        (timeframe,)
    ).fetchall()
    conn.close()
    return (np.array([r[0] for r in rows]),
            np.array([r[1] for r in rows], dtype=float),
            np.array([r[2] for r in rows], dtype=float),
            np.array([r[3] for r in rows], dtype=float),
            np.array([r[4] for r in rows], dtype=float),
            np.array([r[5] for r in rows], dtype=float))

def ema(data, period):
    alpha = 2.0/(period+1); r=np.zeros_like(data); r[0]=data[0]
    for i in range(1,len(data)): r[i]=alpha*data[i]+(1-alpha)*r[i-1]
    return r

def rsi(close, period=14):
    d=np.diff(close,prepend=close[0]); g=np.maximum(d,0); lo=np.abs(np.minimum(d,0))
    ag=np.zeros_like(close); al=np.zeros_like(close)
    if len(close)<=period: return np.full_like(close,50.0)
    ag[period]=np.mean(g[1:period+1]); al[period]=np.mean(lo[1:period+1])
    for i in range(period+1,len(close)):
        ag[i]=(ag[i-1]*(period-1)+g[i])/period; al[i]=(al[i-1]*(period-1)+lo[i])/period
    rs=np.divide(ag,al,out=np.full_like(ag,1e9),where=al!=0)
    return 100.0-100.0/(1.0+rs)

def macd(close, fast=5, slow=34, signal=5):
    ef=ema(close,fast); es=ema(close,slow); ml=ef-es; sl=ema(ml,signal)
    return ml,sl,ml-sl

def adx(high, low, close, period=14):
    n=len(close); tr=np.zeros(n); pdm=np.zeros(n); ndm=np.zeros(n)
    for i in range(1,n):
        tr[i]=max(high[i]-low[i],abs(high[i]-close[i-1]),abs(low[i]-close[i-1]))
        up=high[i]-high[i-1]; dn=low[i-1]-low[i]
        pdm[i]=up if(up>dn and up>0)else 0; ndm[i]=dn if(dn>up and dn>0)else 0
    atr=np.zeros(n); pdi=np.zeros(n); ndi=np.zeros(n)
    if n>period:
        atr[period]=np.sum(tr[1:period+1]); ps=np.sum(pdm[1:period+1]); ns=np.sum(ndm[1:period+1])
        for i in range(period+1,n):
            atr[i]=atr[i-1]-atr[i-1]/period+tr[i]
            ps=ps-ps/period+pdm[i]; ns=ns-ns/period+ndm[i]
            pdi[i]=100*ps/atr[i] if atr[i]!=0 else 0; ndi[i]=100*ns/atr[i] if atr[i]!=0 else 0
    dx=np.zeros(n)
    for i in range(period+1,n):
        dnom=pdi[i]+ndi[i]
        if dnom>0: dx[i]=100*abs(pdi[i]-ndi[i])/dnom
    ad=np.zeros(n); si=2*period
    if n>si:
        ad[si]=np.mean(dx[period+1:si+1])
        for i in range(si+1,n): ad[i]=(ad[i-1]*(period-1)+dx[i])/period
    return ad,atr

def sharpe(rets):
    if len(rets)<2: return 0.0
    m=np.mean(rets); s=np.std(rets,ddof=1)
    return m/s*np.sqrt(len(rets)) if s>0 else 0.0

def mdd(rets):
    if len(rets)==0: return 0.0
    cum=np.cumsum(rets); return np.min(cum-np.maximum.accumulate(cum))

def sess(ts_ms):
    h=datetime.fromtimestamp(ts_ms/1000,tz=timezone.utc).hour
    if 0<=h<8: return 'Asia'
    elif 8<=h<14: return 'Europe'
    else: return 'US'

def analyze(trades, name):
    if not trades:
        print(f"\n{'='*60}\n{name}: NO TRADES\n{'='*60}")
        return None
    rets=np.array([t['pnl_pct'] for t in trades])
    wins=np.sum(rets>0); total=len(rets)
    wr=wins/total*100; mn=np.mean(rets); sh=sharpe(rets); d=mdd(rets)
    ss=defaultdict(list)
    for t in trades: ss[t['session']].append(t['pnl_pct'])
    print(f"\n{'='*60}\n{name}\n{'='*60}")
    print(f"  Trades:{total} | WR:{wr:.1f}% | Mean:{mn*100:.4f}% | MDD:{d*100:.4f}% | Sharpe:{sh:.3f}")
    for s in['Asia','Europe','US']:
        if s in ss:
            r=ss[s]; w=np.sum(np.array(r)>0)
            print(f"  {s}: {len(r)}t, w={w/len(r)*100:.1f}%, m={np.mean(r)*100:.4f}%")
    rec=(mn>0.0015)and(wr>55)
    print(f"  RECOMMEND: {'✅ YES' if rec else '❌ NO'}")
    return{'name':name,'trades':total,'wr':wr,'mean':mn*100,'mdd':d*100,'sharpe':sh,'recommend':rec}

# ── B3: 15m FVG trend-filter, TP=0.5% ──
def fvg_05tp():
    ts,o,h,l,c,v=load_klines('15m'); e50=ema(c,50); trades=[]
    for i in range(50,len(c)-10):
        k3,k2,k1=i,i+1,i+2
        if l[k1]>h[k3]: gh,gl=l[k1],h[k3]; d='long'
        elif h[k1]<l[k3]: gh,gl=l[k3],h[k1]; d='short'
        else: continue
        if (gh-gl)/gl*100<0.12: continue
        if d=='long' and c[k1]<=e50[k1]: continue
        if d=='short' and c[k1]>=e50[k1]: continue
        for j in range(k1+1,min(k1+6,len(c)-2)):
            trig=False
            if d=='long' and l[j]<=gh and l[j]>=gl:
                ep=gl+(gh-gl)*0.3; sl=gl*0.998; tp=ep*1.005; trig=True
            elif d=='short' and h[j]>=gl and h[j]<=gh:
                ep=gh-(gh-gl)*0.3; sl=gh*1.002; tp=ep*0.995; trig=True
            if not trig: continue
            xp=None
            for x in range(j+1,min(j+8,len(c))):
                if d=='long':
                    if h[x]>=tp: xp=tp; break
                    if l[x]<=sl: xp=sl; break
                else:
                    if l[x]<=tp: xp=tp; break
                    if h[x]>=sl: xp=sl; break
            if xp is None: xp=c[min(j+7,len(c)-1)]
            pnl=(xp-ep)/ep-FEE if d=='long' else (ep-xp)/ep-FEE
            trades.append({'pnl_pct':pnl,'session':sess(ts[j]),'entry_ts':ts[j],'direction':d})
            break
    return trades

# ── B4: 15m FVG trend-filter, 0.5% TP, Asia+Europe only ──
def fvg_asia_eu():
    ts,o,h,l,c,v=load_klines('15m'); e50=ema(c,50); trades=[]
    for i in range(50,len(c)-10):
        k3,k2,k1=i,i+1,i+2
        if l[k1]>h[k3]: gh,gl=l[k1],h[k3]; d='long'
        elif h[k1]<l[k3]: gh,gl=l[k3],h[k1]; d='short'
        else: continue
        if (gh-gl)/gl*100<0.12: continue
        if d=='long' and c[k1]<=e50[k1]: continue
        if d=='short' and c[k1]>=e50[k1]: continue
        for j in range(k1+1,min(k1+6,len(c)-2)):
            if sess(ts[j]) not in ('Asia','Europe'): break
            trig=False
            if d=='long' and l[j]<=gh and l[j]>=gl:
                ep=gl+(gh-gl)*0.3; sl=gl*0.998; tp=ep*1.005; trig=True
            elif d=='short' and h[j]>=gl and h[j]<=gh:
                ep=gh-(gh-gl)*0.3; sl=gh*1.002; tp=ep*0.995; trig=True
            if not trig: continue
            xp=None
            for x in range(j+1,min(j+8,len(c))):
                if d=='long':
                    if h[x]>=tp: xp=tp; break
                    if l[x]<=sl: xp=sl; break
                else:
                    if l[x]<=tp: xp=tp; break
                    if h[x]>=sl: xp=sl; break
            if xp is None: xp=c[min(j+7,len(c)-1)]
            pnl=(xp-ep)/ep-FEE if d=='long' else (ep-xp)/ep-FEE
            trades.append({'pnl_pct':pnl,'session':sess(ts[j]),'entry_ts':ts[j],'direction':d})
            break
    return trades

# ── EMA pullback Asia-only ──
def ema_asia():
    ts,o,h,l,c,v=load_klines('15m')
    if len(c)<60: return[]
    e20=ema(c,20); e50=ema(c,50); trades=[]
    for i in range(50,len(c)-1):
        if sess(ts[i])!='Asia': continue
        if e20[i]<=e50[i] or c[i]<=e50[i]: continue
        if l[i]>e20[i]: continue
        ei=i+1
        if ei>=len(c): continue
        ep=o[ei]; sl=l[i]*0.998; tp=ep*1.004
        xp=None
        for j in range(ei+1,min(ei+12,len(c))):
            if h[j]>=tp: xp=tp; break
            if l[j]<=sl: xp=sl; break
        if xp is None: xp=c[min(ei+11,len(c)-1)]
        trades.append({'pnl_pct':(xp-ep)/ep-FEE,'session':sess(ts[ei]),'entry_ts':ts[ei],'direction':'long'})
    return trades

# ── 1H breakout with ATR stop ──
def h1_breakout():
    ts,o,h,l,c,v=load_klines('1H')
    if len(c)<30: return[]
    adx_v,atr_v=adx(h,l,c,14); trades=[]
    for i in range(30,len(c)-1):
        # Identify range: prior 10 bars high/low
        rng_h=np.max(h[i-10:i]); rng_l=np.min(l[i-10:i])
        rng_pct=(rng_h-rng_l)/rng_l*100
        if rng_pct>1.5: continue  # skip wide ranges
        if adx_v[i]>25: continue  # want low ADX (consolidation)
        # Breakout above range high
        if c[i]>rng_h and v[i]>np.mean(v[i-10:i])*1.3:
            ep=o[i+1] if i+1<len(c) else c[i]
            if i+1>=len(c): continue
            sl=rng_l; tp=ep+rng_pct/100*ep*1.5
            xp=None
            for j in range(i+2,min(i+12,len(c))):
                if h[j]>=tp: xp=tp; break
                if l[j]<=sl: xp=sl; break
            if xp is None: xp=c[min(i+11,len(c)-1)]
            trades.append({'pnl_pct':(xp-ep)/ep-FEE,'session':sess(ts[i+1]),'entry_ts':ts[i+1],'direction':'long'})
    return trades

# ── 5m VWAP with momentum filter ──
def vwap_mom():
    ts,o,h,l,c,v=load_klines('5m')
    if len(c)<200: return[]
    trades=[]
    anchor=96
    for i in range(anchor,len(c)):
        wv=v[i-anchor:i]; wc=c[i-anchor:i]; tv=np.sum(wv)
        if tv==0: continue
        vwap_v=np.sum(wv*wc)/tv; std=np.std(wc,ddof=1)
        if std==0: continue
        up=vwap_v+2.5*std; lo=vwap_v-2.5*std
        if(up-lo)/vwap_v<0.008: continue  # need meaningful width
        # Momentum: price moving toward VWAP already
        ep=None; d=None
        if l[i]<=lo and c[i]>o[i]: ep=lo; d='long'  # bullish reversal at band
        elif h[i]>=up and c[i]<o[i]: ep=up; d='short'
        if ep is None: continue
        tp=vwap_v; sl=ep*(1-0.0025)if d=='long' else ep*(1+0.0025)
        xp=None
        for j in range(i+1,min(i+1+12,len(c))):
            if d=='long':
                if h[j]>=tp: xp=tp; break
                if l[j]<=sl: xp=sl; break
            else:
                if l[j]<=tp: xp=tp; break
                if h[j]>=sl: xp=sl; break
        if xp is None: xp=c[min(i+12,len(c)-1)]
        pnl=(xp-ep)/ep-FEE if d=='long' else (ep-xp)/ep-FEE
        trades.append({'pnl_pct':pnl,'session':sess(ts[i]),'entry_ts':ts[i],'direction':d})
    return trades

# ── 1H MACD signal line crossover (simpler) ──
def h1_macd_simple():
    ts,o,h,l,c,v=load_klines('1H')
    if len(c)<50: return[]
    ml,sl,hist=macd(c,12,26,9); trades=[]
    for i in range(50,len(c)-1):
        # Golden cross: MACD line crosses above signal line
        if ml[i-1]<=sl[i-1] and ml[i]>sl[i]:
            ep=o[i+1] if i+1<len(c) else c[i]
            if i+1>=len(c): continue
            st=ep*0.995; tp=ep*1.008
            xp=None
            for j in range(i+2,min(i+12,len(c))):
                if h[j]>=tp: xp=tp; break
                if l[j]<=st: xp=st; break
            if xp is None: xp=c[min(i+11,len(c)-1)]
            trades.append({'pnl_pct':(xp-ep)/ep-FEE,'session':sess(ts[i+1]),'entry_ts':ts[i+1],'direction':'long'})
    return trades

# ══════════════════════════════════════════════
if __name__=='__main__':
    strats=[
        ('【B3】FVG trend 0.5%TP', fvg_05tp),
        ('【B4】FVG trend 0.5%TP Asia+EU only', fvg_asia_eu),
        ('【EMA-A】15m EMA20 pullback Asia-only 0.4%TP', ema_asia),
        ('【1H-BO】1H range breakout', h1_breakout),
        ('【5m-VWAP】VWAP 2.5σ + momentum', vwap_mom),
        ('【1H-MACD】1H MACD crossover simple', h1_macd_simple),
    ]
    results=[]
    for name,fn in strats:
        print(f"\n{'#'*60}\n# {name}\n{'#'*60}")
        r=analyze(fn(),name)
        if r: results.append(r)

    print(f"\n{'='*70}\nFINAL SUMMARY\n{'='*70}")
    rec=[r for r in results if r['recommend']]
    if rec:
        print("✅ RECOMMENDED:")
        for r in rec:
            print(f"  {r['name']}: WR={r['wr']:.1f}%, Mean={r['mean']:.4f}%, MDD={r['mdd']:.4f}%, Sharpe={r['sharpe']:.3f}")
    else:
        print("❌ No strategy met both criteria.")
    print("\nAll results:")
    for r in sorted(results,key=lambda x:(x['wr']/100)*(x['mean']),reverse=True):
        flag='✅' if r['recommend'] else '  '
        print(f"  {flag} {r['name']}: WR={r['wr']:.1f}%, Mean={r['mean']:.4f}%, Sharpe={r['sharpe']:.3f}")
