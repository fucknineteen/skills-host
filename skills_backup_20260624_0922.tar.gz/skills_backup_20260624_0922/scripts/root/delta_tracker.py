#!/usr/bin/env python3
"""
OKX 永续合约 Delta 数据获取
用法：
  python3 delta_tracker.py BTC-USDT-SWAP        # 拉最近100笔，计算Delta
  python3 delta_tracker.py BTC-USDT-SWAP --save  # 拉取并累积到文件
  python3 delta_tracker.py BTC-USDT-SWAP --read  # 读取累积Delta状态
  python3 delta_tracker.py BTC-USDT-SWAP --reset # 重置累积Delta（08:00 BJT）
"""

import sys, os, json, time, requests
from datetime import datetime, timezone, timedelta

BJT = timezone(timedelta(hours=8))
CUMDELTA_DIR = "/tmp/hermes_delta"
os.makedirs(CUMDELTA_DIR, exist_ok=True)

def get_trades(symbol="BTC-USDT-SWAP", limit=100):
    """拉取最近成交"""
    url = "https://www.okx.com/api/v5/market/trades"
    resp = requests.get(url, params={"instId": symbol, "limit": str(limit)}, timeout=10)
    data = resp.json()
    if data.get("code") != "0":
        print(f"ERROR: {data}")
        return []
    return data["data"]

def calc_delta(trades, minutes=None):
    """计算Delta = 主动买量 - 主动卖量"""
    now_ms = int(time.time() * 1000)
    cutoff = now_ms - (minutes * 60 * 1000) if minutes else 0
    
    buy_vol = sell_vol = 0.0
    buy_cnt = sell_cnt = 0
    max_px = min_px = None
    
    for t in trades:
        ts = int(t["ts"])
        if ts < cutoff:
            continue
        sz = float(t["sz"])
        px = float(t["px"])
        if t["side"] == "buy":
            buy_vol += sz
            buy_cnt += 1
        else:
            sell_vol += sz
            sell_cnt += 1
        if max_px is None or px > max_px: max_px = px
        if min_px is None or px < min_px: min_px = px
    
    delta = buy_vol - sell_vol
    total = buy_vol + sell_vol
    ratio = buy_vol / sell_vol if sell_vol > 0 else float('inf')
    
    return {
        "delta": round(delta, 4),
        "buy_vol": round(buy_vol, 4),
        "sell_vol": round(sell_vol, 4),
        "buy_sell_ratio": round(ratio, 4),
        "buy_count": buy_cnt,
        "sell_count": sell_cnt,
        "total_trades": buy_cnt + sell_cnt,
        "price_range": f"{min_px}-{max_px}" if min_px and max_px else "N/A",
        "time": datetime.now(BJT).strftime("%H:%M:%S")
    }

def save_cumdelta(symbol, new_delta):
    """累积Delta到文件"""
    fpath = f"{CUMDELTA_DIR}/{symbol.replace('-', '_')}_cumdelta.json"
    
    if os.path.exists(fpath):
        with open(fpath) as f:
            cum = json.load(f)
    else:
        cum = {"symbol": symbol, "cumulative_delta": 0.0, "updates": 0,
               "started_at": datetime.now(BJT).isoformat(), "last_price": None}
    
    cum["cumulative_delta"] = round(cum["cumulative_delta"] + new_delta["delta"], 4)
    cum["updates"] += 1
    cum["last_delta"] = new_delta["delta"]
    cum["last_ratio"] = new_delta["buy_sell_ratio"]
    cum["last_update"] = datetime.now(BJT).isoformat()
    
    with open(fpath, 'w') as f:
        json.dump(cum, f, indent=2)
    
    return cum

def read_cumdelta(symbol):
    """读取累积Delta"""
    fpath = f"{CUMDELTA_DIR}/{symbol.replace('-', '_')}_cumdelta.json"
    if os.path.exists(fpath):
        with open(fpath) as f:
            return json.load(f)
    return None

def reset_cumdelta(symbol):
    """重置累积Delta"""
    fpath = f"{CUMDELTA_DIR}/{symbol.replace('-', '_')}_cumdelta.json"
    if os.path.exists(fpath):
        os.remove(fpath)
        print(f"✓ {symbol} 累积Delta已重置")

if __name__ == "__main__":
    symbol = sys.argv[1] if len(sys.argv) > 1 else "BTC-USDT-SWAP"
    action = sys.argv[2] if len(sys.argv) > 2 else ""
    
    if action == "--reset":
        reset_cumdelta(symbol)
        sys.exit(0)
    
    if action == "--read":
        cum = read_cumdelta(symbol)
        if cum:
            print(json.dumps(cum, indent=2))
        else:
            print(f"{symbol}: 暂无累积Delta数据")
        sys.exit(0)
    
    # 拉取并计算
    trades = get_trades(symbol, limit=100)
    recent = calc_delta(trades, minutes=5)   # 最近5分钟
    all100 = calc_delta(trades)               # 最近100笔
    
    print(f"📊 {symbol} Delta 分析 | {recent['time']} BJT")
    print(f"━━━━━━━━━━━━━━━━━━━━━━━━━━━━━")
    print(f"最近5分钟 ({recent['total_trades']}笔):")
    print(f"  Delta: {recent['delta']:+.4f} | 买/卖比: {recent['buy_sell_ratio']}")
    print(f"  买量: {recent['buy_vol']} | 卖量: {recent['sell_vol']}")
    print(f"  价格区间: {recent['price_range']}")
    print(f"最近100笔 ({all100['total_trades']}笔):")
    print(f"  Delta: {all100['delta']:+.4f} | 买/卖比: {all100['buy_sell_ratio']}")
    
    if action == "--save":
        cum = save_cumdelta(symbol, recent)
        print(f"\n📈 累积Delta: {cum['cumulative_delta']:+.4f} (已更新{cum['updates']}次)")
        print(f"   启动于: {cum['started_at']}")
    
    # 信号解读
    if recent['buy_sell_ratio'] > 2.0 and recent['total_trades'] >= 20:
        print(f"\n🔴 信号：极端买方主导 (ratio={recent['buy_sell_ratio']})")
    elif recent['buy_sell_ratio'] < 0.5 and recent['total_trades'] >= 20:
        print(f"\n🔴 信号：极端卖方主导 (ratio={recent['buy_sell_ratio']})")
    
    # 累积Delta背离检测
    cum = read_cumdelta(symbol)
    if cum:
        cum_d = cum["cumulative_delta"]
        if abs(cum_d) > 100:
            direction = "偏多" if cum_d > 0 else "偏空"
            print(f"\n📈 累积Delta: {cum_d:+.1f} ({direction}, {cum['updates']}次采样)")
