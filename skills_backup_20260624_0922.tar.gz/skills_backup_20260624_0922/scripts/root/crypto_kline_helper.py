#!/usr/bin/env python3
"""
K-line 数据存储与增量拉取助手
DB: /root/BTC_Kline.db + /root/ETH_Kline.db
"""
import sqlite3, json, subprocess, time
from datetime import datetime, timezone, timedelta

DB_DIR = "/root"
OKX_BASE = "https://www.okx.com/api/v5"

# 每个时间框架的拉取窗口（仅精细级别，日/周/月/季由独立 cron 脚本维护）
FETCH_WINDOWS = {
    "1m":  {"hours": 5,   "max_candles": 300},
    "5m":  {"hours": 12,  "max_candles": 144},
    "30m": {"hours": 12,  "max_candles": 24},
    "1H":  {"hours": 12,  "max_candles": 12},
    "4H":  {"hours": 12,  "max_candles": 3},
}

SYMBOLS = ["BTC-USDT-SWAP", "ETH-USDT-SWAP"]

def get_db_path(symbol):
    """根据币种返回对应数据库路径"""
    prefix = "BTC" if "BTC" in symbol else "ETH"
    return f"{DB_DIR}/{prefix}_Kline.db"


def get_conn(symbol):
    conn = sqlite3.connect(get_db_path(symbol))
    # 确保所有表存在
    for tf in FETCH_WINDOWS:
        conn.execute(f"""
            CREATE TABLE IF NOT EXISTS kline_{tf} (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                ts INTEGER NOT NULL,
                open REAL,
                high REAL,
                low REAL,
                close REAL,
                volume REAL,
                confirm INTEGER DEFAULT 0,
                UNIQUE(ts)
            )
        """)
        conn.execute(f"""
            CREATE INDEX IF NOT EXISTS idx_kline_{tf}_ts ON kline_{tf}(ts)
        """)
    conn.commit()
    return conn


def okx_get(endpoint):
    """调用 OKX 公开 API (with DNS workaround for 169.254.0.2 hijack)"""
    url = f"{OKX_BASE}{endpoint}"
    r = subprocess.run(
        ["curl", "-s", "--max-time", "10",
         "--resolve", "www.okx.com:443:104.18.12.94",
         url],
        capture_output=True, text=True
    )
    return json.loads(r.stdout)


def get_last_ts(conn, table):
    """获取某个表的最新时间戳 (ms)"""
    row = conn.execute(f"SELECT MAX(ts) FROM {table} WHERE confirm = 1").fetchone()
    return row[0] if row[0] else None


def fetch_and_store(conn, symbol, timeframe):
    """拉取增量 K 线并存入数据库"""
    table = f"kline_{timeframe}"
    window = FETCH_WINDOWS[timeframe]
    
    last_ts = get_last_ts(conn, table)
    limit = window["max_candles"]
    bar = window.get("bar", timeframe)
    
    resp = okx_get(f"/market/candles?instId={symbol}&bar={bar}&limit={limit}")
    if resp.get("code") != "0" or "data" not in resp:
        print(f"  ❌ {symbol} {timeframe}: {resp.get('msg', 'unknown')}")
        return 0
    
    candles = resp["data"]
    
    inserted = 0
    for c in candles:
        ts = int(c[0])
        o, h, l, clo, vol = float(c[1]), float(c[2]), float(c[3]), float(c[4]), float(c[5])
        confirm = int(c[8]) if len(c) > 8 else 1
        
        if last_ts and ts <= last_ts:
            continue
        
        try:
            conn.execute(
                f"""INSERT OR IGNORE INTO {table} (ts, open, high, low, close, volume, confirm)
                    VALUES (?,?,?,?,?,?,?)""",
                (ts, o, h, l, clo, vol, confirm)
            )
            if conn.execute("SELECT changes()").fetchone()[0] > 0:
                inserted += 1
        except Exception as e:
            print(f"  ⚠️ insert error {symbol} {timeframe} ts={ts}: {e}")
    
    conn.commit()
    return inserted


def fetch_all(time_now_str=None):
    """拉取所有币种所有时间框架的增量数据"""
    if time_now_str:
        print(f"📡 数据抓取开始: {time_now_str}")
    
    total = 0
    for symbol in SYMBOLS:
        print(f"\n{'='*60}")
        print(f"  {symbol} → {get_db_path(symbol)}")
        conn = get_conn(symbol)
        for tf in FETCH_WINDOWS:
            count = fetch_and_store(conn, symbol, tf)
            if count > 0:
                print(f"  ✅ {tf}: +{count} 根 (窗口 {FETCH_WINDOWS[tf]['hours']}h)")
            total += count
        conn.close()
    
    return total


def get_klines(symbol, timeframe, limit=None):
    """从数据库读取 K 线数据，按时间升序"""
    conn = get_conn(symbol)
    table = f"kline_{timeframe}"
    
    query = f"""SELECT ts, open, high, low, close, volume, confirm
                FROM {table}
                ORDER BY ts ASC"""
    if limit:
        query += f" LIMIT {limit}"
    
    rows = conn.execute(query).fetchall()
    conn.close()
    
    return [
        {"ts": r[0], "open": r[1], "high": r[2], "low": r[3],
         "close": r[4], "volume": r[5], "confirm": r[6]}
        for r in rows
    ]


def get_db_stats():
    """获取数据库统计信息"""
    stats = {}
    for sym in SYMBOLS:
        conn = get_conn(sym)
        for tf in FETCH_WINDOWS:
            key = f"{sym} {tf}"
            row = conn.execute(
                f"SELECT COUNT(*), MIN(ts), MAX(ts) FROM kline_{tf}"
            ).fetchone()
            stats[key] = {
                "count": row[0],
                "from": datetime.fromtimestamp(row[1]/1000, tz=timezone(timedelta(hours=8))).strftime("%m-%d %H:%M") if row[1] else "N/A",
                "to": datetime.fromtimestamp(row[2]/1000, tz=timezone(timedelta(hours=8))).strftime("%m-%d %H:%M") if row[2] else "N/A",
            }
        conn.close()
    return stats


if __name__ == "__main__":
    import sys
    if len(sys.argv) > 1 and sys.argv[1] == "stats":
        stats = get_db_stats()
        for k, v in stats.items():
            print(f"{k}: {v['count']} 根 ({v['from']} ~ {v['to']})")
    else:
        bjt = datetime.now(timezone(timedelta(hours=8))).strftime("%Y-%m-%d %H:%M:%S BJT")
        added = fetch_all(bjt)
        print(f"\n📊 总计新增: {added} 根 K 线")
        stats = get_db_stats()
        for k, v in stats.items():
            print(f"  {k}: {v['count']} 根 ({v['from']} ~ {v['to']})")
