#!/usr/bin/env python3
"""Final push: US-only FVG, long-only FVG, and 15m momentum."""
import sqlite3, numpy as np
from datetime import datetime, timezone
from collections import defaultdict

DB = "/root/.hermes/trade_review/okx_klines.db"; FEE=0.0014

def load_klines(tf):
    conn=sqlite3.connect(DB)
    rows=conn.execute("SELECT ts,open,high,low,close,volume FROM klines WHERE coin='BTC' AND timeframe=? ORDER BY ts ASC",(tf,)).fetchall()
    conn.close()
    return(np.array([r[0]for r in rows]),np.array([r[1]for r in rows],dtype=float),np.array([r[2]for r in rows],dtype=float),np.array([r[3]for r in rows],dtype=float),np.array([r[4]for r in rows],dtype=float),np.array([r[5]for r in rows],dtype=float))

def ema(d,p):
    a=2/(p+1);r=np.zeros_like(d);r[0]=d[0]
    for i in range(1,len(d)):r[i]=a*d[i]+(1-a)*r[i-1]
    return r

def rsi(c,p=14):
    d=np.diff(c,prepend=c[0]);g=np.maximum(d,0);lo=np.abs(np.minimum(d,0))
    ag=np.zeros_like(c);al=np.zeros_like(c)
    if len(c)<=p:return np.full_like(c,50.)
    ag[p]=np.mean(g[1:p+1]);al[p]=np.mean(lo[1:p+1])
    for i in range(p+1,len(c)):ag[i]=(ag[i-1]*(p-1)+g[i])/p;al[i]=(al[i-1]*(p-1)+lo[i])/p
    rs=np.divide(ag,al,out=np.full_like(ag,1e9),where=al!=0)
    return 100-100/(1+rs)

def sess(ts_ms):
    h=datetime.fromtimestamp(ts_ms/1000,tz=timezone.utc).hour
    if 0<=h<8:return'Asia'
    elif 8<=h<14:return'Europe'
    else:return'US'

def analyze(tr,name):
    if not tr:print(f"\n{'='*60}\n{name}: NO TRADES\n{'='*60}");return None
    rets=np.array([t['pnl_pct']for t in tr]);w=np.sum(rets>0);tot=len(rets)
    wr=w/tot*100;mn=np.mean(rets);sd=np.std(rets,ddof=1)if tot>1 else 0
    sh=mn/sd*np.sqrt(tot)if sd>0 else 0;d=np.min(np.cumsum(rets)-np.maximum.accumulate(np.cumsum(rets)))if tot>0 else 0
    ss=defaultdict(list)
    for t in tr:ss[t['session']].append(t['pnl_pct'])
    print(f"\n{'='*60}\n{name}\n{'='*60}")
    print(f"  Trades:{tot} | WR:{wr:.1f}% | Mean:{mn*100:.4f}% | MDD:{d*100:.4f}% | Sharpe:{sh:.3f}")
    for s in['Asia','Europe','US']:
        if s in ss:
            r=ss[s];w2=np.sum(np.array(r)>0)
            print(f"  {s}:{len(r)}t w={w2/len(r)*100:.1f}% m={np.mean(r)*100:.4f}%")
    rec=(mn>0.0015)and(wr>55)
    print(f"  RECOMMEND: {'✅ YES' if rec else '❌ NO'}")
    return{'name':name,'trades':tot,'wr':wr,'mean':mn*100,'mdd':d*100,'sharpe':sh,'recommend':rec}

# ── FVG-US: trend-filter FVG, US session only, 0.5% TP ──
def fvg_us():
    ts,o,h,l,c,v=load_klines('15m');e50=ema(c,50);trades=[]
    for i in range(50,len(c)-10):
        k3,k2,k1=i,i+1,i+2
        if l[k1]>h[k3]:gh,gl=l[k1],h[k3];d='long'
        elif h[k1]<l[k3]:gh,gl=l[k3],h[k1];d='short'
        else:continue
        if(gh-gl)/gl*100<0.12:continue
        if d=='long'and c[k1]<=e50[k1]:continue
        if d=='short'and c[k1]>=e50[k1]:continue
        for j in range(k1+1,min(k1+6,len(c)-2)):
            if sess(ts[j])!='US':break
            trig=False
            if d=='long'and l[j]<=gh and l[j]>=gl:
                ep=gl+(gh-gl)*0.3;sl=gl*0.998;tp=ep*1.005;trig=True
            elif d=='short'and h[j]>=gl and h[j]<=gh:
                ep=gh-(gh-gl)*0.3;sl=gh*1.002;tp=ep*0.995;trig=True
            if not trig:continue
            xp=None
            for x in range(j+1,min(j+8,len(c))):
                if d=='long':
                    if h[x]>=tp:xp=tp;break
                    if l[x]<=sl:xp=sl;break
                else:
                    if l[x]<=tp:xp=tp;break
                    if h[x]>=sl:xp=sl;break
            if xp is None:xp=c[min(j+7,len(c)-1)]
            pnl=(xp-ep)/ep-FEE if d=='long'else(ep-xp)/ep-FEE
            trades.append({'pnl_pct':pnl,'session':sess(ts[j]),'entry_ts':ts[j],'direction':d})
            break
    return trades

# ── FVG long-only, trend filter, 0.6% TP ──
def fvg_long():
    ts,o,h,l,c,v=load_klines('15m');e50=ema(c,50);trades=[]
    for i in range(50,len(c)-10):
        k3,k2,k1=i,i+1,i+2
        if not(l[k1]>h[k3]):continue  # long only
        gh,gl=l[k1],h[k3]
        if(gh-gl)/gl*100<0.12:continue
        if c[k1]<=e50[k1]:continue
        for j in range(k1+1,min(k1+6,len(c)-2)):
            if l[j]<=gh and l[j]>=gl:
                ep=gl+(gh-gl)*0.3;sl=gl*0.998;tp=ep*1.006
                xp=None
                for x in range(j+1,min(j+8,len(c))):
                    if h[x]>=tp:xp=tp;break
                    if l[x]<=sl:xp=sl;break
                if xp is None:xp=c[min(j+7,len(c)-1)]
                pnl=(xp-ep)/ep-FEE
                trades.append({'pnl_pct':pnl,'session':sess(ts[j]),'entry_ts':ts[j],'direction':'long'})
                break
    return trades

# ── 15m Momentum: EMA crossover + RSI filter ──
def mom_15m():
    ts,o,h,l,c,v=load_klines('15m')
    if len(c)<60:return[]
    e20=ema(c,20);e50=ema(c,50);r=rsi(c,14);trades=[]
    for i in range(50,len(c)-1):
        # Uptrend: EMA20 > EMA50
        if e20[i]<=e50[i]:continue
        # Momentum entry: RSI > 55 (not yet overbought)
        if r[i]<=55:continue
        # Price > EMA20
        if c[i]<=e20[i]:continue
        # Volume increasing
        if i<5 or v[i]<=np.mean(v[i-5:i])*1.1:continue

        ep=o[i+1]if i+1<len(c)else c[i]
        if i+1>=len(c):continue
        sl=e20[i];tp=ep*1.004
        xp=None
        for j in range(i+2,min(i+8,len(c))):
            if h[j]>=tp:xp=tp;break
            if l[j]<=sl:xp=sl;break
        if xp is None:xp=c[min(i+7,len(c)-1)]
        trades.append({'pnl_pct':(xp-ep)/ep-FEE,'session':sess(ts[i+1]),'entry_ts':ts[i+1],'direction':'long'})
    return trades

# ── 1H trend following: ADX > 25 + EMA alignment ──
def h1_trend():
    ts,o,h,l,c,v=load_klines('1H')
    if len(c)<60:return[]
    # inline ADX
    def adx_fn(hh,ll,cc,period=14):
        n=len(cc);tr=np.zeros(n);pdm=np.zeros(n);ndm=np.zeros(n)
        for i in range(1,n):
            tr[i]=max(hh[i]-ll[i],abs(hh[i]-cc[i-1]),abs(ll[i]-cc[i-1]))
            up=hh[i]-hh[i-1];dn=ll[i-1]-ll[i]
            pdm[i]=up if(up>dn and up>0)else 0;ndm[i]=dn if(dn>up and dn>0)else 0
        at=np.zeros(n);pdi=np.zeros(n);ndi=np.zeros(n)
        if n>period:
            at[period]=np.sum(tr[1:period+1]);ps=np.sum(pdm[1:period+1]);ns=np.sum(ndm[1:period+1])
            for i in range(period+1,n):
                at[i]=at[i-1]-at[i-1]/period+tr[i]
                ps=ps-ps/period+pdm[i];ns=ns-ns/period+ndm[i]
                pdi[i]=100*ps/at[i]if at[i]!=0 else 0;ndi[i]=100*ns/at[i]if at[i]!=0 else 0
        dx=np.zeros(n)
        for i in range(period+1,n):
            dnom=pdi[i]+ndi[i]
            if dnom>0:dx[i]=100*abs(pdi[i]-ndi[i])/dnom
        ad=np.zeros(n);si=2*period
        if n>si:
            ad[si]=np.mean(dx[period+1:si+1])
            for i in range(si+1,n):ad[i]=(ad[i-1]*(period-1)+dx[i])/period
        return ad
    e20=ema(c,20);e50=ema(c,50);ad=adx_fn(h,l,c,14);trades=[]
    for i in range(50,len(c)-1):
        if ad[i]<=25:continue  # trending market
        # Long: EMA20 > EMA50
        if e20[i]<=e50[i]:continue
        # Entry on pullback to EMA20
        if l[i]>e20[i]:continue
        if c[i]>=e20[i]:continue  # must close below EMA20 (pullback)
        ep=o[i+1]if i+1<len(c)else c[i]
        if i+1>=len(c):continue
        sl=l[i]*0.995;tp=ep*1.008
        xp=None
        for j in range(i+2,min(i+12,len(c))):
            if h[j]>=tp:xp=tp;break
            if l[j]<=sl:xp=sl;break
        if xp is None:xp=c[min(i+11,len(c)-1)]
        trades.append({'pnl_pct':(xp-ep)/ep-FEE,'session':sess(ts[i+1]),'entry_ts':ts[i+1],'direction':'long'})
    return trades

if __name__=='__main__':
    strats=[
        ('【FVG-US】FVG trend 0.5%TP US-only',fvg_us),
        ('【FVG-L】FVG long-only 0.6%TP',fvg_long),
        ('【MOM-15】15m momentum EMA+Rsi',mom_15m),
        ('【1H-TF】1H trend pullback ADX>25',h1_trend),
    ]
    results=[]
    for name,fn in strats:
        print(f"\n{'#'*60}\n# {name}\n{'#'*60}")
        r=analyze(fn(),name)
        if r:results.append(r)

    print(f"\n{'='*70}\nFINAL SUMMARY\n{'='*70}")
    rec=[r for r in results if r['recommend']]
    if rec:
        print("✅ RECOMMENDED:")
        for r in rec:print(f"  {r['name']}: WR={r['wr']:.1f}%, Mean={r['mean']:.4f}%, MDD={r['mdd']:.4f}%, Sharpe={r['sharpe']:.3f}")
    else:
        print("❌ NONE passed both criteria")
    print("\nRanked (WR*Mean):")
    for r in sorted(results,key=lambda x:(x['wr']/100)*(x['mean']),reverse=True):
        print(f"  {r['name']}: WR={r['wr']:.1f}%, Mean={r['mean']:.4f}%")
