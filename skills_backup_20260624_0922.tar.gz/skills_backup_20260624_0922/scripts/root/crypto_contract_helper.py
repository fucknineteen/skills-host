#!/usr/bin/env python3
"""
Binance 免费合约数据拉取助手
替代 CoinGlass 付费 API，从 Binance Futures 公开端点获取合约市场数据。

全部端点无需 API Key，但部分端点（/futures/data/*）可能受 IP 地区限制。
当前环境验证：全部 5 类端点可用。

使用方式：
    from crypto_contract_helper import get_all_contract_data, format_contract_summary
    btc_data = get_all_contract_data("BTC")
    print(format_contract_summary(btc_data))
"""

import json, subprocess, time
from datetime import datetime

BINANCE_FAPI = "https://fapi.binance.com"
BINANCE_FUTURES_DATA = "https://fapi.binance.com/futures/data"

SYMBOLS = {"BTC": "BTCUSDT", "ETH": "ETHUSDT"}


def _curl_get(url):
    """GET 请求，返回 parsed JSON 或 None"""
    r = subprocess.run(
        ["curl", "-s", "--max-time", "8", url],
        capture_output=True, text=True
    )
    if r.returncode != 0 or not r.stdout.strip():
        return None
    # Binance 地区限制返回 HTML 错误页
    if r.stdout.strip().startswith("<!") or "<html" in r.stdout[:200].lower():
        return None
    try:
        return json.loads(r.stdout)
    except json.JSONDecodeError:
        return None


def get_open_interest(coin="BTC"):
    """当前持仓量 (OI)。返回 dict 含 openInterest 字段，单位为「张」合约。"""
    symbol = SYMBOLS.get(coin, "BTCUSDT")
    return _curl_get(f"{BINANCE_FAPI}/fapi/v1/openInterest?symbol={symbol}")


def get_funding_rate(coin="BTC"):
    """最新资金费率。正=多付空，负=空付多。返回含 fundingRate/markPrice 的 dict。"""
    symbol = SYMBOLS.get(coin, "BTCUSDT")
    data = _curl_get(f"{BINANCE_FAPI}/fapi/v1/fundingRate?symbol={symbol}&limit=1")
    if data and isinstance(data, list) and len(data) > 0:
        return data[0]
    return None


def get_ls_ratio(coin="BTC", period="5m"):
    """
    全局多空比 (Long/Short Account Ratio)。
    >1 = 多头账户多于空头（偏拥挤）；<1 = 空头多于多头。
    ⚠️ 注意：此端点路径为 /futures/data/ 而非 /fapi/v1/
    """
    symbol = SYMBOLS.get(coin, "BTCUSDT")
    data = _curl_get(
        f"{BINANCE_FUTURES_DATA}/globalLongShortAccountRatio"
        f"?symbol={symbol}&period={period}&limit=1"
    )
    if data and isinstance(data, list) and len(data) > 0:
        return data[0]
    return None


def get_top_ls_ratio(coin="BTC", period="5m"):
    """
    大户多空比 (Top Trader Long/Short Ratio)。
    仅统计持仓量前 20% 的大户，用于判断「聪明钱」方向。
    散户倾向 = 全局 L/S - 大户 L/S（定性推断）。
    ⚠️ 路径为 /futures/data/ 而非 /fapi/v1/
    """
    symbol = SYMBOLS.get(coin, "BTCUSDT")
    data = _curl_get(
        f"{BINANCE_FUTURES_DATA}/topLongShortAccountRatio"
        f"?symbol={symbol}&period={period}&limit=1"
    )
    if data and isinstance(data, list) and len(data) > 0:
        return data[0]
    return None


def get_taker_volume(coin="BTC", period="5m"):
    """
    主动买卖量比 (Taker Buy/Sell Volume Ratio)。
    >1 = 主动买盘多于卖盘（买方积极）；<1 = 主动卖盘多（卖方主导）。
    包含 buyVol/sellVol 原始值用于深度分析。
    ⚠️ 路径为 /futures/data/ 而非 /fapi/v1/
    """
    symbol = SYMBOLS.get(coin, "BTCUSDT")
    data = _curl_get(
        f"{BINANCE_FUTURES_DATA}/takerlongshortRatio"
        f"?symbol={symbol}&period={period}&limit=1"
    )
    if data and isinstance(data, list) and len(data) > 0:
        return data[0]
    return None


def get_all_contract_data(coin="BTC"):
    """
    一次性拉取指定币种的全部 5 类免费合约数据。
    返回 dict，失败的字段值为 None（不阻断整体流程）。
    
    返回结构:
    {
        "coin": "BTC",
        "ts": "2026-05-28 15:30:00 BJT",
        "oi": {...},
        "funding_rate": {...},
        "ls_ratio": {...},
        "top_ls_ratio": {...},
        "taker_volume": {...}
    }
    """
    results = {"coin": coin, "ts": datetime.now().strftime("%Y-%m-%d %H:%M:%S BJT")}
    
    for name, fn in [
        ("oi", get_open_interest),
        ("funding_rate", get_funding_rate),
        ("ls_ratio", get_ls_ratio),
        ("top_ls_ratio", get_top_ls_ratio),
        ("taker_volume", get_taker_volume),
    ]:
        try:
            results[name] = fn(coin)
        except Exception:
            results[name] = None
    
    return results


def format_contract_summary(data):
    """
    将合约数据格式化为单行摘要，用于嵌入分析报告。
    
    输出示例：
    BTC合约数据 | OI=102.4K张 | 费率=0.0099%⚖️ | 全局L/S=1.60 | 大户L/S=1.58 | 主动买/卖=1.51🟢
    """
    coin = data.get("coin", "?")
    parts = [f"{coin}合约数据"]
    
    oi = data.get("oi") or {}
    if oi.get("openInterest"):
        oi_val = float(oi["openInterest"])
        if oi_val >= 1e6:
            parts.append(f"OI={oi_val/1e6:.1f}M张")
        else:
            parts.append(f"OI={oi_val/1e3:.1f}K张")
    
    fr = data.get("funding_rate") or {}
    if fr.get("fundingRate"):
        rate = float(fr["fundingRate"])
        icon = "📈" if rate > 0.0001 else "📉" if rate < 0 else "⚖️"
        parts.append(f"费率={rate*100:.4f}%{icon}")
    
    ls = data.get("ls_ratio") or {}
    if ls.get("longShortRatio"):
        parts.append(f"全局L/S={float(ls['longShortRatio']):.2f}")
    
    top = data.get("top_ls_ratio") or {}
    if top.get("longShortRatio"):
        parts.append(f"大户L/S={float(top['longShortRatio']):.2f}")
    
    tv = data.get("taker_volume") or {}
    if tv.get("buySellRatio"):
        bsr = float(tv["buySellRatio"])
        icon = "🟢" if bsr > 1.1 else "🔴" if bsr < 0.9 else "⚖️"
        parts.append(f"主动买/卖={bsr:.2f}{icon}")
    
    return " | ".join(parts)


def interpret_signals(data):
    """
    根据合约数据生成多空信号解读（用于分析报告）。
    返回 dict: {bias: "🐂"|"🐻"|"⚖️", signals: [...], score: int}
    score: -5 到 +5，正=偏多，负=偏空
    """
    signals = []
    score = 0
    
    # 1. 资金费率
    fr = data.get("funding_rate") or {}
    if fr.get("fundingRate"):
        rate = float(fr["fundingRate"])
        if rate > 0.0003:       # >0.03% = 多头过度拥挤 → 偏空
            signals.append(f"费率{rate*100:.3f}%偏高→多头拥挤🐻")
            score -= 1
        elif rate > 0.0001:     # 0.01-0.03% = 轻度偏多
            signals.append(f"费率{rate*100:.3f}%正常偏多🐂")
            score += 1
        elif rate >= 0:
            signals.append(f"费率{rate*100:.3f}%中性⚖️")
        else:
            signals.append(f"费率{rate*100:.3f}%负值→空头拥挤🐂")
            score += 1
    
    # 2. 大户 vs 全局多空比
    ls = data.get("ls_ratio") or {}
    top = data.get("top_ls_ratio") or {}
    if ls.get("longShortRatio") and top.get("longShortRatio"):
        global_ls = float(ls["longShortRatio"])
        top_ls = float(top["longShortRatio"])
        
        if top_ls > global_ls:  # 大户比散户更偏多
            signals.append(f"大户偏多({top_ls:.2f}>{global_ls:.2f})🐂")
            score += 1
        elif top_ls < global_ls:  # 大户比散户更偏空
            signals.append(f"大户偏空({top_ls:.2f}<{global_ls:.2f})🐻")
            score -= 1
        else:
            signals.append(f"大户与散户一致⚖️")
        
        # 极端值
        if global_ls > 3.0:
            signals.append(f"全局L/S={global_ls:.2f}极度偏多→反转风险🐻")
            score -= 1
    
    # 3. 主动买卖比
    tv = data.get("taker_volume") or {}
    if tv.get("buySellRatio"):
        bsr = float(tv["buySellRatio"])
        if bsr > 1.5:
            signals.append(f"主动买盘主导({bsr:.2f})🟢")
            score += 1
        elif bsr > 1.1:
            signals.append(f"买方略积极({bsr:.2f})↗️")
        elif bsr < 0.9:
            signals.append(f"卖方主导({bsr:.2f})🔴")
            score -= 1
        else:
            signals.append(f"买卖均衡({bsr:.2f})⚖️")
    
    bias = "🐂" if score > 0 else "🐻" if score < 0 else "⚖️"
    return {"bias": bias, "signals": signals, "score": score}


if __name__ == "__main__":
    import sys
    coin = sys.argv[1].upper() if len(sys.argv) > 1 else "BTC"
    if coin not in ("BTC", "ETH"):
        print(f"用法: python3 crypto_contract_helper.py [BTC|ETH]")
        sys.exit(1)
    
    print("=" * 60)
    print(f"  {coin} 免费合约数据 (Binance Futures 公开 API)")
    print("=" * 60)
    
    data = get_all_contract_data(coin)
    
    for key, label, fmt_fn in [
        ("oi", "📊 OI", lambda d: f"{float(d['openInterest']):,.0f} 张"),
        ("funding_rate", "💰 费率", lambda d: f"{float(d['fundingRate'])*100:.4f}%"),
        ("ls_ratio", "📈 全局多空比", lambda d: f"{float(d['longShortRatio']):.2f}"),
        ("top_ls_ratio", "🐋 大户多空比", lambda d: f"{float(d['longShortRatio']):.2f}"),
        ("taker_volume", "🔄 主动买/卖", lambda d: f"{float(d['buySellRatio']):.2f}"),
    ]:
        val = data.get(key)
        if val:
            print(f"  {label}: {fmt_fn(val)}")
        else:
            print(f"  ❌ {label}: 获取失败")
    
    print(f"\n  摘要: {format_contract_summary(data)}")
    
    sig = interpret_signals(data)
    print(f"  信号: {sig['bias']} (score={sig['score']})")
    for s in sig['signals']:
        print(f"    → {s}")
