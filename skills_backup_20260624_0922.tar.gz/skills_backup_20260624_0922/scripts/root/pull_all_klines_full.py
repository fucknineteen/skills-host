#!/usr/bin/env python3
"""
全量K线拉取 + 去重更新到 okx_klines.db
翻页回溯拉取所有可用历史数据
LAB → 币安，其余 → OKX
"""
import sqlite3, json, subprocess, time, sys
from datetime import datetime, timezone, timedelta

DB_PATH = "/root/.hermes/trade_review/okx_klines.db"
BJT = timezone(timedelta(hours=8))

# ============================================================
# 配置
# ============================================================
COINS = ["BTC", "ETH", "SOL", "HOME", "OND", "ZEC", "ALLO"]
BINANCE_COINS = ["LAB"]  # LAB 走币安

TIMEFRAMES = ["1m", "5m", "15m", "30m", "1H", "4H", "1D", "1W"]

# OKX bar 映射
OKX_BAR = {"1m":"1m","5m":"5m","15m":"15m","30m":"30m","1H":"1H","4H":"4H","1D":"1D","1W":"1W"}
OKX_LIMIT = 300

# 币安
BINANCE_INTERVAL = {"1m":"1m","5m":"5m","15m":"15m","30m":"30m","1H":"1h","4H":"4h","1D":"1d","1W":"1w"}
BINANCE_LIMIT = 1500

# ============================================================
# curl
# ============================================================
def curl_get(url, retries=3):
    cmd = ["curl", "-s", "--connect-timeout", "8", "--max-time", "30", url]
    for attempt in range(retries):
        try:
            r = subprocess.run(cmd, capture_output=True, text=True)
            if r.stdout.strip():
                return r.stdout.strip()
        except:
            pass
        time.sleep(1)
    return None

# ============================================================
# OKX 翻页拉取
# ============================================================
def okx_fetch_page(coin, timeframe, limit, after=""):
    bar = OKX_BAR[timeframe]
    inst_id = f"{coin}-USDT-SWAP"
    url = f"https://www.okx.com/api/v5/market/candles?instId={inst_id}&bar={bar}&limit={limit}"
    if after:
        url += f"&after={after}"
    raw = curl_get(url)
    if not raw:
        return None
    try:
        data = json.loads(raw)
        if data.get("code") == "0" and data.get("data"):
            return data["data"]
    except:
        pass
    return None

# ============================================================
# 币安翻页拉取
# ============================================================
def binance_fetch_page(coin, timeframe, limit, end_time=None):
    interval = BINANCE_INTERVAL[timeframe]
    symbol = f"{coin}USDT"
    url = f"https://fapi.binance.com/fapi/v1/klines?symbol={symbol}&interval={interval}&limit={limit}"
    if end_time:
        url += f"&endTime={end_time}"
    raw = curl_get(url)
    if not raw:
        return None
    try:
        data = json.loads(raw)
        if isinstance(data, list) and len(data) > 0:
            result = []
            for c in data:
                result.append([c[0], c[1], c[2], c[3], c[4], c[5], c[7]])
            return result
    except:
        pass
    return None

# ============================================================
# 保存到DB
# ============================================================
def save_candles(conn, coin, timeframe, candles):
    rows = []
    for c in candles:
        ts = int(c[0])
        rows.append((coin, timeframe, ts,
                     float(c[1]), float(c[2]), float(c[3]), float(c[4]),
                     float(c[5]), float(c[6])))
    conn.executemany("""
        INSERT OR REPLACE INTO klines (coin, timeframe, ts, open, high, low, close, volume, vol_ccy, updated_at)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, datetime('now'))
    """, rows)
    conn.commit()
    return len(rows)

# ============================================================
# 翻页回溯拉取
# ============================================================
def deep_backfill(conn, coin, timeframe):
    """翻页拉取所有可用历史数据"""
    is_binance = coin in BINANCE_COINS
    source = "币安" if is_binance else "OKX"
    limit = BINANCE_LIMIT if is_binance else OKX_LIMIT
    
    # 获取已有最早时间戳
    cur = conn.execute(
        "SELECT MIN(ts), MAX(ts), COUNT(*) FROM klines WHERE coin=? AND timeframe=?",
        (coin, timeframe)
    ).fetchone()
    
    existing_min = cur[0]  # 可None
    existing_max = cur[1]
    existing_count = cur[2]
    
    total_new = 0
    page = 0
    end_time = None  # 币安用
    
    # 如果已有数据，从最早之前继续往前拉
    if existing_min:
        after = str(existing_min - 1)  # OKX: 从最早前1ms开始翻页
        if is_binance:
            end_time = existing_min - 1
    else:
        after = ""
    
    while True:
        page += 1
        
        if is_binance:
            candles = binance_fetch_page(coin, timeframe, limit, end_time)
        else:
            candles = okx_fetch_page(coin, timeframe, limit, after)
        
        if not candles:
            break
        
        saved = save_candles(conn, coin, timeframe, candles)
        total_new += saved
        
        if page % 5 == 0 or page == 1:
            first_ts = datetime.fromtimestamp(int(candles[0][0])/1000, BJT).strftime("%m-%d %H:%M")
            last_ts = datetime.fromtimestamp(int(candles[-1][0])/1000, BJT).strftime("%m-%d %H:%M")
            print(f"    page {page}: +{saved}根 ({last_ts} → {first_ts}) 累计+{total_new}")
        
        # 翻页条件
        if len(candles) < limit:
            break
        
        if is_binance:
            end_time = int(candles[-1][0]) - 1
            if end_time <= 0:
                break
        else:
            after = str(int(candles[-1][0]) - 1)
        
        time.sleep(0.12)
    
    return total_new

# ============================================================
# 也拉取最新的（填补后续时间段）
# ============================================================
def forward_fill(conn, coin, timeframe):
    """拉取最新的K线（覆盖最新可能遗漏的）"""
    is_binance = coin in BINANCE_COINS
    limit = 100 if is_binance else 300
    
    if is_binance:
        candles = binance_fetch_page(coin, timeframe, limit)
    else:
        candles = okx_fetch_page(coin, timeframe, limit)
    
    if not candles:
        return 0
    
    return save_candles(conn, coin, timeframe, candles)

# ============================================================
# Main
# ============================================================
def main():
    print("=" * 70)
    print("📡 全量K线翻页拉取（去重更新）")
    print(f"  数据库: {DB_PATH}")
    print(f"  币种: {COINS + BINANCE_COINS}")
    print(f"  周期: {TIMEFRAMES}")
    print(f"  开始: {datetime.now(BJT).strftime('%Y-%m-%d %H:%M:%S BJT')}")
    print("=" * 70)
    
    conn = sqlite3.connect(DB_PATH)
    conn.execute("PRAGMA journal_mode=WAL")
    conn.execute("PRAGMA synchronous=NORMAL")
    conn.execute("PRAGMA busy_timeout=5000")
    
    grand_total = 0
    
    for coin in BINANCE_COINS + COINS:  # LAB first (binance)
        source = "币安" if coin in BINANCE_COINS else "OKX"
        print(f"\n{'#'*60}")
        print(f"# {coin} ({source})")
        print(f"{'#'*60}")
        
        for tf in TIMEFRAMES:
            cur = conn.execute(
                "SELECT COUNT(*), MIN(ts), MAX(ts) FROM klines WHERE coin=? AND timeframe=?",
                (coin, tf)
            ).fetchone()
            
            existing = cur[0]
            min_ts = cur[1]
            max_ts = cur[2]
            
            if min_ts:
                min_str = datetime.fromtimestamp(min_ts/1000, BJT).strftime("%Y-%m-%d %H:%M")
                max_str = datetime.fromtimestamp(max_ts/1000, BJT).strftime("%Y-%m-%d %H:%M")
            else:
                min_str, max_str = "N/A", "N/A"
            
            print(f"\n  [{tf}] 现有{existing}根 ({min_str} ~ {max_str})")
            
            t0 = time.time()
            
            # 1. 翻页回溯拉取旧数据
            added_back = deep_backfill(conn, coin, tf)
            
            # 2. 前向拉取最新数据
            added_fwd = forward_fill(conn, coin, tf)
            
            total_added = added_back + added_fwd
            grand_total += total_added
            elapsed = time.time() - t0
            
            new_cur = conn.execute(
                "SELECT COUNT(*), MIN(ts), MAX(ts) FROM klines WHERE coin=? AND timeframe=?",
                (coin, tf)
            ).fetchone()
            
            new_min = datetime.fromtimestamp(new_cur[1]/1000, BJT).strftime("%Y-%m-%d %H:%M") if new_cur[1] else "N/A"
            new_max = datetime.fromtimestamp(new_cur[2]/1000, BJT).strftime("%Y-%m-%d %H:%M") if new_cur[2] else "N/A"
            
            if total_added > 0:
                print(f"    ✅ +{total_added}根 → {new_cur[0]}根 ({new_min} ~ {new_max}) {elapsed:.1f}s")
            else:
                print(f"    ✅ 已完整，无需更新 {elapsed:.1f}s")
    
    conn.close()
    
    # 最终统计
    print(f"\n{'='*70}")
    print(f"📊 总计新增: {grand_total} 根 K线")
    print(f"   完成时间: {datetime.now(BJT).strftime('%Y-%m-%d %H:%M:%S BJT')}")
    
    # 去重检查
    conn = sqlite3.connect(DB_PATH)
    dup_count = conn.execute(
        "SELECT COUNT(*) FROM (SELECT coin,timeframe,ts,COUNT(*) as c FROM klines GROUP BY coin,timeframe,ts HAVING c>1)"
    ).fetchone()[0]
    conn.close()
    print(f"   去重检查: {'✅ 无重复' if dup_count == 0 else f'⚠️ {dup_count}组重复'}")
    print("=" * 70)

if __name__ == "__main__":
    main()
