#!/usr/bin/env python3
"""
BTC 日线策略回测 — v5.0 候选策略验证 (修正版)
"""
import sqlite3
import numpy as np
import pandas as pd
from datetime import datetime
from collections import defaultdict

DB_PATH = '/root/.hermes/trade_review/okx_klines.db'
FEE = 0.0014  # 0.14% per trade

# ── 数据加载 ──
conn = sqlite3.connect(DB_PATH)
df = pd.read_sql_query(
    "SELECT ts, open, high, low, close, volume FROM klines "
    "WHERE coin='BTC' AND timeframe='1D' ORDER BY ts ASC",
    conn
)
conn.close()
df['ts'] = pd.to_datetime(df['ts'], unit='ms')
df = df.reset_index(drop=True)
print(f"Loaded {len(df)} daily bars: {df['ts'].min().date()} → {df['ts'].max().date()}")

# ── 技术指标 (修正版Wilder平滑) ──
def compute_indicators(df):
    N = len(df)
    df['body'] = np.abs(df['close'] - df['open'])
    df['upper_shadow'] = df['high'] - df[['open', 'close']].max(axis=1)
    df['lower_shadow'] = df[['open', 'close']].min(axis=1) - df['low']
    df['total_range'] = df['high'] - df['low']

    # EMA20
    df['ema20'] = df['close'].ewm(span=20, adjust=False).mean()
    
    # SMA20 volume and body
    df['sma20_vol'] = df['volume'].rolling(20, min_periods=1).mean()
    df['sma20_body'] = df['body'].rolling(20, min_periods=1).mean()
    
    # RSI(14) — Wilder smoothing, correct
    delta = df['close'].diff().values
    gain = np.maximum(delta, 0)
    loss = np.maximum(-delta, 0)
    n_rs = 14
    avg_gain = np.full(N, np.nan)
    avg_loss = np.full(N, np.nan)
    # First SMA at index n_rs (n_rs gains)
    if N > n_rs:
        avg_gain[n_rs] = np.mean(gain[1:n_rs+1])
        avg_loss[n_rs] = np.mean(loss[1:n_rs+1])
    for i in range(n_rs+1, N):
        avg_gain[i] = (avg_gain[i-1] * (n_rs-1) + gain[i]) / n_rs
        avg_loss[i] = (avg_loss[i-1] * (n_rs-1) + loss[i]) / n_rs
    rs = np.divide(avg_gain, avg_loss, out=np.zeros(N), where=avg_loss>0)
    df['rsi14'] = np.where(avg_loss > 0, 100 - (100 / (1 + rs)), 100)
    
    # ATR(14) — Wilder smoothing
    tr_arr = np.maximum(
        df['high'].values - df['low'].values,
        np.maximum(
            np.abs(df['high'].values - df['close'].shift(1).values),
            np.abs(df['low'].values - df['close'].shift(1).values)
        )
    )
    atr = np.full(N, np.nan)
    if N > 14:
        atr[14] = np.mean(tr_arr[1:15])
    for i in range(15, N):
        atr[i] = (atr[i-1] * 13 + tr_arr[i]) / 14
    df['atr14'] = atr
    
    # ADX(14) — Wilder
    up_move = df['high'].values - df['high'].shift(1).values
    down_move = df['low'].shift(1).values - df['low'].values
    plus_dm = np.where((up_move > down_move) & (up_move > 0), up_move, 0)
    minus_dm = np.where((down_move > up_move) & (down_move > 0), down_move, 0)
    
    plus_di = np.full(N, np.nan)
    minus_di = np.full(N, np.nan)
    atr14 = atr
    
    # First average at 14
    if N > 14:
        plus_di[14] = 100 * np.mean(plus_dm[1:15]) / atr14[14] if atr14[14] > 0 else 0
        minus_di[14] = 100 * np.mean(minus_dm[1:15]) / atr14[14] if atr14[14] > 0 else 0
    for i in range(15, N):
        if atr14[i] > 0:
            plus_di[i] = (plus_di[i-1] * 13 + 100 * plus_dm[i] / atr14[i]) / 14
            minus_di[i] = (minus_di[i-1] * 13 + 100 * minus_dm[i] / atr14[i]) / 14
        else:
            plus_di[i] = plus_di[i-1]
            minus_di[i] = minus_di[i-1]
    
    di_sum = plus_di + minus_di
    dx = np.where(di_sum > 0, 100 * np.abs(plus_di - minus_di) / di_sum, 0)
    
    adx = np.full(N, np.nan)
    if N > 28:
        adx[28] = np.mean(dx[15:29])
    for i in range(29, N):
        adx[i] = (adx[i-1] * 13 + dx[i]) / 14
    df['adx14'] = adx
    
    # Bollinger Bands
    df['bb_sma'] = df['close'].rolling(20, min_periods=1).mean()
    df['bb_std'] = df['close'].rolling(20, min_periods=1).std()
    df['bb_upper'] = df['bb_sma'] + 2 * df['bb_std']
    df['bb_lower'] = df['bb_sma'] - 2 * df['bb_std']
    df['bb_mid'] = df['bb_sma']
    df['bb_bandwidth'] = (df['bb_upper'] - df['bb_lower']) / df['bb_mid']
    
    # Bandwidth 120-day percentile
    df['bw_120_pct'] = df['bb_bandwidth'].rolling(120, min_periods=20).rank(pct=True)
    
    # 5-day extremes
    df['high_5d'] = df['high'].rolling(5, min_periods=1).max()
    df['low_5d'] = df['low'].rolling(5, min_periods=1).min()
    
    # Volume ratio
    df['vol_ratio'] = df['volume'] / df['sma20_vol']
    
    return df

print("Computing indicators...")
df = compute_indicators(df)

# Quick verify
print(f"RSI14 range: {df['rsi14'].min():.1f} to {df['rsi14'].max():.1f}")
print(f"RSI14 < 30 count: {(df['rsi14'] < 30).sum()}")
print(f"ADX14 valid: {df['adx14'].notna().sum()}")
print(f"ADX14 range: {df['adx14'].min():.1f} to {df['adx14'].max():.1f}")
print(f"ATR14 range: {df['atr14'].min():.0f} to {df['atr14'].max():.0f}")
print("Indicators computed.")

# ── 市场状态分类 ──
def classify_regime(df):
    df['sma200'] = df['close'].rolling(200, min_periods=20).mean()
    df['sma200_slope'] = df['sma200'].diff(20) / df['sma200'].shift(20)
    
    regimes = []
    for i in range(len(df)):
        sl = df['sma200_slope'].iloc[i]
        if pd.isna(sl):
            regimes.append('unknown')
        elif sl > 0.02:
            regimes.append('bull')
        elif sl < -0.02:
            regimes.append('bear')
        else:
            regimes.append('sideways')
    df['regime'] = regimes
    return df

df = classify_regime(df)
print(f"Regime: {df['regime'].value_counts().to_dict()}")

# ── 回测工具 ──
def run_trades_long(df, signals, max_hold, tp_pct=None, sl_pct=None, sl_fn=None, use_tp_atr=False, tp_atr_mult=None, use_sl_atr=False, sl_atr_mult=None):
    """
    Generic long-only backtest.
    signals: bool array at entry bar i
    Entry at bar i+1 open
    """
    trades = []
    in_pos = False
    entry_bar = None
    entry_price = None
    sl_price = None
    tp_price = None
    
    for i in range(len(df)):
        if in_pos:
            hold_days = i - entry_bar
            exit_price = None
            
            # Check SL
            if df['low'].iloc[i] <= sl_price:
                exit_price = sl_price
            # Check TP
            elif tp_price and df['high'].iloc[i] >= tp_price:
                exit_price = tp_price
            # Max hold
            elif hold_days >= max_hold:
                exit_price = df['close'].iloc[i]
            
            if exit_price is not None:
                gross_ret = (exit_price - entry_price) / entry_price
                net_ret = gross_ret - FEE
                trades.append({
                    'entry_ts': df['ts'].iloc[entry_bar],
                    'exit_ts': df['ts'].iloc[i],
                    'entry_price': entry_price,
                    'exit_price': exit_price,
                    'hold_days': i - entry_bar,
                    'gross_ret': gross_ret,
                    'net_ret': net_ret,
                    'regime': df['regime'].iloc[entry_bar],
                    'win': net_ret > 0,
                    'exit_reason': 'sl' if exit_price == sl_price else ('tp' if tp_price and exit_price == tp_price else 'time'),
                })
                in_pos = False
        else:
            if signals[i] and i + 1 < len(df):
                entry_bar = i
                entry_price = df['open'].iloc[i + 1]
                
                if sl_fn:
                    sl_price = sl_fn(df, i, entry_price)
                elif use_sl_atr:
                    sl_price = entry_price - sl_atr_mult * df['atr14'].iloc[i]
                elif sl_pct:
                    sl_price = entry_price * (1 - sl_pct)
                else:
                    sl_price = df['low'].iloc[i]
                
                if use_tp_atr:
                    tp_price = entry_price + tp_atr_mult * df['atr14'].iloc[i]
                elif tp_pct:
                    tp_price = entry_price * (1 + tp_pct)
                else:
                    tp_price = None
                
                in_pos = True
    
    return trades


def run_trades_both(df, signals_long, signals_short, max_hold, sl_fn_long=None, sl_fn_short=None, tp_fn_long=None, tp_fn_short=None):
    """Combined long/short backtest."""
    trades = []
    in_pos = False
    pos_type = None
    entry_bar = None
    entry_price = None
    sl_price = None
    tp_price = None
    
    for i in range(len(df)):
        if in_pos:
            hold_days = i - entry_bar
            exit_price = None
            
            if pos_type == 'long':
                if df['low'].iloc[i] <= sl_price:
                    exit_price = sl_price
                elif tp_price and df['high'].iloc[i] >= tp_price:
                    exit_price = tp_price
                elif hold_days >= max_hold:
                    exit_price = df['close'].iloc[i]
            else:  # short
                if df['high'].iloc[i] >= sl_price:
                    exit_price = sl_price
                elif tp_price and df['low'].iloc[i] <= tp_price:
                    exit_price = tp_price
                elif hold_days >= max_hold:
                    exit_price = df['close'].iloc[i]
            
            if exit_price is not None:
                if pos_type == 'long':
                    gross_ret = (exit_price - entry_price) / entry_price
                else:
                    gross_ret = (entry_price - exit_price) / entry_price
                net_ret = gross_ret - FEE
                trades.append({
                    'entry_ts': df['ts'].iloc[entry_bar],
                    'exit_ts': df['ts'].iloc[i],
                    'entry_price': entry_price,
                    'exit_price': exit_price,
                    'hold_days': i - entry_bar,
                    'gross_ret': gross_ret,
                    'net_ret': net_ret,
                    'regime': df['regime'].iloc[entry_bar],
                    'win': net_ret > 0,
                    'type': pos_type,
                })
                in_pos = False
        else:
            if i + 1 >= len(df):
                continue
            entry_bar = i
            entry_price = df['open'].iloc[i + 1]
            
            if signals_long[i]:
                pos_type = 'long'
                sl_price = sl_fn_long(df, i, entry_price) if sl_fn_long else entry_price * 0.95
                tp_price = tp_fn_long(df, i, entry_price) if tp_fn_long else None
                in_pos = True
            elif signals_short[i]:
                pos_type = 'short'
                sl_price = sl_fn_short(df, i, entry_price) if sl_fn_short else entry_price * 1.05
                tp_price = tp_fn_short(df, i, entry_price) if tp_fn_short else None
                in_pos = True
    
    return trades


def analyze_trades(trades, name):
    if not trades:
        print(f"\n{'='*60}")
        print(f"  {name}: NO TRADES")
        print(f"{'='*60}")
        return None
    
    n = len(trades)
    win_rate = sum(1 for t in trades if t['win']) / n
    avg_net = np.mean([t['net_ret'] for t in trades])
    avg_hold = np.mean([t['hold_days'] for t in trades])
    
    # Max drawdown
    cumulative = np.cumprod([1 + t['net_ret'] for t in trades])
    peak = np.maximum.accumulate(cumulative)
    drawdown = (cumulative - peak) / peak
    max_dd = drawdown.min()
    
    rets = [t['net_ret'] for t in trades]
    sharpe = np.mean(rets) / np.std(rets) * np.sqrt(365 / max(avg_hold, 0.1)) if np.std(rets) > 0 else 0
    
    print(f"\n{'='*60}")
    print(f"  📊 {name}")
    print(f"{'='*60}")
    print(f"  信号/交易次数: {n}")
    print(f"  胜率: {win_rate:.1%}")
    print(f"  税后平均收益: {avg_net:.4%}")
    print(f"  平均持有天数: {avg_hold:.1f}")
    print(f"  最大回撤: {max_dd:.2%}")
    print(f"  年化Sharpe(近似): {sharpe:.2f}")
    
    # By regime
    regimes = defaultdict(list)
    for t in trades:
        regimes[t['regime']].append(t['net_ret'])
    
    print(f"  分市场状态:")
    for reg in ['bull', 'bear', 'sideways', 'unknown']:
        if reg in regimes and regimes[reg]:
            r = regimes[reg]
            wr = sum(1 for x in r if x > 0) / len(r)
            print(f"    {reg:>8}: 次数={len(r)}, 胜率={wr:.1%}, 均值={np.mean(r):.4%}")
        elif reg in ['bull', 'bear', 'sideways']:
            print(f"    {reg:>8}: 无信号")
    
    wins = [t['net_ret'] for t in trades if t['win']]
    losses = [t['net_ret'] for t in trades if not t['win']]
    if wins:
        print(f"  盈利均值: {np.mean(wins):.4%} (最大: {max(wins):.4%})")
    if losses:
        print(f"  亏损均值: {np.mean(losses):.4%} (最小: {min(losses):.4%})")
    
    # Exit reason distribution
    reasons = defaultdict(int)
    for t in trades:
        reasons[t.get('exit_reason', 'unknown')] += 1
    if len(reasons) > 1:
        print(f"  退出原因: {dict(reasons)}")
    
    return {
        'name': name,
        'count': n,
        'win_rate': win_rate,
        'avg_net_ret': avg_net,
        'avg_hold': avg_hold,
        'max_dd': max_dd,
        'sharpe': sharpe,
        'trades': trades,
        'by_regime': {r: {
            'count': len(regimes.get(r, [])),
            'win_rate': sum(1 for x in regimes.get(r, []) if x > 0) / max(len(regimes.get(r, [])), 1),
            'avg_ret': np.mean(regimes[r]) if r in regimes else 0
        } for r in ['bull', 'bear', 'sideways']},
        'qualified': avg_net > 0 and win_rate >= 0.55
    }


# ═════════════════════════════════════════════════════════════
#  策略1: Spring做多
# ═════════════════════════════════════════════════════════════
def strategy_1_spring(df):
    signals = np.zeros(len(df), dtype=bool)
    for i in range(5, len(df)):
        # 前5日至少3日阴线
        bear_days = sum(1 for j in range(i-5, i) if df['close'].iloc[j] < df['open'].iloc[j])
        if bear_days < 3:
            continue
        # 今日最低 < 前日收盘 (假跌破)
        if df['low'].iloc[i] >= df['close'].iloc[i-1]:
            continue
        # 今日收阳
        if df['close'].iloc[i] <= df['open'].iloc[i]:
            continue
        # 下影 > 实体×2
        body = df['body'].iloc[i]
        lower_shadow = df['lower_shadow'].iloc[i]
        if body == 0 or lower_shadow <= body * 2:
            continue
        # 量 > 前20日均量×1.5
        if pd.isna(df['sma20_vol'].iloc[i]) or df['volume'].iloc[i] <= df['sma20_vol'].iloc[i] * 1.5:
            continue
        signals[i] = True
    
    def sl_fn(df, i, entry):
        return df['low'].iloc[i] * 0.98
    
    return run_trades_long(df, signals, max_hold=5, tp_pct=0.05, sl_fn=sl_fn)


# ═════════════════════════════════════════════════════════════
#  策略2: 努力无果反转 (多空双向)
# ═════════════════════════════════════════════════════════════
def strategy_2_effortless(df):
    signals_long = np.zeros(len(df), dtype=bool)
    signals_short = np.zeros(len(df), dtype=bool)
    
    for i in range(20, len(df)):
        if pd.isna(df['sma20_vol'].iloc[i]) or pd.isna(df['sma20_body'].iloc[i]):
            continue
        # 量 > 20日均量×2
        if df['volume'].iloc[i] <= df['sma20_vol'].iloc[i] * 2:
            continue
        # 实体 < 前20日平均实体×0.5
        if df['body'].iloc[i] >= df['sma20_body'].iloc[i] * 0.5:
            continue
        # 方向判断
        in_downtrend = all(df['close'].iloc[j] < df['ema20'].iloc[j] for j in range(i-10, i) if not pd.isna(df['ema20'].iloc[j]))
        in_uptrend = all(df['close'].iloc[j] > df['ema20'].iloc[j] for j in range(i-10, i) if not pd.isna(df['ema20'].iloc[j]))
        
        if in_downtrend:
            signals_long[i] = True  # 做多反转
        elif in_uptrend:
            signals_short[i] = True  # 做空反转
    
    def sl_fn_long(df, i, entry):
        return min(df['low'].iloc[i], entry * 0.97)
    
    def sl_fn_short(df, i, entry):
        return max(df['high'].iloc[i], entry * 1.03)
    
    def tp_fn_long(df, i, entry):
        return entry * 1.03
    
    def tp_fn_short(df, i, entry):
        return entry * 0.97
    
    return run_trades_both(df, signals_long, signals_short, max_hold=3,
                          sl_fn_long=sl_fn_long, sl_fn_short=sl_fn_short,
                          tp_fn_long=tp_fn_long, tp_fn_short=tp_fn_short)


# ═════════════════════════════════════════════════════════════
#  策略3: ADX沉睡觉醒 (多空双向)
# ═════════════════════════════════════════════════════════════
def strategy_3_adx_wakeup(df):
    signals_long = np.zeros(len(df), dtype=bool)
    signals_short = np.zeros(len(df), dtype=bool)
    
    for i in range(30, len(df)):
        if pd.isna(df['adx14'].iloc[i]) or pd.isna(df['adx14'].iloc[i-1]):
            continue
        # ADX突破20
        if df['adx14'].iloc[i-1] >= 20 or df['adx14'].iloc[i] <= 20:
            continue
        # Direction
        if df['close'].iloc[i] > df['high_5d'].iloc[i-1]:
            signals_long[i] = True
        elif df['close'].iloc[i] < df['low_5d'].iloc[i-1]:
            signals_short[i] = True
    
    def sl_fn_long(df, i, entry):
        return entry - 2 * df['atr14'].iloc[i]
    def tp_fn_long(df, i, entry):
        return entry + 3 * df['atr14'].iloc[i]
    def sl_fn_short(df, i, entry):
        return entry + 2 * df['atr14'].iloc[i]
    def tp_fn_short(df, i, entry):
        return entry - 3 * df['atr14'].iloc[i]
    
    return run_trades_both(df, signals_long, signals_short, max_hold=5,
                          sl_fn_long=sl_fn_long, sl_fn_short=sl_fn_short,
                          tp_fn_long=tp_fn_long, tp_fn_short=tp_fn_short)


# ═════════════════════════════════════════════════════════════
#  策略4: 减速+恐慌反弹
# ═════════════════════════════════════════════════════════════
def strategy_4_deceleration_panic(df):
    signals = np.zeros(len(df), dtype=bool)
    for i in range(3, len(df)):
        if pd.isna(df['rsi14'].iloc[i]):
            continue
        prev_body = df['body'].iloc[i-1]
        prev2_body = df['body'].iloc[i-2]
        cur_body = df['body'].iloc[i]
        if prev2_body == 0 or prev_body == 0:
            continue
        # 加速: 前日 > 前前日×2
        if prev_body <= prev2_body * 2:
            continue
        # 减速: 今日 < 前日×0.3
        if cur_body >= prev_body * 0.3:
            continue
        # RSI < 25
        if df['rsi14'].iloc[i] >= 25:
            continue
        # Ensure bearish context
        if df['close'].iloc[i] >= df['close'].iloc[i-1]:
            continue
        signals[i] = True
    
    def sl_fn(df, i, entry):
        return df['low'].iloc[i] * 0.97
    
    return run_trades_long(df, signals, max_hold=5, tp_pct=0.04, sl_fn=sl_fn)


# ═════════════════════════════════════════════════════════════
#  策略5: 布林收口突破 (多空双向)
# ═════════════════════════════════════════════════════════════
def strategy_5_bb_squeeze(df):
    signals_long = np.zeros(len(df), dtype=bool)
    signals_short = np.zeros(len(df), dtype=bool)
    
    for i in range(120, len(df)):
        if pd.isna(df['bw_120_pct'].iloc[i]) or pd.isna(df['sma20_vol'].iloc[i]):
            continue
        # Bandwidth bottom 10%
        if df['bw_120_pct'].iloc[i] > 0.10:
            continue
        # Volume
        if df['volume'].iloc[i] <= df['sma20_vol'].iloc[i] * 1.5:
            continue
        # Breakout
        if df['close'].iloc[i] > df['bb_upper'].iloc[i]:
            signals_long[i] = True
        elif df['close'].iloc[i] < df['bb_lower'].iloc[i]:
            signals_short[i] = True
    
    def sl_fn_long(df, i, entry):
        return df['bb_mid'].iloc[i]
    def tp_fn_long(df, i, entry):
        return entry * (1 + df['bb_bandwidth'].iloc[i] * 1.5)
    def sl_fn_short(df, i, entry):
        return df['bb_mid'].iloc[i]
    def tp_fn_short(df, i, entry):
        return entry * (1 - df['bb_bandwidth'].iloc[i] * 1.5)
    
    return run_trades_both(df, signals_long, signals_short, max_hold=5,
                          sl_fn_long=sl_fn_long, sl_fn_short=sl_fn_short,
                          tp_fn_long=tp_fn_long, tp_fn_short=tp_fn_short)


# ═════════════════════════════════════════════════════════════
#  策略6: 费率极端 + K线确认
# ═════════════════════════════════════════════════════════════
def strategy_6_extreme_funding(df):
    signals = np.zeros(len(df), dtype=bool)
    for i in range(4, len(df)):
        if pd.isna(df['rsi14'].iloc[i]) or pd.isna(df['sma20_vol'].iloc[i]):
            continue
        # 连续3日以上下跌
        if not (df['close'].iloc[i-1] < df['close'].iloc[i-2] and 
                df['close'].iloc[i-2] < df['close'].iloc[i-3]):
            continue
        # RSI < 30
        if df['rsi14'].iloc[i] >= 30:
            continue
        # 今日收阳
        if df['close'].iloc[i] <= df['open'].iloc[i]:
            continue
        # 实体 > 总长×0.5
        if df['body'].iloc[i] <= df['total_range'].iloc[i] * 0.5:
            continue
        # 量 > 20日均量
        if df['volume'].iloc[i] <= df['sma20_vol'].iloc[i]:
            continue
        signals[i] = True
    
    def sl_fn(df, i, entry):
        return df['low'].iloc[i] * 0.97
    
    return run_trades_long(df, signals, max_hold=5, tp_pct=0.05, sl_fn=sl_fn)


# ═════════════════════════════════════════════════════════════
#  运行所有策略
# ═════════════════════════════════════════════════════════════
print("\n" + "="*70)
print("  🧪 开始回测6个候选策略")
print("="*70)

results = []

t1 = strategy_1_spring(df)
r1 = analyze_trades(t1, "策略1: Spring做多")
if r1: results.append(r1)

t2 = strategy_2_effortless(df)
r2 = analyze_trades(t2, "策略2: 努力无果反转(多空)")
if r2: results.append(r2)

t3 = strategy_3_adx_wakeup(df)
r3 = analyze_trades(t3, "策略3: ADX沉睡觉醒(多空)")
if r3: results.append(r3)

t4 = strategy_4_deceleration_panic(df)
r4 = analyze_trades(t4, "策略4: 减速+恐慌反弹")
if r4: results.append(r4)

t5 = strategy_5_bb_squeeze(df)
r5 = analyze_trades(t5, "策略5: 布林收口突破(多空)")
if r5: results.append(r5)

t6 = strategy_6_extreme_funding(df)
r6 = analyze_trades(t6, "策略6: 费率极端+K线确认")
if r6: results.append(r6)


# ═════════════════════════════════════════════════════════════
#  汇总
# ═════════════════════════════════════════════════════════════
print("\n" + "="*70)
print("  📋 汇总: 税后均值>0 且 胜率>55% 的策略")
print("="*70)

qualified = [r for r in results if r and r['qualified']]
for r in results:
    if r is None:
        continue
    status = "✅ 合格" if r['qualified'] else "❌ 不合格"
    print(f"  {status} | {r['name']:35s} | 次数={r['count']:3d} | 胜率={r['win_rate']:.1%} | 均值={r['avg_net_ret']:.4%} | 回撤={r['max_dd']:.2%}")

if qualified:
    print(f"\n  🎯 共 {len(qualified)} 个策略通过筛选，可考虑实盘:")
    for r in qualified:
        print(f"     • {r['name']}: 胜率{r['win_rate']:.1%} 均值{r['avg_net_ret']:.4%}")
else:
    print(f"\n  ⚠️ 无策略通过原始筛选标准")

# If no strategies qualified, try relaxing conditions (parameter optimization)
print("\n" + "="*70)
print("  🔧 参数优化: 放宽条件重测")
print("="*70)

# ── 策略1 放宽: 降低量要求到1.2x, 下影要求到1.5x ──
def s1_relaxed(df, vol_mult=1.2, shadow_mult=1.5):
    signals = np.zeros(len(df), dtype=bool)
    for i in range(5, len(df)):
        bear_days = sum(1 for j in range(i-5, i) if df['close'].iloc[j] < df['open'].iloc[j])
        if bear_days < 3:
            continue
        if df['low'].iloc[i] >= df['close'].iloc[i-1]:
            continue
        if df['close'].iloc[i] <= df['open'].iloc[i]:
            continue
        body = df['body'].iloc[i]
        if body == 0 or df['lower_shadow'].iloc[i] <= body * shadow_mult:
            continue
        if pd.isna(df['sma20_vol'].iloc[i]) or df['volume'].iloc[i] <= df['sma20_vol'].iloc[i] * vol_mult:
            continue
        signals[i] = True
    def sl_fn(df, i, entry):
        return df['low'].iloc[i] * 0.98
    return run_trades_long(df, signals, max_hold=5, tp_pct=0.05, sl_fn=sl_fn)

for vm in [1.5, 1.3, 1.2, 1.0]:
    t = s1_relaxed(df, vol_mult=vm, shadow_mult=2.0)
    if t:
        wr = sum(1 for x in t if x['win']) / len(t)
        avg = np.mean([x['net_ret'] for x in t])
        print(f"  S1 vol×{vm}: 次数={len(t)}, 胜率={wr:.1%}, 均值={avg:.4%}")

# ── 策略4 放宽RSI ──
def s4_relaxed(df, rsi_thresh=25):
    signals = np.zeros(len(df), dtype=bool)
    for i in range(3, len(df)):
        if pd.isna(df['rsi14'].iloc[i]):
            continue
        prev_body = df['body'].iloc[i-1]
        prev2_body = df['body'].iloc[i-2]
        cur_body = df['body'].iloc[i]
        if prev2_body == 0 or prev_body == 0:
            continue
        if prev_body <= prev2_body * 2:
            continue
        if cur_body >= prev_body * 0.3:
            continue
        if df['rsi14'].iloc[i] >= rsi_thresh:
            continue
        if df['close'].iloc[i] >= df['close'].iloc[i-1]:
            continue
        signals[i] = True
    def sl_fn(df, i, entry):
        return df['low'].iloc[i] * 0.97
    return run_trades_long(df, signals, max_hold=5, tp_pct=0.04, sl_fn=sl_fn)

for rsi_t in [25, 30, 35, 40]:
    t = s4_relaxed(df, rsi_thresh=rsi_t)
    if t:
        wr = sum(1 for x in t if x['win']) / len(t)
        avg = np.mean([x['net_ret'] for x in t])
        print(f"  S4 RSI<{rsi_t}: 次数={len(t)}, 胜率={wr:.1%}, 均值={avg:.4%}")

# ── 策略6 放宽RSI ──
def s6_relaxed(df, rsi_thresh=30):
    signals = np.zeros(len(df), dtype=bool)
    for i in range(4, len(df)):
        if pd.isna(df['rsi14'].iloc[i]) or pd.isna(df['sma20_vol'].iloc[i]):
            continue
        if not (df['close'].iloc[i-1] < df['close'].iloc[i-2] and 
                df['close'].iloc[i-2] < df['close'].iloc[i-3]):
            continue
        if df['rsi14'].iloc[i] >= rsi_thresh:
            continue
        if df['close'].iloc[i] <= df['open'].iloc[i]:
            continue
        if df['body'].iloc[i] <= df['total_range'].iloc[i] * 0.5:
            continue
        if df['volume'].iloc[i] <= df['sma20_vol'].iloc[i]:
            continue
        signals[i] = True
    def sl_fn(df, i, entry):
        return df['low'].iloc[i] * 0.97
    return run_trades_long(df, signals, max_hold=5, tp_pct=0.05, sl_fn=sl_fn)

for rsi_t in [30, 35, 40, 45]:
    t = s6_relaxed(df, rsi_thresh=rsi_t)
    if t:
        wr = sum(1 for x in t if x['win']) / len(t)
        avg = np.mean([x['net_ret'] for x in t])
        print(f"  S6 RSI<{rsi_t}: 次数={len(t)}, 胜率={wr:.1%}, 均值={avg:.4%}")

# ── 策略3 放宽ADX阈值 ──
def s3_relaxed(df, adx_thresh=20, adx_yesterday_thresh=20):
    signals_long = np.zeros(len(df), dtype=bool)
    signals_short = np.zeros(len(df), dtype=bool)
    for i in range(30, len(df)):
        if pd.isna(df['adx14'].iloc[i]) or pd.isna(df['adx14'].iloc[i-1]):
            continue
        if df['adx14'].iloc[i-1] >= adx_yesterday_thresh or df['adx14'].iloc[i] <= adx_thresh:
            continue
        if df['close'].iloc[i] > df['high_5d'].iloc[i-1]:
            signals_long[i] = True
        elif df['close'].iloc[i] < df['low_5d'].iloc[i-1]:
            signals_short[i] = True
    
    def sl_fn_long(df, i, entry):
        return entry - 2 * df['atr14'].iloc[i]
    def tp_fn_long(df, i, entry):
        return entry + 3 * df['atr14'].iloc[i]
    def sl_fn_short(df, i, entry):
        return entry + 2 * df['atr14'].iloc[i]
    def tp_fn_short(df, i, entry):
        return entry - 3 * df['atr14'].iloc[i]
    return run_trades_both(df, signals_long, signals_short, max_hold=5,
                          sl_fn_long=sl_fn_long, sl_fn_short=sl_fn_short,
                          tp_fn_long=tp_fn_long, tp_fn_short=tp_fn_short)

for thresh in [(20, 20), (18, 18), (15, 15), (20, 25), (25, 25)]:
    t = s3_relaxed(df, adx_thresh=thresh[0], adx_yesterday_thresh=thresh[1])
    if t:
        wr = sum(1 for x in t if x['win']) / len(t)
        avg = np.mean([x['net_ret'] for x in t])
        print(f"  S3 ADX>{thresh[0]}, yday<{thresh[1]}: 次数={len(t)}, 胜率={wr:.1%}, 均值={avg:.4%}")

# ── 策略5 放宽带宽分位 ──
def s5_relaxed(df, pct=0.10, vol_mult=1.5):
    signals_long = np.zeros(len(df), dtype=bool)
    signals_short = np.zeros(len(df), dtype=bool)
    for i in range(120, len(df)):
        if pd.isna(df['bw_120_pct'].iloc[i]) or pd.isna(df['sma20_vol'].iloc[i]):
            continue
        if df['bw_120_pct'].iloc[i] > pct:
            continue
        if df['volume'].iloc[i] <= df['sma20_vol'].iloc[i] * vol_mult:
            continue
        if df['close'].iloc[i] > df['bb_upper'].iloc[i]:
            signals_long[i] = True
        elif df['close'].iloc[i] < df['bb_lower'].iloc[i]:
            signals_short[i] = True
    
    def sl_fn_long(df, i, entry):
        return df['bb_mid'].iloc[i]
    def tp_fn_long(df, i, entry):
        return entry * (1 + df['bb_bandwidth'].iloc[i] * 1.5)
    def sl_fn_short(df, i, entry):
        return df['bb_mid'].iloc[i]
    def tp_fn_short(df, i, entry):
        return entry * (1 - df['bb_bandwidth'].iloc[i] * 1.5)
    return run_trades_both(df, signals_long, signals_short, max_hold=5,
                          sl_fn_long=sl_fn_long, sl_fn_short=sl_fn_short,
                          tp_fn_long=tp_fn_long, tp_fn_short=tp_fn_short)

for pct in [0.10, 0.15, 0.20, 0.25]:
    t = s5_relaxed(df, pct=pct, vol_mult=1.2)
    if t:
        wr = sum(1 for x in t if x['win']) / len(t)
        avg = np.mean([x['net_ret'] for x in t])
        print(f"  S5 BW<{pct:.0%}: 次数={len(t)}, 胜率={wr:.1%}, 均值={avg:.4%}")

print("\nDone.")
