#!/usr/bin/env python3
"""
开仓方案回测 — 对比 4 种开仓信号 + D_ATR20 SL/TP
方案:
  0_当前: 共振≥2偏强/≤-2偏弱 + near_bottom + RSI_1D趋势
  1_降门槛: 共振≥1偏强/≤-1偏弱
  2_加指标: ADX+VP 5指标共振
  4_趋势过滤: 1D趋势 + 4H MACD + VP位置

SL/TP统一用 D_ATR20: SL=entry±2ATR, TP=entry±4ATR, RR=2
输出: /tmp/signal_backtest.json
"""
import json, sqlite3, sys, os
from datetime import datetime, timezone, timedelta
from collections import defaultdict
sys.path.insert(0, '/root/.hermes/trade_review')
from _shared import BJT, ema as _ema, calc_rsi as _calc_rsi_list

DB = '/root/.hermes/trade_review/okx_klines.db'
OUT = '/tmp/signal_backtest.json'
MAX_TRACK_H = 168

def load_all_1h(db, coin):
    rows = db.execute("""
        SELECT ts, open, high, low, close FROM klines
        WHERE coin=? AND timeframe='1H' ORDER BY ts ASC
    """, (coin,)).fetchall()
    return rows

def calc_ema(data, period):
    if len(data) < 2: return [data[0]] if data else []
    k = 2.0/(period+1)
    r = [data[0]]
    for i in range(1,len(data)): r.append(data[i]*k + r[-1]*(1-k))
    return r

def calc_atr(highs, lows, closes, period=14):
    if len(closes) < period+1: return 0
    tr = []
    for i in range(1, len(closes)):
        tr.append(max(highs[i]-lows[i], abs(highs[i]-closes[i-1]), abs(lows[i]-closes[i-1])))
    if len(tr) < period: return sum(tr)/len(tr)
    atr = sum(tr[:period])/period
    for i in range(period, len(tr)): atr = (atr*(period-1)+tr[i])/period
    return atr

def calc_adx(highs, lows, closes, period=14):
    """简化ADX: 只用+DI/-DI差值"""
    if len(closes) < period+1: return 0
    tr_list, plus_dm, minus_dm = [], [], []
    for i in range(1, len(closes)):
        tr = max(highs[i]-lows[i], abs(highs[i]-closes[i-1]), abs(lows[i]-closes[i-1]))
        tr_list.append(tr)
        up = highs[i]-highs[i-1] if i>0 else 0
        down = lows[i-1]-lows[i] if i>0 else 0
        plus_dm.append(up if up>down and up>0 else 0)
        minus_dm.append(down if down>up and down>0 else 0)
    if len(tr_list) < period: return 0
    atr_s = sum(tr_list[:period])/period
    pdi = sum(plus_dm[:period])/period/atr_s*100 if atr_s>0 else 0
    mdi = sum(minus_dm[:period])/period/atr_s*100 if atr_s>0 else 0
    for i in range(period, len(tr_list)):
        atr_s = (atr_s*(period-1)+tr_list[i])/period
        pdi = (pdi*(period-1)+plus_dm[i])/period/atr_s*100 if atr_s>0 else pdi
        mdi = (mdi*(period-1)+minus_dm[i])/period/atr_s*100 if atr_s>0 else mdi
    return pdi - mdi  # +DI - -DI: positive=uptrend strength, negative=downtrend

def track_outcomes(highs, lows, idx, direction):
    """D_ATR20: SL=entry±2ATR, TP=entry±4ATR"""
    entry = closes_all[idx] if 'closes_all' in dir() else 0
    # 传入参数在外层
    return None  # handled inline

def backtest_coin(coin, rows):
    timestamps = [r[0] for r in rows]
    highs = [r[2] for r in rows]
    lows = [r[3] for r in rows]
    closes = [r[4] for r in rows]
    
    stats = defaultdict(lambda: {'total':0,'tp':0,'sl':0,'open':0,'tp_bars':[],'sl_bars':[]})
    
    for i in range(100, len(rows)-MAX_TRACK_H):
        close_hist = closes[i-50:i+1]
        high_hist = highs[i-50:i+1]
        low_hist = lows[i-50:i+1]
        if len(close_hist) < 50: continue
        
        entry = closes[i]
        
        # === 通用指标 ===
        rsi_list = _calc_rsi_list(close_hist, 14)
        rsi_4h = rsi_list[-1] if rsi_list and rsi_list[-1] is not None else 50
        
        ema_f = calc_ema(close_hist, 12)
        ema_s = calc_ema(close_hist, 75)
        macd_line = [f-s for f,s in zip(ema_f, ema_s)]
        ema_sig = calc_ema(macd_line, 9)
        macd_h = macd_line[-1] - ema_sig[-1] if ema_sig and macd_line else 0
        
        atr = calc_atr(high_hist, low_hist, close_hist, 14)
        if atr <= 0: atr = entry * 0.005
        
        # 日线趋势 (用1H近似: 过去96根的方向)
        close_96 = closes[max(0,i-96):i+1]
        trend_1d = '上升' if close_96[-1] > close_96[0] else '下降'
        
        # %b 近似
        std_20 = (sum((x-sum(close_hist[-20:])/20)**2 for x in close_hist[-20:])/20)**0.5 if len(close_hist)>=20 else 0
        ma_20 = sum(close_hist[-20:])/20 if len(close_hist)>=20 else entry
        pct_b = (entry - (ma_20-2*std_20)) / (4*std_20) * 100 if std_20 > 0 else 50
        
        # ADX
        adx_val = calc_adx(high_hist, low_hist, close_hist, 14)
        
        # VP边界
        vp_hist = 24
        val = min(lows[max(0,i-vp_hist):i+1])
        vah = max(highs[max(0,i-vp_hist):i+1])
        
        # RSI_1D (用96H近似)
        close_1d_hist = closes[max(0,i-96):i+1]
        rsi_1d_list = _calc_rsi_list(close_1d_hist, 14)
        rsi_1d = rsi_1d_list[-1] if rsi_1d_list and rsi_1d_list[-1] is not None else 50
        
        # === 方案 0: 当前 ===
        score0 = 0
        if rsi_4h > 55: score0 += 1
        elif rsi_4h < 45: score0 -= 1
        if macd_h > 0: score0 += 1
        elif macd_h < 0: score0 -= 1
        if pct_b < 30: score0 -= 1
        elif pct_b > 70: score0 += 1
        
        sig0 = None
        if score0 >= 2: sig0 = 'long'
        elif score0 <= -2: sig0 = 'short'
        elif rsi_1d > 67 and trend_1d in ('下降', '偏空') and macd_h < 0: sig0 = 'short'
        
        # === 方案 1: 降门槛 ===
        sig1 = None
        if score0 >= 1: sig1 = 'long'
        elif score0 <= -1: sig1 = 'short'
        elif rsi_1d > 67 and trend_1d in ('下降', '偏空') and macd_h < 0: sig1 = 'short'
        
        # === 方案 2: 加指标(ADX+VP) ===
        score2 = score0  # 先复用3指标结果
        if adx_val > 25 and macd_h > 0: score2 += 1
        elif adx_val > 25 and macd_h < 0: score2 -= 1
        if entry < val: score2 += 1
        elif entry > vah: score2 -= 1
        
        sig2 = None
        if score2 >= 2: sig2 = 'long'
        elif score2 <= -2: sig2 = 'short'
        
        # === 方案 4: 趋势过滤 ===
        sig4 = None
        if trend_1d == '上升' and macd_h > 0 and entry > val:
            sig4 = 'long'
        elif trend_1d == '下降' and macd_h < 0 and entry < vah:
            sig4 = 'short'
        
        # D_ATR20 SL/TP
        signals = [
            ('0_当前', sig0),
            ('1_降门槛', sig1),
            ('2_加指标', sig2),
            ('4_趋势过滤', sig4),
        ]
        
        for mname, direction in signals:
            if not direction: continue
            
            sl = entry - 2.0*atr if direction=='long' else entry + 2.0*atr
            tp = entry + 4.0*atr if direction=='long' else entry - 4.0*atr
            if abs(entry-sl) <= 0: continue
            
            # 追踪
            found = None
            for j in range(i+1, len(highs)):
                h, l = highs[j], lows[j]
                if direction == 'long':
                    if l <= sl: found = ('sl', j-i, sl); break
                    if h >= tp: found = ('tp', j-i, tp); break
                else:
                    if h >= sl: found = ('sl', j-i, sl); break
                    if l <= tp: found = ('tp', j-i, tp); break
            if not found: found = ('open', len(highs)-i-1, 0)
            
            s = stats[mname]
            s['total'] += 1
            result, bars, price = found
            if result == 'tp': s['tp'] += 1; s['tp_bars'].append(bars)
            elif result == 'sl': s['sl'] += 1; s['sl_bars'].append(bars)
            else: s['open'] += 1
    
    return stats

def main():
    db = sqlite3.connect(DB)
    all_stats = defaultdict(lambda: {'total':0,'tp':0,'sl':0,'open':0,'tp_bars':[],'sl_bars':[]})
    
    for coin in ['BTC', 'ETH']:
        rows = load_all_1h(db, coin)
        if not rows: continue
        print(f'{coin}: {len(rows)} 根1H, 扫描中...')
        coin_stats = backtest_coin(coin, rows)
        for k, v in coin_stats.items():
            for kk in ('total','tp','sl','open'): all_stats[k][kk] += v[kk]
            all_stats[k]['tp_bars'].extend(v['tp_bars'])
            all_stats[k]['sl_bars'].extend(v['sl_bars'])
    
    print(f"\n{'='*95}")
    print("开仓方案回测 (SL/TP统一=D_ATR20: SL±2ATR, TP±4ATR, RR=2)")
    print(f"{'='*95}")
    print(f"{'方案':<15} {'信号':>6} {'胜率':>7} {'损率':>7} {'开率':>7} {'均TP':>7} {'均SL':>7} {'利润因子':>8}")
    print("-"*95)
    
    for m in ['0_当前','1_降门槛','2_加指标','4_趋势过滤']:
        s = all_stats[m]
        t = s['total']
        if t == 0: continue
        wr = s['tp']/t*100
        sr = s['sl']/t*100
        opr = s['open']/t*100
        atp = sum(s['tp_bars'])/len(s['tp_bars']) if s['tp_bars'] else 0
        asl = sum(s['sl_bars'])/len(s['sl_bars']) if s['sl_bars'] else 0
        pf = round((s['tp']/t*2.0)/(max(s['sl']/t*1, 0.001)), 2)  # RR always 2
        print(f"{m:<15} {t:>6} {wr:>6.1f}% {sr:>6.1f}% {opr:>6.1f}% {atp:>6.1f}h {asl:>6.1f}h {pf:>+7.2f}")
    
    # 输出详细 JSON
    output = {
        'backtest_time': datetime.now(BJT).strftime('%Y-%m-%d %H:%M BJ'),
        'sl_tp_method': 'D_ATR20 (SL±2ATR, TP±4ATR, RR=2)',
        'summary': {m: {
            'total': all_stats[m]['total'],
            'win_rate': round(all_stats[m]['tp']/all_stats[m]['total']*100, 1) if all_stats[m]['total']>0 else 0,
            'sl_rate': round(all_stats[m]['sl']/all_stats[m]['total']*100, 1) if all_stats[m]['total']>0 else 0,
            'avg_tp_h': round(sum(all_stats[m]['tp_bars'])/len(all_stats[m]['tp_bars']), 1) if all_stats[m]['tp_bars'] else 0,
            'avg_sl_h': round(sum(all_stats[m]['sl_bars'])/len(all_stats[m]['sl_bars']), 1) if all_stats[m]['sl_bars'] else 0,
        } for m in ['0_当前','1_降门槛','2_加指标','4_趋势过滤']}
    }
    with open(OUT, 'w') as f:
        json.dump(output, f, indent=2, ensure_ascii=False)
    print(f"\n详细: {OUT}")

if __name__ == '__main__':
    main()
