#!/usr/bin/env python3
"""
缠论核心模块 v1.0 — 中枢 + 背驰 + 买卖点
供 analysis_template.py 和 _social_publish.py 导入使用
"""
import numpy as np

def find_swing_points(highs, lows, min_bars=5):
    """
    找顶底分型 → 笔的端点（去重：每个位置只保留一种分型，顶优先）。
    """
    points = []
    n = len(highs)
    for i in range(3, n - 3):
        is_top = (highs[i] >= highs[i-1] and highs[i] >= highs[i+1] 
                  and highs[i] > highs[i-2] and highs[i] > highs[i+2]
                  and highs[i] > highs[i-3] and highs[i] > highs[i+3])
        is_bottom = (lows[i] <= lows[i-1] and lows[i] <= lows[i+1]
                     and lows[i] < lows[i-2] and lows[i] < lows[i+2]
                     and lows[i] < lows[i-3] and lows[i] < lows[i+3])
        
        if is_top and is_bottom:
            # 同位置顶底冲突：取离前一个分型更远的价格
            if not points:
                is_bottom = False  # 优先顶
            elif points[-1][1] == 'top':
                is_top = False  # 上一个是顶 → 这次取底
            else:
                is_bottom = False  # 上一个是底 → 这次取顶
        
        if is_top and (not points or points[-1][1] != 'top'):
            points.append((i, 'top', highs[i]))
        elif is_bottom and (not points or points[-1][1] != 'bottom'):
            points.append((i, 'bottom', lows[i]))
    return points

def find_bi(swing_points):
    """
    从分型序列提取有效笔（顶底交替，合并连续同向）。
    """
    if len(swing_points) < 2:
        return []
    # 合并连续同向分型（保留最极端的）
    merged = [swing_points[0]]
    for pt in swing_points[1:]:
        last = merged[-1]
        if pt[1] == last[1]:
            # 同向：保留更极端的
            if pt[1] == 'top' and pt[2] > last[2]:
                merged[-1] = pt
            elif pt[1] == 'bottom' and pt[2] < last[2]:
                merged[-1] = pt
        else:
            merged.append(pt)
    
    # 提取笔（顶底交替）
    bi_list = []
    for i in range(len(merged) - 1):
        curr, nxt = merged[i], merged[i+1]
        if nxt[0] - curr[0] < 4:  # 至少4根K线
            continue
        direction = 'down' if curr[1] == 'top' else 'up'
        bi_list.append((curr[0], nxt[0], direction, curr[2], nxt[2]))
    return bi_list

def find_zhongshu(bi_list, highs, lows):
    """
    找中枢：至少连续3笔的重叠区间。
    中枢上沿 ZG = min(前三笔中所有高点)
    中枢下沿 ZD = max(前三笔中所有低点)
    返回: [(ZG, ZD, start_bi_idx, end_bi_idx), ...]
    """
    hubs = []
    if len(bi_list) < 3:
        return hubs
    
    i = 0
    while i <= len(bi_list) - 3:
        b1, b2, b3 = bi_list[i], bi_list[i+1], bi_list[i+2]
        # 取三笔涉及的所有K线的高低点
        all_highs = []
        all_lows = []
        for bi in [b1, b2, b3]:
            for j in range(bi[0], bi[1] + 1):
                if j < len(highs):
                    all_highs.append(highs[j])
                    all_lows.append(lows[j])
        if not all_highs:
            i += 1; continue
        
        zg = min(all_highs)  # 中枢上沿
        zd = max(all_lows)   # 中枢下沿
        
        if zg > zd:  # 有重叠
            hubs.append((zg, zd, i, i+2))
            i += 3  # 跳过已覆盖的笔
        else:
            i += 1
    return hubs

def calc_macd_area(closes, start_idx, end_idx, fast=12, slow=26, signal=9):
    """
    计算指定区间的 MACD histogram 面积。
    用于背驰判断：比较两段同向走势的 MACD 面积。
    """
    if end_idx - start_idx < 5:
        return 0
    
    segment = closes[start_idx:end_idx+1]
    if len(segment) < 5:
        return 0
    
    # 计算 MACD
    ema_fast = [segment[0]]
    ema_slow = [segment[0]]
    kf = 2.0/(fast+1)
    ks = 2.0/(slow+1)
    for i in range(1, len(segment)):
        ema_fast.append(segment[i]*kf + ema_fast[-1]*(1-kf))
        ema_slow.append(segment[i]*ks + ema_slow[-1]*(1-ks))
    
    macd_line = [f-s for f,s in zip(ema_fast, ema_slow)]
    
    if len(macd_line) < signal:
        return 0
    
    ema_sig = [macd_line[0]]
    k = 2.0/(signal+1)
    for i in range(1, len(macd_line)):
        ema_sig.append(macd_line[i]*k + ema_sig[-1]*(1-k))
    
    hist = [m - s for m, s in zip(macd_line, ema_sig)]
    
    # 面积 = Σ|hist| （取绝对值求和）
    return sum(abs(h) for h in hist)

def detect_beichi(bi_list, closes):
    """
    检测背驰：比较相邻两段同向笔的 MACD 面积。
    底背驰: 两段下跌，第二段价格更低但MACD面积更小 → 做多信号
    顶背驰: 两段上涨，第二段价格更高但MACD面积更小 → 做空信号
    返回: [{'type': '底背驰'/'顶背驰', 'bi1_idx': i, 'bi2_idx': i+2, 'area1': a1, 'area2': a2}, ...]
    """
    if len(bi_list) < 4:
        return []
    
    signals = []
    for i in range(len(bi_list) - 3):
        b1 = bi_list[i]     # 第一段
        b2 = bi_list[i+2]   # 第三段（同方向）
        if b1[2] != b2[2]:  # 必须同方向
            continue
        
        area1 = calc_macd_area(closes, b1[0], b1[1])
        area2 = calc_macd_area(closes, b2[0], b2[1])
        
        if area1 <= 0 or area2 <= 0:
            continue
        
        if b1[2] == 'down':  # 两段下跌
            # 底背驰: 第二段低点更低但MACD面积更小
            if b2[4] < b1[4] and area2 < area1 * 0.85:
                signals.append({
                    'type': '底背驰',
                    'bi1_idx': i, 'bi2_idx': i+2,
                    'price1': b1[4], 'price2': b2[4],
                    'area1': round(area1, 1), 'area2': round(area2, 1),
                })
        else:  # 两段上涨
            # 顶背驰: 第二段高点更高但MACD面积更小
            if b2[3] > b1[3] and area2 < area1 * 0.85:
                signals.append({
                    'type': '顶背驰',
                    'bi1_idx': i, 'bi2_idx': i+2,
                    'price1': b1[3], 'price2': b2[3],
                    'area1': round(area1, 1), 'area2': round(area2, 1),
                })
    return signals

def detect_buy_sell_points(beichi_list, hubs, bi_list, current_price):
    """
    根据背驰和中枢判定买卖点。
    一买: 底背驰 → 趋势反转
    二买: 一买后回踩中枢下沿不破
    三买: 突破中枢上沿后回踩不破ZG
    
    返回: {'buy': ['一买','二买'], 'sell': [...]}
    """
    result = {'buy': [], 'sell': [], 'details': []}
    
    if not beichi_list:
        return result
    
    latest_bei = beichi_list[-1]
    latest_hub = hubs[-1] if hubs else None
    
    if latest_bei['type'] == '底背驰':
        result['buy'].append('一买')
        result['details'].append(f"底背驰: 价格{latest_bei['price1']:.0f}→{latest_bei['price2']:.0f}, MACD面积{latest_bei['area1']}→{latest_bei['area2']}")
        
        # 二买: 当前价在中枢上方且离中枢不远
        if latest_hub:
            zg, zd = latest_hub[0], latest_hub[1]
            if current_price > zg and current_price < zg * 1.03:
                result['buy'].append('二买')
                result['details'].append(f"回踩中枢上沿(ZG={zg:.0f})确认, 现价={current_price:.0f}")
            elif current_price > zd and current_price < zg:
                result['buy'].append('二买')
                result['details'].append(f"中枢内震荡(ZD={zd:.0f}-ZG={zg:.0f}), 现价={current_price:.0f}")
    
    elif latest_bei['type'] == '顶背驰':
        result['sell'].append('一卖')
        result['details'].append(f"顶背驰: 价格{latest_bei['price1']:.0f}→{latest_bei['price2']:.0f}, MACD面积{latest_bei['area1']}→{latest_bei['area2']}")
        
        if latest_hub:
            zg, zd = latest_hub[0], latest_hub[1]
            if current_price < zd and current_price > zd * 0.97:
                result['sell'].append('二卖')
                result['details'].append(f"跌破中枢下沿(ZD={zd:.0f})反抽, 现价={current_price:.0f}")
    
    return result

def analyze_chanlun(highs_4h, lows_4h, closes_4h, current_price):
    """
    完整缠论分析 — 供外部调用。
    输入: 4H K线数据（至少60根）
    输出: {'hubs': [...], 'beichi': [...], 'points': {...}}
    """
    if len(highs_4h) < 60:
        return {'hubs': [], 'beichi': [], 'points': {'buy': [], 'sell': [], 'details': []}}
    
    swing_pts = find_swing_points(highs_4h, lows_4h)
    bi = find_bi(swing_pts)
    hubs = find_zhongshu(bi, highs_4h, lows_4h)
    beichi = detect_beichi(bi, closes_4h)
    points = detect_buy_sell_points(beichi, hubs, bi, current_price)
    
    return {
        'hubs': [{'ZG': round(h[0], 1), 'ZD': round(h[1], 1)} for h in hubs[-3:]],
        'beichi': beichi[-2:],
        'points': points,
        'bi_count': len(bi),
        'hub_count': len(hubs),
    }
