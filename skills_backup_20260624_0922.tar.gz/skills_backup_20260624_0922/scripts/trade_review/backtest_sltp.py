#!/usr/bin/env python3
"""
SL/TP 方案回测 v3 — 1H K线逐根扫描
每根1H蜡烛: 计算指标 → 判定方向 → 5种SL/TP方案 → 追踪后续K线看谁最先触发
输出: /tmp/sltp_backtest_h1.json
"""
import json, sqlite3, sys, os
from datetime import datetime, timezone, timedelta
from collections import defaultdict
sys.path.insert(0, '/root/.hermes/trade_review')
from _shared import BJT, ema as _ema, calc_rsi as _calc_rsi_list

DB = '/root/.hermes/trade_review/okx_klines.db'
OUT = '/tmp/sltp_backtest_h1.json'

ATR_PERIOD = 14
LOOKBACK_4H = 96   # 16天4H
LOOKBACK_1D = 90   # 90天日线
MAX_TRACK_H = 168  # 最多追踪168小时(7天)

def load_all_1h(db, coin):
    """加载所有1H K线"""
    rows = db.execute("""
        SELECT ts, open, high, low, close FROM klines
        WHERE coin=? AND timeframe='1H'
        ORDER BY ts ASC
    """, (coin,)).fetchall()
    return rows

def calc_ema(data, period):
    """EMA计算 (chronological order)"""
    if len(data) < 2:
        return [data[0]] if data else []
    k = 2.0 / (period + 1)
    result = [data[0]]
    for i in range(1, len(data)):
        result.append(data[i] * k + result[-1] * (1 - k))
    return result

def calc_atr(highs, lows, closes, period=14):
    """ATR计算"""
    if len(closes) < period + 1:
        return 0
    tr_list = []
    for i in range(1, len(closes)):
        tr = max(highs[i] - lows[i], abs(highs[i] - closes[i-1]), abs(lows[i] - closes[i-1]))
        tr_list.append(tr)
    if len(tr_list) < period:
        return sum(tr_list) / len(tr_list)
    atr = sum(tr_list[:period]) / period
    for i in range(period, len(tr_list)):
        atr = (atr * (period - 1) + tr_list[i]) / period
    return atr

def detect_signal(closes_1h, highs_1h, lows_1h, idx):
    """
    在idx位置判定方向信号。
    需要: 50根1H计算指标 + 96根4H找支撑阻力
    """
    if idx < 100:
        return None, {}
    
    # 计算指标 (用idx之前的数据)
    close_hist = closes_1h[idx-50:idx+1]
    if len(close_hist) < 50:
        return None, {}
    
    # RSI(14)
    rsi_list = _calc_rsi_list(close_hist, 14)
    rsi = rsi_list[-1] if rsi_list and rsi_list[-1] is not None else 50
    
    # MACD(12/75/9)
    ema_f = calc_ema(close_hist, 12)
    ema_s = calc_ema(close_hist, 75)
    macd_line = [f - s for f, s in zip(ema_f, ema_s)]
    ema_sig = calc_ema(macd_line, 9)
    macd_h = macd_line[-1] - ema_sig[-1] if len(ema_sig) > 0 and len(macd_line) > 0 else 0
    
    # ATR
    atr = calc_atr(highs_1h[max(0,idx-ATR_PERIOD-1):idx+1],
                   lows_1h[max(0,idx-ATR_PERIOD-1):idx+1],
                   closes_1h[max(0,idx-ATR_PERIOD-1):idx+1], ATR_PERIOD)
    if atr <= 0:
        atr = closes_1h[idx] * 0.005
    
    # 方向
    direction = None
    if rsi > 55 and macd_h > 0:
        direction = 'long'
    elif rsi < 45 and macd_h < 0:
        direction = 'short'
    
    if not direction:
        return None, {}
    
    entry = closes_1h[idx]
    current_high = highs_1h[idx]
    current_low = lows_1h[idx]
    
    # 找支撑阻力：过去96根1H(=16天)的高低点
    lookback = min(idx, 96)
    hist_highs = highs_1h[idx-lookback:idx]
    hist_lows = lows_1h[idx-lookback:idx]
    
    # 支撑: 低于当前价的低点，取最近3个
    supports = sorted(set(l for l in hist_lows if l < entry), reverse=True)[:3]
    # 阻力: 高于当前价的高点，取最近3个
    resistances = sorted(set(h for h in hist_highs if h > entry))[:3]
    
    # VP边界近似: 最近24H的高低点
    vp_lookback = min(idx, 24)
    val = min(lows_1h[idx-vp_lookback:idx+1])
    vah = max(highs_1h[idx-vp_lookback:idx+1])
    
    ctx = {
        'entry': entry,
        'atr': atr,
        'rsi': rsi,
        'macd_h': macd_h,
        'supports': supports,
        'resistances': resistances,
        'val': val,
        'vah': vah,
    }
    return direction, ctx

def calc_methods(direction, ctx):
    """计算5种方案的SL/TP"""
    entry = ctx['entry']
    atr = ctx['atr']
    supports = ctx['supports']
    resistances = ctx['resistances']
    val = ctx['val']
    vah = ctx['vah']
    
    methods = {}
    
    # A: 当前方案 (最近支撑/阻力 ± 0.5ATR)
    if direction == 'long' and supports:
        sl = supports[0] - atr * 0.5
        tp = resistances[0] if resistances else entry + atr * 3
    elif direction == 'short' and resistances:
        sl = resistances[0] + atr * 0.5
        tp = supports[0] if supports else entry - atr * 3
    else:
        sl = entry - atr * 1.5 if direction == 'long' else entry + atr * 1.5
        tp = entry + atr * 3 if direction == 'long' else entry - atr * 3
    if sl > 0 and abs(entry - sl) > 0:
        methods['A_当前'] = {'sl': sl, 'tp': tp, 'rr': abs(tp-entry)/abs(entry-sl)}
    
    # B: VP锚定
    if direction == 'long':
        methods['B_VP'] = {'sl': val, 'tp': vah, 'rr': abs(vah-entry)/abs(entry-val) if abs(entry-val)>0 else 0}
    else:
        methods['B_VP'] = {'sl': vah, 'tp': val, 'rr': abs(val-entry)/abs(entry-vah) if abs(entry-vah)>0 else 0}
    
    # C: 纯ATR 1.5x / 3.0x
    sl = entry - 1.5*atr if direction=='long' else entry + 1.5*atr
    tp = entry + 3.0*atr if direction=='long' else entry - 3.0*atr
    methods['C_ATR15'] = {'sl': sl, 'tp': tp, 'rr': 2.0}
    
    # D: 纯ATR 2.0x / 4.0x
    sl = entry - 2.0*atr if direction=='long' else entry + 2.0*atr
    tp = entry + 4.0*atr if direction=='long' else entry - 4.0*atr
    methods['D_ATR20'] = {'sl': sl, 'tp': tp, 'rr': 2.0}
    
    # E: 混合
    if direction == 'long':
        struct_sl = supports[0] if supports else entry - atr*1.5
        sl = max(struct_sl, entry - atr*1.5)
    else:
        struct_sl = resistances[0] if resistances else entry + atr*1.5
        sl = min(struct_sl, entry + atr*1.5)
    sl_dist = abs(entry - sl)
    tp = entry + sl_dist*2 if direction=='long' else entry - sl_dist*2
    methods['E_混合'] = {'sl': sl, 'tp': tp, 'rr': abs(tp-entry)/sl_dist if sl_dist>0 else 0}
    
    return methods

def track_outcomes(highs, lows, idx, direction, methods):
    """
    从idx+1开始追踪，记录每种方案SL/TP最先触发的K线序号和结果。
    返回: {method_name: ('sl'/'tp'/'open', bar_offset, trigger_price)}
    """
    results = {}
    for mname, m in methods.items():
        sl, tp = m['sl'], m['tp']
        found = None
        for i in range(idx + 1, len(highs)):
            h, l = highs[i], lows[i]
            if direction == 'long':
                if l <= sl:
                    found = ('sl', i - idx, sl)
                    break
                if h >= tp:
                    found = ('tp', i - idx, tp)
                    break
            else:
                if h >= sl:
                    found = ('sl', i - idx, sl)
                    break
                if l <= tp:
                    found = ('tp', i - idx, tp)
                    break
        if not found:
            found = ('open', len(highs) - idx - 1, 0)
        results[mname] = found
    return results

def main():
    db = sqlite3.connect(DB)
    
    all_stats = defaultdict(lambda: {'total': 0, 'tp': 0, 'sl': 0, 'open': 0,
                                      'tp_bars': [], 'sl_bars': [], 'avg_rr': 0, 'rr_sum': 0})
    signals = []
    
    for coin in ['BTC', 'ETH']:
        rows = load_all_1h(db, coin)
        if not rows:
            continue
        
        timestamps = [r[0] for r in rows]
        highs = [r[2] for r in rows]
        lows = [r[3] for r in rows]
        closes = [r[4] for r in rows]
        
        print(f'{coin}: {len(rows)} 根1H K线, 扫描中...')
        
        coin_signals = 0
        for i in range(100, len(rows) - MAX_TRACK_H):
            direction, ctx = detect_signal(closes, highs, lows, i)
            if not direction:
                continue
            
            methods = calc_methods(direction, ctx)
            outcomes = track_outcomes(highs, lows, i, direction, methods)
            
            coin_signals += 1
            for mname, (result, bars, price) in outcomes.items():
                s = all_stats[mname]
                s['total'] += 1
                if result == 'tp':
                    s['tp'] += 1
                    s['tp_bars'].append(bars)
                elif result == 'sl':
                    s['sl'] += 1
                    s['sl_bars'].append(bars)
                else:
                    s['open'] += 1
                s['rr_sum'] += methods[mname]['rr']
            
            if coin_signals <= 3:
                ts_str = datetime.fromtimestamp(timestamps[i]/1000, tz=BJT).strftime('%m-%d %H:%M')
                signals.append({
                    'coin': coin, 'time': ts_str, 'direction': direction,
                    'entry': round(ctx['entry'], 1), 'rsi': round(ctx['rsi'], 1),
                    'atr': round(ctx['atr'], 1),
                    'outcomes': {m: {'result': o[0], 'bars': o[1]} for m, o in outcomes.items()}
                })
        
        print(f'  {coin}: {coin_signals} 个信号')
    
    # 计算汇总
    for m in all_stats:
        s = all_stats[m]
        t = s['total']
        if t > 0:
            s['win_rate'] = round(s['tp'] / t * 100, 1)
            s['sl_rate'] = round(s['sl'] / t * 100, 1)
            s['open_rate'] = round(s['open'] / t * 100, 1)
            s['avg_rr'] = round(s['rr_sum'] / t, 2) if t > 0 else 0
            s['avg_tp_bars'] = round(sum(s['tp_bars'])/len(s['tp_bars']), 1) if s['tp_bars'] else 0
            s['avg_sl_bars'] = round(sum(s['sl_bars'])/len(s['sl_bars']), 1) if s['sl_bars'] else 0
            # 利润因子 = (胜率×均RR) / (败率×1)
            s['profit_factor'] = round((s['tp']/t * s['avg_rr']) / max(s['sl']/t * 1, 0.001), 2)
    
    output = {
        'backtest_time': datetime.now(BJT).strftime('%Y-%m-%d %H:%M BJ'),
        'total_signals': sum(s['total'] for s in all_stats.values()) // 5,  # 5方法
        'summary': {m: {k: v for k, v in s.items() if k not in ('tp_bars', 'sl_bars', 'rr_sum')}
                    for m, s in sorted(all_stats.items())},
        'sample_signals': signals
    }
    
    with open(OUT, 'w') as f:
        json.dump(output, f, indent=2, ensure_ascii=False)
    
    # 打印
    print(f"\n{'='*90}")
    print(f"回测完成: {len(rows)}根1H × 2币种")
    print(f"{'='*90}")
    print(f"{'方案':<12} {'信号':>6} {'胜率':>7} {'损率':>7} {'开率':>7} {'均RR':>6} {'均TP(h)':>8} {'均SL(h)':>8} {'利润因子':>8}")
    print("-" * 90)
    for m in ['A_当前', 'B_VP', 'C_ATR15', 'D_ATR20', 'E_混合']:
        s = all_stats[m]
        t = s['total']
        if t == 0: continue
        print(f"{m:<12} {t:>6} {s['win_rate']:>6.1f}% {s['sl_rate']:>6.1f}% {s['open_rate']:>6.1f}% "
              f"{s['avg_rr']:>6.2f} {s['avg_tp_bars']:>7.1f}h {s['avg_sl_bars']:>7.1f}h {s['profit_factor']:>+7.2f}")
    
    print(f"\n详细数据: {OUT}")

if __name__ == '__main__':
    main()
