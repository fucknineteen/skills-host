#!/usr/bin/env python3
"""
SL/TP + 仓位引擎 v062309
三层解耦: Signal(方向) → Quality(是否值得) → Execution(仓位)
供 analysis_template.py 和 _social_publish.py 调用
"""
import math

# ============================================================
# 数据结构
# ============================================================

class TradePlan:
    """一次交易的完整计划"""
    __slots__ = ('direction', 'entry', 'sl', 'tp', 'rr', 'risk_pct', 
                 'tp_source', 'trade_space', 'blocked_reason')
    
    def __init__(self):
        self.direction = 'FLAT'
        self.entry = 0
        self.sl = 0
        self.tp = 0
        self.rr = 0
        self.risk_pct = 0
        self.tp_source = 'none'
        self.trade_space = 0
        self.blocked_reason = ''

# ============================================================
# Layer 2: Quality — SL计算 + TP选择 + Trade Space过滤
# ============================================================

def compute_sl(direction, entry, near_support, near_resistance,
               swing_low, swing_high, chanlun_zd, atr):
    """
    结构锚定 SL:
    SL = max(near_support[-1], swing_low, chanlun_ZD) - ATR×0.3  (做多)
    SL = min(near_resistance[-1], swing_high, ???) + ATR×0.3     (做空)
    """
    if not near_support or not near_resistance:
        return 0
    
    if direction == 'LONG':
        candidates = [near_support[-1]]
        if swing_low and swing_low > 0: candidates.append(swing_low)
        if chanlun_zd and chanlun_zd > 0: candidates.append(chanlun_zd)
        sl_base = max(c for c in candidates if c < entry) if any(c < entry for c in candidates) else near_support[-1]
        return sl_base - atr * 0.3
    else:  # SHORT
        candidates = [near_resistance[-1]]
        if swing_high and swing_high > 0: candidates.append(swing_high)
        # 做空没有 chanlun_ZG（中枢上沿），用 VAH 代替
        sl_base = min(c for c in candidates if c > entry) if any(c > entry for c in candidates) else near_resistance[-1]
        return sl_base + atr * 0.3


def compute_tp(direction, entry, atr,
               tp1, tp2, tp3,
               tp2_age_days=None, tp3_age_days=None,
               signal_level=None):
    """
    三层流动性目标 — 时间质量加权。
    TP1: 无条件进入候选（最近阻力/支撑）
    TP2: 结构swing，≤120天允许
    TP3: VAH/1D级别，≤180天允许
    信号质量门控: 远端目标(>4ATR)需L0或L1确认
    
    参数:
      tp2_age_days: TP2来源的年龄（天），None=未知
      tp3_age_days: TP3来源的年龄（天）
      signal_level: 'L0'|'L1'|'L2' 触发层级
    """
    candidates = []
    
    # TP1: 永远允许
    if tp1 and tp1 > 0:
        candidates.append(('tp1', tp1, 0))
    
    # TP2: ≤120天或未知
    if tp2 and tp2 > 0:
        age = tp2_age_days if tp2_age_days is not None else 90
        if age <= 120:
            candidates.append(('tp2', tp2, age))
    
    # TP3: ≤180天或未知
    if tp3 and tp3 > 0:
        age = tp3_age_days if tp3_age_days is not None else 60
        if age <= 180:
            candidates.append(('tp3', tp3, age))
    
    # 方向过滤
    if direction == 'LONG':
        valid = [(s, p, a) for s, p, a in candidates if p > entry]
    else:
        valid = [(s, p, a) for s, p, a in candidates if p < entry]
    
    if not valid:
        return 0, 'none'
    
    # 选最远目标
    if direction == 'LONG':
        best_source, best_tp, best_age = max(valid, key=lambda x: x[1])
    else:
        best_source, best_tp, best_age = min(valid, key=lambda x: x[1])
    
    # 信号质量门控: 远端目标(>4ATR)需要L0或L1触发
    tp_distance = abs(best_tp - entry)
    if tp_distance > 4 * atr:
        if signal_level not in ('L0', 'L1'):
            # 回退到 ≤4ATR 的目标
            close = [(s, p, a) for s, p, a in valid if abs(p - entry) <= 4 * atr]
            if close:
                if direction == 'LONG':
                    best_source, best_tp, best_age = max(close, key=lambda x: x[1])
                else:
                    best_source, best_tp, best_age = min(close, key=lambda x: x[1])
            else:
                return 0, 'none'
    
    return best_tp, best_source


def trade_space_filter(entry, sl, tp, atr):
    """Trade Space = TP - SL, 必须 ≥ 1.5×ATR"""
    trade_space = tp - sl if tp > sl else sl - tp
    if trade_space < 1.5 * atr:
        return False, trade_space
    return True, trade_space


# ============================================================
# Layer 3: Execution — RR计算 + 仓位映射
# ============================================================

def compute_rr(entry, sl, tp):
    """RR = |TP-entry| / |entry-SL|"""
    risk = abs(entry - sl)
    reward = abs(tp - entry)
    if risk <= 0:
        return 0
    return reward / risk


def position_sizing(rr):
    """RR → 账户风险比例"""
    if rr < 1.0:
        return 0.0
    elif rr < 1.3:
        return 0.006   # 0.6%
    elif rr < 1.8:
        return 0.014   # 1.4%
    else:
        return 0.02    # 2%


def apply_quality_adjustment(rr, tp_source, l1_aligned):
    """TP覆盖率修正: 只吃到TP1且道氏不齐 → RR打折"""
    if tp_source == 'tp1' and not l1_aligned:
        return rr * 0.7
    return rr


# ============================================================
# 主入口: decision_engine
# ============================================================

def decision_engine(direction, entry, atr,
                    near_support, near_resistance,
                    swing_low=None, swing_high=None,
                    chanlun_zd=None,
                    tp1=None, tp2=None, tp3=None,
                    tp2_age_days=None, tp3_age_days=None,
                    signal_level=None,
                    l1_aligned=False):
    """
    三层解耦主入口。
    
    参数:
      direction: 'LONG' | 'SHORT' | 'FLAT'  (来自信号层 L0-L3)
      entry, atr: 现价和ATR
      near_support, near_resistance: 最近支撑阻力列表
      swing_low, swing_high: 威科夫结构高低点 (wyckoff_detect 的 swing_lows/highs)
      chanlun_zd: 缠论中枢下沿 (仅在LONG时用)
      tp1: 第一目标 = near_resistance[-1] (做多) / near_support[-1] (做空)
      tp2: 第二目标 = previous_swing_high_4H / previous_swing_low_4H
      tp3: 第三目标 = max(VAH, 1D_prev_high) / min(VAL, 1D_prev_low)
      l1_aligned: L1道氏是否对齐
    
    返回: TradePlan 对象
    """
    plan = TradePlan()
    plan.direction = direction
    
    if direction == 'FLAT' or entry <= 0 or atr <= 0:
        plan.blocked_reason = 'no_signal'
        return plan
    
    if not near_support or not near_resistance:
        plan.blocked_reason = 'no_levels'
        return plan
    
    # Layer 2: SL + TP + Trade Space
    plan.sl = compute_sl(direction, entry, near_support, near_resistance,
                         swing_low, swing_high, chanlun_zd, atr)
    if plan.sl <= 0:
        plan.blocked_reason = 'sl_invalid'
        return plan
    
    plan.tp, plan.tp_source = compute_tp(direction, entry, atr, tp1, tp2, tp3,
                                         tp2_age_days, tp3_age_days, signal_level)
    if plan.tp <= 0:
        plan.blocked_reason = 'tp_invalid'
        return plan
    
    ok, plan.trade_space = trade_space_filter(entry, plan.sl, plan.tp, atr)
    if not ok:
        plan.blocked_reason = f'trade_space_too_small({plan.trade_space:.1f}<{1.5*atr:.1f})'
        return plan
    
    # Layer 3: RR → 仓位
    plan.rr = compute_rr(entry, plan.sl, plan.tp)
    plan.rr = apply_quality_adjustment(plan.rr, plan.tp_source, l1_aligned)
    plan.risk_pct = position_sizing(plan.rr)
    
    if plan.risk_pct == 0:
        plan.blocked_reason = f'rr_too_low({plan.rr:.2f})'
    
    plan.entry = entry
    return plan
