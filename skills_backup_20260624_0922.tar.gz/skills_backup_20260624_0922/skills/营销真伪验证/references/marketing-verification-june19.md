# 2026-06-19 营销内容验证完整记录

## 待验证工具清单

| 工具名 | 声称功能 | GitHub API 结果 | 最终判定 |
|--------|---------|----------------|---------|
| Agency Agents | 人格记忆 | `msitarzewski/agency-agents` → 404 | ⚠️ 同名项目存在但非此repo（`msitarzewski/agency-agents` 11万星，但描述是"AI agency workforce"非记忆） |
| Hindsight | 人格记忆 | `vectorize-io/hindsight` → 1.6万星 | ✅ 真实存在，Agent记忆学习框架 |
| Jina Reader | 联网 | `jina-ai/reader` → 1.1万星 | ✅ 真实存在，URL转LLM文本 |
| Crawl4AI | 联网 | `unclecode/crawl4ai` → 6.8万星 | ✅ 真实存在，开源爬虫 |
| Whisper | 表达 | `openai/whisper` → 10万星 | ✅ 真实存在，语音识别 |
| HTTS | 表达 | GitHub搜htts → 372结果，无相关 | ❌ 虚构/拼写错误 |
| RTK | 成本管控 | GitHub搜rtk → 0结果 | ❌ 虚构 |
| Talkscale | 成本管控 | GitHub搜talkscale → 0结果 | ❌ 虚构 |
| Tavily | 联网 | `tavily-ai/tavily-python` → 1289星 | ✅ 真实存在，SaaS搜索API |
| Awesome Hermes Agent | 生态库 | `0xNyk/awesome-hermes-agent` → 4061星 | ✅ 真实存在，Hermes资源合集 |

## 关键发现

1. **RTK** 和 **Talkscale** 完全搜不到，确认为虚构
2. **HTTS** GitHub有372个同名项目但无一个是TTS工具，确认为拼写错误/虚构
3. **Agency Agents** 虽非记忆工具但确实存在（11万星），视频将其归类为"人格记忆"可能不准确
4. **Tavily** 是SaaS服务，有Python SDK但无官方monorepo

## 对用户的实用建议

- 最有用：Awesome Hermes Agent（资源合集）、Hindsight（记忆框架）
- 有用但已有替代：Jina Reader（Crawl4AI更强）、Tavily（Crawl4AI替代）
- 无用/虚构：RTK、Talkscale、HTTS
