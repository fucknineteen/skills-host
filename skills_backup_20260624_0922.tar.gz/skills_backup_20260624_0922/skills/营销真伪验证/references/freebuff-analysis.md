# Freebuff 验证记录 (2026-06-22)

## 基本信息
- **包名**: `freebuff` (npm)
- **版本**: 0.0.112 (latest)
- **发布者**: jahooma / brandonatcodebuff / charleslien
- **仓库**: github.com/CodebuffAI/freebuff-private
- **官网**: freebuff.com / codebuff.com
- **描述**: "The world's strongest free coding agent"
- **许可证**: MIT
- **依赖**: 仅 tar@^7.0.0

## 验证结论
✅ 真实存在。npm 包体积仅 ~30KB，实际是一个二进制下载器。

## 架构特点
- `index.js` 是纯 Node.js 壳，负责从 codebuff.com API 下载平台适配的二进制
- 二进制存放在 `~/.config/manicode/freebuff`
- 二进制是 Go/C++ 编译的闭源可执行文件，实际 AI 推理在二进制内部完成
- 无需 API Key，安装即用
- 商业模式：终端广告支撑免费使用
- 数据政策：使用的模型提供商承诺不训练用户数据

## 模型使用情况
- 内部接入了多个模型（DeepSeek V4 Pro、MiniMax M3、MiMo 2.5 Pro、Kimi K2.6 等）
- 不透明：源码中无模型调用逻辑，全部在闭源二进制内
- 用户无法自定义模型或切换提供商

## 社区生态
- **Freebuff2API** (github.com/Quorinex/Freebuff2API, ⭐500): Go 语言写的 OpenAI 兼容代理服务，做 token rotation 和 Docker 部署
- 这不是官方项目，是第三方封装

## 实用评估
- Hermes 已有同等能力（编码代理），功能重叠度高
- 用户工作流 90% 通过 Python 脚本完成，freebuff 覆盖场景有限
- 安装成本：需要 Node.js 环境
- 结论：不建议集成

## Pitfall: 二进制包装模式
遇到 npm 包只有 index.js 几十 KB、依赖极少（仅 tar）的情况时，高度可能是二进制下载器。此时：
1. 查看 index.js 中的 downloadUrl/release 逻辑
2. 搜索 CODEBUFF / APP_URL 等环境变量
3. 不要假设源码包含核心逻辑
4. 这意味着无法审计 AI 调用的具体实现
