# RTK 压缩适用范围

## 核心事实

RTK (Runtime Token Compression) 插件**只压缩 `terminal()` 命令的输出**，不压缩以下内容：

| 工具调用 | RTK压缩？ | 原因 |
|----------|:---------:|------|
| `terminal(command="git log")` | ✅ | 原生支持 |
| `execute_code(code="...")` | ❌ | 走Python执行，不走terminal |
| `write_file(path, content)` | ❌ | 文件写入，不是终端输出 |
| `read_file(path)` | ❌ | 文件读取，不是终端输出 |

## 对用户工作流的实际影响

用户的交易工作流构成：
- **~90%** Python 脚本（`execute_code`）→ RTK 不压缩
- **~9%** 文件读写（`write_file`/`read_file`）→ RTK 不压缩
- **~1%** 终端命令（`terminal`）→ RTK 可压缩

结论：RTK 对用户节省的 token 比例**不到2%**，不值得安装。

## 通用判断法

评估任何工具是否值得安装，先分析用户工作流的构成比例：
1. 列出用户的主要操作类型及各自占比
2. 看工具覆盖的操作类型占比是多少
3. 如果覆盖的比例很低 → 不值得装

## 参考

- 本次会话验证：2026-06-19，用户询问 RTK 插件作用
- 来源：social-dynamic skill 的营销内容验证流程
