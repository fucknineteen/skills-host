# Pipeline Migration Details

## Background

`analysis_template.py --social` (5-step old pipeline) has been superseded by `publish_social.py` (7-step pipeline).

## Old Pipeline (DEPRECATED)

```bash
python3 analysis_template.py BTC ETH -s
```

Steps:
1. `review_last_post.py` — review last post
2. `generate_social_draft()` (inside analysis_template.py) — draft copy
3. `verify_social_post.py` — verify data
4. `gen_charts.py --style 1` — generate chart
5. `save_social_post.py` — save record

## New Pipeline (ACTIVE)

```bash
python3 publish_social.py BTC ETH
```

Steps:
1. `monitor_and_sync.py` — sync K-lines
2. `analysis_template.py BTC ETH` — analyze (NO -s flag)
3. `review_last_post.py --save` — review last post
4. `_social_publish.generate_social_draft()` — draft copy (imports from _social_publish.py)
5. `verify_social_post.py` — verify data
6. User confirmation
7. `save_social_post.py` — save record

## Key Differences

| Aspect | Old (-s) | New (publish_social.py) |
|--------|----------|------------------------|
| Steps | 5 | 7 (includes sync + user confirmation) |
| Draft function | `analysis_template.py` local copy | `_social_publish.py` canonical copy |
| `generate_social_draft` data | Uses `near_support`/`near_resistance` | Uses `levels_4h` |
| Chart style | Fixed Style 1 | Dynamic (Style 1-4 based on signals) |
| Cron usage | None | Not used by cron |

## Why Migration Happened

1. `analysis_template.py` (84KB) and `_social_publish.py` (25KB) had 23 duplicate functions
2. `generate_social_draft` had divergent implementations with different data structures
3. `_retry` in AT had fewer retries (3) and fewer error types than SP (5)
4. New pipeline separates analysis (`analysis_template.py`) from social drafting (`_social_publish.py`)

## Safety Notes

- Deleting `analysis_template.py` lines 1936-2003 (`--social` block) is safe — nothing calls it
- `analysis_template.py` itself is still needed for analysis (called by `publish_social.py` without `-s`)
- `social-dynamic` skill docs were updated to reflect new pipeline
- `trade-review-workflow` skill audit notes updated