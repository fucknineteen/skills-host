# 时区规范：BJT 常量与违规扫荡

> 记录 2026-06-22 第1+2轮全量审计的时区修复历程

## 规范

**唯一正确写法**：`from _shared import BJT`

`BJT` 定义：
```python
BJT = timezone(timedelta(hours=8), 'Asia/Shanghai')
```

**禁止写法**：
- `timezone(timedelta(hours=8))` — 缺少时区名 `'Asia/Shanghai'`
- `timedelta(hours=8)` 拼接 — 不完整

## 扫荡命令

任何时候怀疑有时区违规，运行：

```bash
cd /root/.hermes/trade_review
grep -rn 'timezone(timedelta(hours=8))' --include='*.py' .
```

返回零结果才算干净。

## 修复历程

### 第1轮（本轮前修复）

| 文件 | 行号 | 修复 |
|------|------|------|
| `analysis_template.py` | L1082 | `timezone(timedelta(hours=8))` → `BJT` |
| `process_reviews.py` | L139 | `timezone(timedelta(hours=8))` → `BJT` |

### 第2轮（本轮修复）

| 文件 | 行号 | 修复 |
|------|------|------|
| `price_path_report.py` | L41 | `dt.replace(tzinfo=timezone(...))` → `dt.replace(tzinfo=BJT)` |
| `price_path_report.py` | L110 | 同上（`replace_all`） |
| `scripts/verify_workflow.py` | L130 | 添加 `from _shared import BJT`，删除函数内局部 `BJ` |

### verify_workflow.py 特殊处理

verify_workflow.py 位于 `scripts/` 子目录，需先 `sys.path.insert(0, str(BASE))` 才能 import `_shared`：

```python
from pathlib import Path
BASE = Path('/root/.hermes/trade_review')
sys.path.insert(0, str(BASE))
from _shared import BJT
```

然后再删除函数内的局部 `BJ = timezone(timedelta(hours=8))` 定义。

## 关联模式

时区违规常与以下模式共现：
- `datetime.fromtimestamp(ts, tz=...)` — 注意 `tz=` 参数
- `dt.replace(tzinfo=...)` — 用于给 naive datetime 附加时区
- `dt.astimezone(BJT)` — 转换到 BJ 时间（此法正确）

## 审计检查清单

- [ ] `grep -rn 'timezone(timedelta(hours=8))'` 是否零结果？
- [ ] 所有 `tzinfo=` 和 `tz=` 参数是否都用 `BJT`？
- [ ] `scripts/` 目录下的独立脚本是否已正确 `sys.path` + `from _shared import BJT`？
- [ ] `grep -rn 'strftime.*\+08:00'` 是否零结果？（应使用 `.isoformat()` 替代硬编码偏移）

## 🆕 硬编码 +08:00 vs isoformat() (2026-06-22 P3-6)

**禁止**：`datetime.now(BJT).strftime('%Y-%m-%dT%H:%M:%S+08:00')`
**正确**：`datetime.now(BJT).isoformat()`

`isoformat()` 自动附加 `+08:00` 时区偏移，且未来更换时区时无需手动改格式串。

### 本次修复实例

| 文件 | 行号 | 修复 |
|------|------|------|
| `trade_journal.py` | L32 | `strftime('...T%H:%M:%S+08:00')` → `.isoformat()` |
| `trade_journal.py` | L46 | 同上 |

### 扫荡命令

```bash
grep -rn 'strftime.*\+08:00' /root/.hermes/trade_review/ --include='*.py'
```
