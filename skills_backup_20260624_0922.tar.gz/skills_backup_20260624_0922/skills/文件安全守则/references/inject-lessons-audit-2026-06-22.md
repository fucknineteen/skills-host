# inject_lessons.py 审计实录 — 2026-06-22

> 完整 bug 清单，作为静态审计方法论的实战案例。11 个 bug，按严重度排序。

## 🔴 数据正确性

### BUG 1 — 系统性重复加载
- **位置**: `load_lessons()`, L22-40
- **根因**: 同时读取 `lessons.json`（所有 regime 文件的并集）和 `regimes/*_lessons.json`（各文件独立），但 `lessons.json` 已包含 regime 文件内容
- **证据**: 238 条加载，仅 116 条唯一，122 条重复（51.3%）
- **影响**: `.lesson_context.txt` 中每条教训出现 2×

### BUG 2 — 字段名不匹配：`summary` ≠ `lesson`
- **位置**: `build_context()`, L65: `l.get('lesson', '')`
- **根因**: `bull_correction_lessons.json` 用 `"summary"` 存储文本，reader 读 `"lesson"`
- **证据**: 8 条空 lesson 文本，全部来自 B1/B2/B3（bull_correction schema）
- **影响**: 输出 `- [?] SL锚定: ` （冒号后为空）

### BUG 3 — `coins` 数组被忽略
- **位置**: `build_context()`, L63: `l.get('coin', '?')`
- **根因**: L100/L101/L102 使用 `"coins": ["BTC", "ETH"]`（数组），reader 读 `"coin"`（字符串）
- **证据**: 14 条缺失 coin，其中 3 条因 `coins` 数组
- **影响**: 输出 `[?]`

## 🟡 健壮性/可观测性

### BUG 4 — 竞态：JSON 半写时被读
- **位置**: `load_lessons()`, L27/L39: `except JSONDecodeError: pass`
- **根因**: `process_reviews.py` 和 `inject_lessons.py` 可能同时操作同一文件。非原子写（直接 `open(w)` 覆盖）→ reader 读到半截 JSON → 全量丢弃无日志

### BUG 5 — TOCTOU 在 regime 文件发现
- **位置**: `load_lessons()`, L31-35: `listdir` → `open`
- **根因**: 文件可在两次系统调用之间被删除 → 静默吞没

### BUG 6 — 损坏 JSON 静默吞没
- **位置**: `load_lessons()`, L27/L39
- **根因**: `JSONDecodeError` 被 `pass` 丢弃，cron 消费者无感知

### BUG 7 — 缺 `date` → `days_ago=999` 魔法数
- **位置**: `build_context()`, L59
- **根因**: 无 date 字段的条目被赋值 999 → 归入 historical，但无法区分「真旧」vs「缺数据」

### BUG 8 — 无 `id` 去重
- **位置**: `load_lessons()` 无去重逻辑
- **根因**: B1/B2/B3 出现在两个 regime 文件中，且有 `id` 字段可识别，但未去重

## 🟢 代码质量

### BUG 9 — `os.listdir()` 非确定性
- **位置**: `load_lessons()`, L32
- **根因**: 文件系统顺序 → 输出排序每次不同

### BUG 10 — `datetime.now(BJT)` 调用两次
- **位置**: L49 vs L104
- **根因**: 文件头时间戳和 days_ago 计算用不同时刻

### BUG 11 — `coin` 格式不统一
- **位置**: 数据源问题，L63 暴露
- **根因**: `"coin": "BTC"` vs `"coin": "BTCUSDT"` → 同一资产不同标签

## 验证命令

```bash
# 统计重复和空字段
python3 -c "
import json
from inject_lessons import load_lessons
lessons = load_lessons()
seen = {}
dupes = empty = no_coin = no_date = 0
for l in lessons:
    key = (l.get('coin',''), l.get('date',''), l.get('lesson',''))
    if not l.get('lesson','').strip(): empty += 1
    if not l.get('coin',''): no_coin += 1
    if not l.get('date',''): no_date += 1
    if key in seen: dupes += 1; seen[key] += 1
    else: seen[key] = 1
print(f'Total: {len(lessons)}, Unique: {len(seen)}, Dupes: {dupes}')
print(f'Empty lesson: {empty}, Missing coin: {no_coin}, Missing date: {no_date}')
"
```
