# 跨文件系统性问题模式

> 来源：2026-06-22 四轮全量审计（~290 bugs 总计）+ 2026-06-23 第二轮全量审计（44 bugs）
> 用途：审计时对照此清单逐项检查，快速定位高频 Bug 类型

## 🏔️ 多层审计深度模型

**核心发现**：一轮审计永远不够。Bug 分布在不同深度层级：

| 层级 | 典型发现 | 审计轮次 |
|------|---------|:--:|
| **L1 表层** | 字段名/路径错误、大小写不匹配、死代码、默认值类型错 | R1 |
| **L2 控制流** | 跨文件判定不一致、V反保护盲区、条件分支遗漏、子串匹配假阳性 | R1+R2 |
| **L3 计算层** | EMA/RSI/ADX 数据顺序反向、MACD 双重 reversal、Wilder 平滑缺失 | R3 |
| **L4 集成层** | R3 修复引入的新 Bug、CDLHARAMI 键覆盖、SOS/HH-HL 值排序错、空 DB 崩溃 | R4 |

**审计原则**：每次修复后必须再审计一轮。每轮深入一层。不要因为上一轮「修了很多」就跳过验证 —— 修复本身会引入新 Bug（见 L4）。

## 🔴 致命级模式（必查）

### 1. 三地判定不一致 — 同一逻辑在多处独立实现
**受害者**: position/方向判定在 `_format_coin_section`、`_pos_quick`、wrapper `analyze_single_coin` 三处独立实现
**症状**: 同一币种同一时刻三处给出不同方向建议（试多 vs 观望 vs 偏空）
**检查方法**: grep 同一判定关键词（`near_bottom` / `resonance` / `偏多`）在所有文件中的出现位置，逐行对照逻辑
**修复原则**: 提取到单一函数，所有调用处 import 统一入口

### 2. 数据存储层错位 — 写入路径 ≠ 读取路径
**受害者**: `macro_external` 在 `regime_detector.py` 存入 `dimensions.macro_external`（嵌套），但 `_social_publish.py` 从顶层读 → 永远读到 `{}`
**症状**: JSON 文件中某字段始终为空/默认值/Null
**检查方法**: 对每个关键字段：grep 写入路径 → grep 读取路径 → 比对路径是否一致
**已修复案例**: `macro_external`、`near_bottom`、`session_vp`(曾存为 `vp_data`)

### 3. 数据方向反转 — 数组正序/逆序混用
**受害者**: 历史类比窗口、TA-Lib 形态识别
**症状**: 特征值/分类结果语义全错但无崩溃（静默错误）
**检查方法**: 搜索 `ORDER BY ts ASC` 和 `ORDER BY ts DESC`，核对下游消费代码的顺序假设

### 4. JSON 键名大小写不匹配
**受害者**: `verify_social_post.py` VP 键名 `POC` vs 实际 `poc`
**症状**: `.get('KEY', 0)` 永远返回默认值，校验静默跳过
**检查方法**: grep 所有 `.get('` 调用，与写入端字段名比对

### 19. 硬编码凭据/API Key 🆕 2026-06-22
**模式**: API Key、私钥、Token 以明文写在源码中
**实例**: `analysis_template.py` L33 `BINANCE_API_KEY='***'`，`scripts/analysis_altcoin.py` L19 同 Key 重复
**症状**: 任何有代码访问权限的人可直接使用凭据；Git 推送泄露风险
**检查方法**: `grep -rnE '(API_KEY|SECRET|TOKEN|PASSWORD)\s*=\s*['"'"'"]'` 搜索所有可能的硬编码凭据
**修复**: `os.environ.get('BINANCE_API_KEY', '')`

### 20. 数据源错配 — 同名字段但文件不同 🆕 2026-06-22
**模式**: 代码从文件 A 读取字段 X，但字段 X 只在文件 B 中被填充（文件 A 中虽有同名键但值永为空）
**实例**: `process_reviews.py` L503/695/707 从 `analysis.get('macro', {}).get('fear_greed')` 读 FG — `analyses.json` 的 `macro` 键存在但无 `fear_greed` 字段；FG 实际在 `social_analyses.json` 的顶层 `fg_val` 
**症状**: 字段永远返回 None/默认值 → 依赖该字段的保护逻辑永不触发（如 RSI<20+FG<20 极端超卖保护）
**检查方法**: 对关键字段逐文件 grep 查找写入位置（`'"field_name"'`），再确认代码从哪个文件/路径读取
**修复**: 添加回退链：`(analysis.get('macro') or {}).get('fear_greed') or analysis.get('fg_val')`

### 22. 缺失 import 导致运行时崩溃 🆕 2026-06-23
**模式**: 文件中使用 `datetime`/`traceback`/`re` 等模块但未在文件头 `import`，外层 try/except 吞掉 NameError → 静默失败
**实例**: `verify_workflow.py` L130 `datetime.fromisoformat()` 和 L296 `traceback.print_exc()` 均未 import；`audit_draft.py` L11 `import math` 全文未使用
**症状**: 脚本运行时抛出 NameError，但被外层 `except: pass` 或 `except Exception` 吞掉 → 功能失效但无报错日志
**检查方法**: 对每个文件执行 `python3 -c "import py_compile; py_compile.compile('file.py')"` + `grep -n 'datetime\|traceback\|re\|math\|subprocess' file.py | grep -v 'import '` 对比使用但未导入的模块
**修复**: 在文件顶部添加缺失的 import

### 23. 无操作字符串替换 🆕 2026-06-23
**模式**: `ts.replace('A', 'A')` 或 `ts.replace('+08:00', '+08:00')` — 替换目标与源相同，零效果
**实例**: `price_path_report.py` L39 `datetime.fromisoformat(ts.replace('+08:00', '+08:00'))` — 疑似原始意图是 `'+0800' → '+08:00'` 标准化时区格式
**症状**: 当输入为 `'+0800'`（无冒号）格式时，Python <3.11 的 `fromisoformat()` 直接崩溃
**检查方法**: 搜索 `\.replace\(.*,.*\)` 确认替换前后的字符串是否相同
**修复**: 确认原始意图，改为正确的替换对（如 `'+0800', '+08:00'`）

### 24. 冗余重复条件判断 🆕 2026-06-23
**模式**: `if x and x:` 或 `if x and x is not None:` — 同一变量判断两次，典型的复制粘贴残留
**实例**: `audit_draft.py` L221 `if hint_path_re and hint_path_re:`
**症状**: 功能无害（逻辑等价于 `if x:`），但表明代码未经审查，可能隐藏更深层的复制粘贴错误
**检查方法**: 搜索 `and .* and ` 模式
**修复**: 删除重复条件

### 25. 双版本代码分叉 🆕 2026-06-23
**模式**: 同一功能在两个路径下存在不同实现（如 `scripts/` vs `trade_review/scripts/`），一个版本有 BugFix 另一个没有，或一个并行一个串行
**实例**: `inject_lessons.py`（scripts 114行旧版 vs trade_review 180行新版含6个BugFix）；`scan_daytrade_coins.py`（scripts 并行版 vs trade_review 串行版缺预警功能）
**症状**: 维护两套代码增加不一致风险；cron 可能调用到劣化版本；修复一个版本后忘记同步另一个
**检查方法**: 对每个脚本搜索同名文件 `find . -name 'filename.py'`，用 `diff` 对比
**修复**: 删除旧版/劣化版，cron 指向新版；或统一为符号链接 + 参数控制差异行为

### 26. 评分阈值与筛选阈值量级不匹配 🆕 2026-06-23
**模式**: 前置筛选条件使用阈值 A，但评分逻辑使用阈值 B（A << B），导致所有通过筛选的样本落入同一评分档位
**实例**: `scan_daytrade_coins.py` 筛选 `abs(fr) <= 0.0003`（0.03%），但评分档位为 `< 0.005`（0.5%）→ 所有通过筛选的币种评分恒为 +20
**症状**: 评分完全失去区分度，所有候选币得分相同，排序/排名无效
**检查方法**: 对每个有筛选+评分的逻辑，确认筛选阈值 < 评分档位上限，否则评分无意义
**修复**: 缩小评分档位使其与筛选范围对齐

### 27. 备份旋转逻辑 off-by-one 🆕 2026-06-23
**模式**: 滚动备份循环从 i=4 到 1，但 `.bak`（i=1）被移动到 `.bak2` 后不再存在 → 下次循环找不到源文件跳过 → 实际只维护了 N-1 个备份
**实例**: `save_social_post.py` L90-95 备份旋转逻辑
**症状**: 注释称"max 5 rolling backups"实际只维护 4 个；`.bak` 永远只是瞬时文件
**检查方法**: 逐行模拟备份旋转过程，确认每个源文件在移动前确实存在
**修复**: 调整循环逻辑保留 `.bak` 或更新注释为实际数量

### 8. 覆盖检测 key 格式不匹配 🆕 2026-06-23
**模式**: 索引建表使用一种 key 格式，查找时使用另一种 key 格式 → 永远不命中
**实例**: `analysis_template.py` L1805 建索引用 `r.get('coin')` → `'BTC'`，L1841 查找用 `coin_key = f"{a['coin']}USDT"` → `'BTCUSDT'` → `('BTCUSDT', date) != ('BTC', date)` → 覆盖检测永远失效
**症状**: 同一天多次运行同币种会重复追加，analyses.json 不断膨胀
**修复**: 统一 key 格式
**⚠️ 二次投毒机制**: 若首次覆写成功（旧记录coin="BTCUSDT"与coin_key匹配），但新记录写入 `"coin": a['coin']`（="BTC"无后缀），则索引仍指向("BTCUSDT",date)→记录coin却是"BTC"。二次运行时从文件读到的coin="BTC"→索引key=("BTC",date)，但coin_key仍是"BTCUSDT"→不再匹配→覆写永久失效。修法：L2058写 `"coin": coin_key` 而非 `"coin": a['coin']`。

### 37. 代码注释声称数据不可获取但实际存在 🆕 2026-06-23
**模式**: 源码注释明确写"我们无法获取 X 数据"，但下游数据库/API 已包含该字段 → 使用了近似/合成数据替代真实数据
**实例**: `regime_detector.py` L1828-1829 `# We don't have real open prices from DB (only close/high/low/volume)` `# Approximate: use previous close as open` — 但 `klines` 表 schema 为 `(ts, open, high, low, close, volume)`，open 列始终存在
**症状**: K线形态检测基于合成数据（前收盘当开盘），高波动日假阳性/假阴率高
**修复**: 从 DB 读取真实 open 列；同时更新/删除过时注释

### 38. 循环搜索无匹配时静默成功 🆕 2026-06-23
**模式**: for 循环中搜索匹配行，找到后 break 出循环执行修复；若循环走完无 break（无匹配），直接跳到循环后的成功返回语句
**实例**: `jin10_mcp_guard.py` L59-71: 循环搜索 Bearer 行→找到则 break→写回配置→return True。若无 Bearer 行：循环走完无 break→L67 写回未修改的配置→L71 return True
**症状**: 修复失效但调用方认为成功，Token 过期后无告警
**检查方法**: 搜索 `for.*:.*if.*:.*break` 模式，检查循环后是否处理了"未找到"的情况
**修复**: 在循环后添加 found 标志检查，未找到时 return False + 记录 ERROR 日志

### 41. 配置文件 read-modify-write 竞态 🆕 2026-06-22 R4
**模式**: `read config → modify → write config` 三步非原子 — 两个进程同时读旧版本，各自修改后写入，后者覆盖前者
**实例**: `jin10_mcp_guard.py` L55-73 `open(CONFIG) → readlines → modify → open(CONFIG, 'w') → writelines`
**症状**: 并发修复时丢失另一进程的修改
**修复**: 写临时文件 `tmp = CONFIG + '.tmp'` → `open(tmp, 'w')` → `os.replace(tmp, CONFIG)`（rename 是原子的）

### 42. 竞态锁文件非原子创建 🆕 2026-06-22 R4
**模式**: `with open(LOCKFILE, "w")` 有 TOCTOU 漏洞 — 两个进程同时执行时都会写入，锁失效
**实例**: `jin10_mcp_guard.py` L147 `with open(LOCKFILE, "w")` — cron 每 5 分钟调度，两个实例可能同时运行
**症状**: 多个进程同时认为自己是"唯一"，导致 gateway 被多次重启
**修复**: 用 `os.open(LOCKFILE, os.O_WRONLY | os.O_CREAT | os.O_EXCL, 0o644)` 原子创建；失败时重新检查冷却期

### 43. 字典值 0 被 falsy 跳过 🆕 2026-06-22 R4
**模式**: `if d.get('key')` — 当 key 存在且值为 0 时，`bool(0) == False` → 条件跳过
**实例**: `verify_social_post.py` L76 `if r.get('coin') == 'FG' and r.get('fg_val')` — FG 指数为 0 时（极端恐惧）被跳过
**症状**: 合法 0 值被当成"无数据"跳过
**修复**: `if r.get('fg_val') is not None` 而非 `if r.get('fg_val')`

---

## 🟠 高优模式

### 5. V反保护盲区 — 部分路径缺失保护
**受害者**: `_pos_quick`、`extract_direction` 缺 8 根 4H 反弹 >3% 检测
**症状**: 做空信号在 V 形底部仍被触发
**检查方法**: 搜索 `near_bottom` 出现的所有位置，确认每个做空/偏空判定点都有对应保护

### 6. 默认值/回退值类型错误
**受害者**: `data_selection` 默认 `{}`（dict）但实际是 `str`
**症状**: 下游 `.get()` 返回错误类型 → 静默退化
**检查方法**: 对每个 `.get(key, default)` 调用，检查写入端的实际类型

### 7. 子进程传参类型不兼容
**受害者**: `--fg` 传入 `composite_score`（浮点 3.5）→ `argparse type=int` → `SystemExit`
**症状**: 必崩（100% 触发）
**检查方法**: 搜索所有 `subprocess.run` 调用，比对传参类型与接收端 argparse 定义

### 9. 模块级 NOW 变量冻结 🆕 2026-06-23
**模式**: `NOW = datetime.now(BJT)` 在模块级（非函数内）定义 → import 时固化
**实例**: `analysis_altcoin.py` L17 `NOW = datetime.now(BJT)`
**症状**: 脚本运行超过 1 分钟后时间戳过时；cron 场景下以 import 时刻而非执行时刻计时
**修复**: 移到函数内部或作为参数传入

### 28. 归档时区比较错误 🆕 2026-06-23
**模式**: naive BJT 时间与 naive UTC 时间直接比较 → 差 8 小时
**实例**: `process_reviews.py` L1018 `cutoff = now_bj.replace(tzinfo=None) - timedelta(days=30)`（naive BJT）与 L1020 `ts.replace(tzinfo=None) < cutoff`（ts 是 UTC，naive 后是 naive UTC）
**症状**: 归档判断提前/延后 8 小时，可能导致记录被错误归档或遗漏
**检查方法**: 搜索所有 `.replace(tzinfo=None)` 后的比较操作，确认两侧时区一致
**修复**: 统一使用 UTC 比较，或统一使用 BJT 比较

---

## 🟡 中等模式

### 10. 死代码覆盖 — 旧格式提取永不执行
**模式**: `if 'old_field' in a:` 检查旧格式字段 → `analyze_single_coin()` 从不设置这些键 → 永假分支
**受害者**: analysis_template.py 7 段旧格式 VP/wyckoff/kline_pattern 提取
**检查方法**: 搜索 `in a:` 或 `a.get('old_key')`，确认该键是否在数据生成函数中设置

### 11. 计数覆盖 — 循环中用 count 而非递增计数器
**模式**: `count = len([...])` → 同值多次覆盖
**受害者**: LPS 索引（LPS1/LPS2 被覆盖）
**修复**: 用 `counter += 1`

### 12. 子串匹配假阳性 — `str(val) in text` 无边界
**模式**: RSI=46 匹配到价格 `"63460"` 中的 `"46"`
**受害者**: verify_social_post.py 指标核验
**修复**: 用 `re.search(r'\b' + re.escape(str(val)) + r'\b', text)`

### 13. 空字段写入 JSON
**模式**: 字段初始化为 `{}` 或 `[]` 后从未赋值 → 写入 JSON 的死数据
**实例**: `analysis_template.py` L1972 `data_vol = {}` 始终为空
**症状**: JSON 文件中有无意义的空字段，增加文件体积
**修复**: 移除无用字段或补充实际数据填充逻辑

### 14. 函数签名跨文件不同步 🆕 R3→R4
**模式**: 修改函数签名（删参数）后未跨文件检查调用点 → TypeError
**实例**: `calc_sl_tp()` 在 `_social_publish.py` 删了 `session_vp`，但 `publish_social.py` 仍传 6 参 → 崩溃
**检查方法**: `grep -rn 'func_name(' /root/.hermes/trade_review/` — 修改签名前必查

### 15. 字典键覆盖 🆕 R4
**模式**: 同一 dict 中两次赋值同一键 → 前者被静默覆盖
**实例**: `regime_detector.py` 中 `'CDLHARAMI': ('bull-harami', 10)` 被后面的 `'CDLHARAMI': ('bear-harami', -10)` 覆盖 → 看涨孕线永久丢失
**检查方法**: `python3 -c "import ast; ..."` 检测 dict 字面量中重复键

### 16. 排序数组误用为时序 🆕 R4
**模式**: `sorted(set(...), reverse=True)` → 值降序数组被当作时序数组使用
**实例**: `wyckoff_detect()` SOS 检测用 `highs[0] > max(highs[3:10])`（降序列表中恒真）+ HH/HL 判断用 `highs[0]>highs[1]>highs[2]`（恒真）
**检测方法**: 搜索 `sorted(` + `reverse=True`，检查下游是否按索引当作时间序列使用

### 17. 格式化字符串 vs 原始枚举死比较 🆕 2026-06-22
**模式**: 字段存储格式化/衍生字符串（如 `"+1/3 (道氏:+1/威科夫:0/价位:0)"`），但比较时用原始枚举值（如 `== '错误'`）
**实例**: `process_reviews.py` 中 `review_12h == '错误'` — `review_12h` 是格式化评分字符串，从来不会等于 `'错误'` → 条件永不触发
**症状**: 静默死条件 —— 不崩溃、不报错、lint 不告警，但逻辑永久失效
**检查方法**: 对任何 `str_field == '枚举值'` 或 `str_field in ('a', 'b')` 的字符串比较，向前追溯该字段的赋值语句，确认值的实际格式
**修复**: 改用底层数值字段（如 `review_12h_result.direction_score == -1`）

### 18. `is` 过滤 + `list.remove()` 语义不一致 🆕 2026-06-22
**模式**: 用 `is`（身份比较）过滤列表元素，但用 `list.remove()`（值比较，`==`）删除
**实例**: `others = [r for r in items if r is not best]; for r in others: reviews.remove(r)`
**场景**: 当存在两条值完全相同但对象不同的 dict 时，`r is not best` 正确剔除了 best 对象，但 `reviews.remove(r)` 用 `==` 在列表中查找 → 找到的第一个 `==` 匹配是 `best` → 删除了最高分记录而非重复项
**症状**: 去重后保留的错误记录（低分保留，高分被删）
**修复**: 全程用对象身份：`remove_ids = {id(r) for r in to_remove}; reviews[:] = [r for r in reviews if id(r) not in remove_ids]`

### 21. 模块级静态时间戳冻结 🆕 2026-06-22
**模式**: `NOW_BJ = datetime.now(BJT)` 在模块加载时执行（import 时）→ 后续所有使用该变量的代码获取的都是 import 时刻的时间戳
**实例**: `publish_social.py` L31-32 `_NOW_UTC = datetime.now(timezone.utc); NOW_BJ = _NOW_UTC.astimezone(BJT)` — L320 用 `NOW_BJ.strftime('%Y-%m-%d')` 过滤当天记录
**症状**: 脚本运行超过 1 分钟后 / 跨日边界（23:59:59 启动）→ 日期过滤用昨天的日期 → 当天新记录被误删或重复
**检查方法**: `grep -rn '= datetime.now('` 查找模块级（非函数内）的时间戳赋值
**修复**: 改为函数 `def _now_bj(): return datetime.now(timezone.utc).astimezone(BJT)`，所有引用改为 `_now_bj()` 调用

---

## 🟢 低优模式

### 32. 重复代码块
**模式**: if/else 双分支开头都调用了相同的 fetch 代码
**实例**: `analysis_template.py` L1740-1746 `fetch_okx_ticker/funding` 在两个分支中重复
**修复**: 提取到 if/else 之前公共部分

### 33. 未使用的返回值
**模式**: 函数返回多个值但调用方只使用部分，或未使用返回值
**实例**: `monitor_and_sync.py` L603 `all_highest, all_lowest` 返回值从未使用
**修复**: 删除未使用的返回值或添加使用逻辑

### 34. 硬编码过期日期
**模式**: HARDCODED_EVENTS 硬编码到特定日期，过期后需手动维护
**实例**: `jin10_fallback.py` L26-58 HARDCODED_EVENTS 到 2026-08-13；`regime_detector.py` L2232 硬编码 2026-06-18
**症状**: 过期事件不会自动清理，新事件不会自动添加
**修复**: 从动态数据源（如 jin10_calendar_cache.json）读取，或设置自动过期清理

### 35. 日期匹配模式过于狭窄
**模式**: `'2026-06-1'` 匹配 `2026-06-10`~`19`，但不匹配 `2026-06-01`~`09`
**实例**: `verify_workflow.py` L172 `'2026-06-1' in str(daily[1])`
**症状**: 月初会误报 stale
**修复**: 使用 `datetime` 解析比较或 `'2026-06-' in str(daily[1])`

### 36. 参数无范围校验
**模式**: argparse 接受任意整数但业务逻辑要求特定范围
**实例**: `save_social_post.py` `--fg` 接受任意整数，无 0-100 校验
**修复**: 添加 `choices=range(0, 101)` 或手动校验

### 29. 布尔短路在 0 值失效
**模式**: `if rsi and rsi < 20` — RSI=0 时 `bool(0)=False` → 条件跳过
**修复**: `if rsi is not None and rsi < 20`

### 30. 共享 list 引用污染
**模式**: `flash_news = _all_flash_news` → 所有币种持有同一 list 对象
**修复**: 用 `[dict(item) for item in items]` 做深拷贝

### 31. 计算顺序错误
**模式**: `running_max = max(running_max, c[2])` 后 `rally = (c[2]-running_max)/running_max` → max_rally 永远为 0
**修复**: 先算 rally 再更新 running_max

---

## 审查清单（审计时逐项对照）

- [ ] 同一判定逻辑在多少处实现？逐一比对
- [ ] 关键字段写入路径 vs 读取路径是否一致？
- [ ] 数组数据顺序假设（ASC/DESC）是否与消费方匹配？
- [ ] 所有 `.get()` JSON 键名与写入端一致（含大小写）？
- [ ] V反/保护逻辑是否覆盖所有做空/偏空判定点？
- [ ] `.get()` 默认值类型与实际数据类型是否一致？
- [ ] 子进程传参类型是否与 argparse 定义兼容？
- [ ] 是否存在 `if 'old_key' in a` 永假死代码？
- [ ] 计数器是否使用递增而非 count 覆盖？
- [ ] 字符串匹配是否使用了词边界？
- [ ] 是否存在 `if val` 短路吞掉合法 0 值？
- [ ] 是否存在 list/dict 引用共享而非拷贝？
- [ ] 修改函数签名后是否 `grep -rn` 检查了所有跨文件调用点？🆕
- [ ] dict 中是否存在同名键覆盖？🆕
- [ ] `sorted(..., reverse=True)` 的数组是否被误当作时序使用？🆕
- [ ] 格式化/衍生字符串字段是否被当作原始枚举值比较？🆕 2026-06-22
- [ ] 去重逻辑中 `is` 和 `remove()` 是否一致使用对象身份？🆕 2026-06-22
- [ ] 计算层函数（ema/rsi/adx/macd）的数据顺序假设是否与调用方一致？🆕 R3
- [ ] 是否存在硬编码 API Key/凭据明文？🆕 2026-06-22
- [ ] 同名字段是否确认了正确的数据源文件？🆕 2026-06-22
- [ ] 模块级 `datetime.now()` 是否已改为函数封装？🆕 2026-06-22
- [ ] 缺失 import 导致运行时崩溃？🆕 2026-06-23
- [ ] 无操作字符串替换 `ts.replace('A', 'A')`？🆕 2026-06-23
- [ ] 冗余重复条件 `if x and x:`？🆕 2026-06-23
- [ ] 双版本代码分叉？🆕 2026-06-23
- [ ] 评分阈值与筛选阈值量级不匹配？🆕 2026-06-23
- [ ] 备份旋转逻辑 off-by-one？🆕 2026-06-23
- [ ] 覆盖检测 key 格式不匹配？🆕 2026-06-23
- [ ] 空字段写入 JSON？🆕 2026-06-23
- [ ] 归档时区比较错误？🆕 2026-06-23
- [ ] 代码注释声称数据不可获取但数据库中实际存在该字段？🆕 2026-06-23
- [ ] 循环搜索无匹配时是否静默返回成功？🆕 2026-06-23
- [ ] 数据变换后的格式是否与排除/过滤条件一致？🆕 2026-06-23
- [ ] 配置文件读写是否使用原子写入（`os.replace`）防止竞态？🆕 2026-06-22
- [ ] 锁文件创建是否使用 `O_EXCL` 原子创建？🆕 2026-06-22
- [ ] `d.get('key')` 是否错误地将合法 0 值当作 falsy 跳过？🆕 2026-06-22
