# 批量 patch 引入回归的常见坑点

> 来源：2026-06-22 全工作流 14 项修复 → 二次审计发现 5 项新问题（3🔴 + 2🟡）

## 坑点 1：变量作用域退化

**模式**：将 `a['field'] and extra_cond1 and extra_cond2` 简化为 `field` 时，忘记加回 `a.get()` 或 `a[]`。

**实例**：
```python
# 旧代码
if '强' in str(resonance) or (a['near_bottom'] and macd_4h_val > -50 and rsi_1h_val < 45):
    pos_dir = '试多'

# ❌ 错误简化 — near_bottom 不在当前作用域
if '强' in str(resonance) or near_bottom:
    pos_dir = '试多'

# ✅ 正确简化 — 显式从 a 取值
if '强' in str(resonance) or a.get('near_bottom'):
    pos_dir = '试多'
```

**检测方法**：`grep -n 'near_bottom\|some_var' target.py` 确认变量有定义/赋值语句在引用行之前。

## 坑点 2：patch 工具正则转义漂移

**模式**：patch 工具传入 `\\d` 时可能被序列化层二次转义为 `\\\\d`，导致 Python raw string 中的正则含义改变。

**实例**：
```python
# 修复时传入的 new_string
"""rf'入场([\\d.]+)'"""

# 文件中实际写入（被双重转义）
rf'入场([\\\\d.]+)'
#               ^^^^ 在 raw string 中 = 正则 \\d → 匹配字面反斜杠 + 'd'
#               而非 \d → 匹配数字
```

**检测方法**：
```bash
python3 -c "
with open('target.py') as f:
    for i, line in enumerate(f, 1):
        if 're.search' in line and '\\\\\\\\d' in line:  # 4 consecutive backslashes
            print(f'L{i}: SUSPICIOUS ESCAPING')
"
# 然后用真实文案测试正则匹配
python3 -c "
import re
m = re.search(r'入场([\d.]+)', '入场64268')
print('PASS' if m else 'FAIL')
"
```

## 坑点 3：多站逻辑对齐遗漏

**模式**：同一判定逻辑在 stdout 输出函数、wrapper 函数、JSON builder 三处各自实现。修一处后，另两处可能仍有旧逻辑。

**实例（本次修复前）**：
| 判定逻辑 | stdout L1293 | wrapper L150 | JSON L2036 |
|----------|:--:|:--:|:--:|
| 偏多: near_bottom | ✅ | ❌ 缺失 | ✅ |
| 偏空: rsi>65+MACD<-50 | ✅ | ❌ 缺失 | ❌ 缺失 |

**检测方法**：修复后逐站列出判定条件，逐行比对。用表格形式一目了然。

## 坑点 4：死条件修复不完整

**模式**：修改 `if A <= x <= B: ... elif C <= x <= D:` 时，仅调整条件边界但未考虑新边界下 else 分支的含义变化。

**实例**：
```python
# 旧（死条件：-24 <= hours <= 0 被 -12 <= hours <= 48 完全覆盖）
if -12 <= hours <= 48:
    return ...  # 距公布
elif -24 <= hours <= 0:
    return ...  # 数据后 → 永不触发

# ✅ 修复：缩小第一个条件，让第二个复活
if 0 < hours <= 48:
    return ...  # 距公布（仅事件前）
elif -24 <= hours <= 0:
    return ...  # 数据后（仅事件后）
```

**检测方法**：画出条件区间在数轴上的覆盖范围，确认无重叠无遗漏。

## 坑点 5：跨文件函数签名不同步

**模式**：修改函数签名（增/删/改参数）后，未检查所有跨文件调用点 → 参数数量不匹配 → TypeError 崩溃。

**实例（2026-06-22 R3→R4）**：
```python
# R3 修复：从 _social_publish.py 的 calc_sl_tp() 删除了 session_vp 参数
# 修改前：def calc_sl_tp(entry, near_s, near_r, atr, pos_label, session_vp=None):
# 修改后：def calc_sl_tp(entry, near_s, near_r, atr, pos_label):

# ❌ 但 publish_social.py L329 的调用点未同步：
sl_val, tp_val, rr_str = calc_sl_tp(entry, lows, highs, atr_4h_val, pos_dir, svp)
#                                                                              ^^^ 第6个参数！
# 运行时 → TypeError: calc_sl_tp() takes 5 positional arguments but 6 were given
```

**根因**：`calc_sl_tp` 在 `_social_publish.py` 中定义，但 `publish_social.py` 也调用了它。修改签名时只看了定义文件的调用方，遗漏了跨文件调用点。

**检测方法**：
```bash
# 修改前：找到 ALL 调用点（跨文件搜索）
grep -rn 'calc_sl_tp(' /root/.hermes/trade_review/
# 修改后：用 py_compile 只能检测语法，不能检测运行时 TypeError
# 必须手动数参数数量，或写一个快速 import + inspect 脚本
python3 -c "
from target import func
import inspect
sig = inspect.signature(func)
print(f'Parameters: {len(sig.parameters)}')
"
```

**预防原则**：修改任何被多个文件调用的公共函数签名时，在 commit message 中标明「BREAKING: signature changed」，并用 `grep -rn` 确认所有调用点已同步。
