# scripts/ 子目录脚本导入 _shared 失败的修复模式

> 发现: 2026-06-23  
> 影响: `inject_lessons.py`, `gen_charts.py`

## 问题
`scripts/` 下脚本 `from _shared import BJT` 失败 → `ModuleNotFoundError`，因 `_shared.py` 在父目录。

## 修复模式 A — cron 运行（绝对路径）
```python
import sys
sys.path.insert(0, '/root/.hermes/trade_review')
from _shared import BJT, TRADE_DIR
```

## 修复模式 B — 手动运行（相对路径）
```python
import sys, os
sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..'))
from _shared import BJT
```
