# 2026-06-22 审计实录 — 第二轮（跨文件 + 安全）

## 审计范围
25 个 Python 文件（`trade_review/` + `scripts/` + `~/.hermes/scripts/`），约 8 项新发现。

## 新发现的 Bug 模式

### 1. `datetime.fromisoformat()` 脆弱性
- **文件**: `process_reviews.py:125,132`（已修复）、`price_path_report.py:39`
- **症状**: 无 try/except 包裹，非标准 ISO 格式（空格分隔、Python <3.11）→ ValueError
- **修复**: 全部加 `try: ... except (ValueError, TypeError): return None`
- **grep 命令**: `grep -rn 'fromisoformat' --include='*.py' .`

### 2. 硬编码 API Key
- **文件**: `analysis_template.py:33` + `scripts/analysis_altcoin.py:19`
- **症状**: 同一 `BINANCE_API_KEY='***'` 明文在两个文件
- **修复**: `os.environ.get('BINANCE_API_KEY', '')`，Key 写入 `~/.bashrc`
- **grep 命令**: `grep -rn "API_KEY\|SECRET\|TOKEN" --include='*.py' .`

### 3. FG（恐惧贪婪指数）数据源错配
- **文件**: `process_reviews.py:503,695,707`
- **症状**: 代码读 `analysis.get('macro', {}).get('fear_greed')`，但 `analyses.json` 的 `macro` 键没有 `fear_greed` 字段（只有 `fred`/`market`）
- **实际数据位置**: `social_analyses.json` 的 `fg_val` 字段
- **修复**: 添加回退链 `(analysis.get('macro') or {}).get('fear_greed') or analysis.get('fg_val')`
- **教训**: 子代理断言 "analyses.json 无 macro 键" 是错的——macro 存在但缺少 fear_greed。**任何子代理的数据断言都需二次验证**

### 4. 模块级时间戳冻结
- **文件**: `publish_social.py:31-32`
- **症状**: `NOW_BJ = datetime.now(BJT)` 在 import 时固化，L320 用于过滤"今天"记录
- **影响**: 跨日边界（23:59:59）运行会误用昨天日期
- **修复**: 改为 `def _now_bj(): return datetime.now(timezone.utc).astimezone(BJT)`

### 5. `timezone(timedelta(hours=8))` 应统一为 BJT
- **文件**: `price_path_report.py:41,110` + `verify_workflow.py:130`（已修复全部 3 处）
- **规范**: 全项目统一用 `_shared.py` 的 `BJT = timezone(timedelta(hours=8), 'Asia/Shanghai')`

### 6. 重复文件问题
- **`inject_lessons.py`**:
  - `/root/.hermes/trade_review/inject_lessons.py` (180行，新版，6 BugFix)
  - `/root/.hermes/scripts/inject_lessons.py` (114行，旧版) ← Cron 跑这个！
  - 修复: 新版覆盖旧版，双副本一致
  - ⚠️ Cron `script` 字段只接受 `~/.hermes/scripts/` 下的相对路径，所以 scripts 副本必须保留
- **`scan_daytrade_coins.py`**:
  - `/root/.hermes/scripts/scan_daytrade_coins.py` (356行，并行版，ThreadPoolExecutor)
  - `/root/.hermes/trade_review/scripts/scan_daytrade_coins.py` (330行，串行版)
  - 修复: 并行版覆盖串行版

### 7. `price_path_report.py` 双重 ×1000 被 min() 掩盖
- **文件**: `price_path_report.py:116`
- **症状**: `int(datetime.now(...).timestamp() * 1000) * 1000` → 微秒值。但 `min(毫秒, 微秒)` 永远选毫秒 → bug 被掩盖
- **修复**: 去掉多余 `* 1000`

## Cron 特殊限制
- `cronjob` 的 `script` 字段**只能填 `~/.hermes/scripts/` 下的相对文件名**，不支持绝对路径
- 需要 cron 执行的脚本若在其他目录，必须 `cp` 一份到 `~/.hermes/scripts/`
- 维护约定: `trade_review/` 是开发源 → 改完后 cp 到 `scripts/`

## 验证链
- 6/6 文件 py_compile 通过
- 6/6 import 链通过
- `BINANCE_API_KEY` 环境变量 + `~/.bashrc` 持久化
- 全局 `timezone(timedelta(hours=8))` 零残留（grep 验证）
