# `or`-短路吞零陷阱 — 重构 helper 函数时的回归 Bug

> 发现日期: 2026-06-23 第三次审计  
> 严重度: 🔴 数据正确性  
> 文件: `process_reviews.py` `_extract_rsi()` / `_extract_fg()`

## 根因

从原始代码提取共享 helper 函数时，原始使用 `is not None` 保护零值，但新 helper 被简化为 `x or y` 模式，导致合法零值被 `or` 吞掉。

## 原始代码（正确）

```python
# extract_lessons L544-546（原始，正确）
rsi_val = analysis.get('rsi_14')
rsi = rsi_val if rsi_val is not None else analysis.get('rsi_4h')
fg = (analysis.get('macro') or {}).get('fear_greed') or analysis.get('fg_val')
```

## 重构后（错误 — 第二轮审计引入）

```python
# 新 _extract_rsi（错误）
return analysis.get('rsi_14') or analysis.get('rsi_4h', default)
# ↑ RSI=0 → 0 is falsy → or 回退到 rsi_4h → 静默返回错误值

# 新 _extract_fg（错误）
return analysis.get('fg_val') or analysis.get('macro_external', {}).get('fg_actual')
# ↑ FG=0 → 0 is falsy → or 回退到 fg_actual → 返回 None
```

## 修复后（正确 — 第三次审计修复）

```python
def _extract_rsi(analysis, default=50):
    if not analysis: return default
    ind = analysis.get('indicators', {})
    rsi = ind.get('4H', {}).get('rsi') if ind else None
    if rsi is not None: return rsi       # ← 显式 None 检查，零值通过
    rsi = analysis.get('rsi_14')
    if rsi is not None: return rsi       # ← 显式 None 检查，零值通过
    return analysis.get('rsi_4h', default)

def _extract_fg(analysis):
    if not analysis: return None
    macro = analysis.get('macro', {})
    fg = macro.get('fear_greed') if macro else None
    if fg is not None: return fg         # ← 显式 None 检查，零值通过
    fg = analysis.get('fg_val')
    if fg is not None: return fg         # ← 显式 None 检查，零值通过
    return analysis.get('macro_external', {}).get('fg_actual')
```

## 验证

```python
_extract_rsi({'rsi_14': 0, 'rsi_4h': 50}) → 0  ✅
_extract_fg({'fg_val': 0})                  → 0  ✅
```

## 教训

1. **提取值为数值的 helper 时，一律用 `is not None` 显式检查**，禁止 `or` 回退
2. **测试边界 0** — RSI=0 和 FG=0 是合法值（极端超卖/极端恐惧）
3. **多轮审计的必要性** — 第二轮提取 helper 时引入的回归 bug，在第三轮才被发现
