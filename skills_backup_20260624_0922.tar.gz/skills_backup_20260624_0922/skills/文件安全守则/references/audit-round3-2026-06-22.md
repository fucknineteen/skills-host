# Audit Round 3 — 2026-06-22

## Scope
37 bugs across 25+ Python files (~17,500 LOC). Two rounds: R1 (37 items), R2 (21 items). Total 58 items.

## Key Patterns Discovered

### 1. Cover-Detection Key Mismatch
- Writer: `coin_key = f"{a['coin']}USDT"` → 'BTCUSDT'
- Record: `"coin": a['coin']` → 'BTC'
- Result: `(BTCUSDT, date) != (BTC, date)` → cover never triggers → JSON grows unbounded
- Fix: Use `a['coin']` consistently

### 2. Candlestick Open Price Synthesis
- `opens[:-1] = closes[1:]` shifts open by 1 bar → all TA-Lib patterns operate on fake data
- DB already has `open` column → just SELECT it
- Impact: All candlestick pattern detection (18 patterns) was based on synthetic data

### 3. RPC Closure Duplication
- Two `def rpc()` closures in `jin10_fallback.py` (~20 lines each)
- One captures `Mcp-Session-Id`, the other doesn't
- Fix: Extract `_rpc()` module-level + `_make_rpc_fn()` factory with `capture_sid` flag

### 4. FG Data Lookup Duplication
- Style 1 reads JSON file fresh; Style 4 iterates records list
- Both extract `fg_val`/`fg_label` from coin=='FG' record
- Fix: `_extract_fg()` helper accepting file path or records list

### 5. Contract Value Silent Default
- `CONTRACT_VALUES.get(coin, 0.1)` silently uses 0.1 for unknown coins
- PnL calculation becomes completely wrong
- Fix: Explicit None check + stderr warning

### 6. Substring Coin Match
- `if coin in path` → 'ETH' matches 'ETHEREUM'
- Fix: Split path on separators, match only in path_parts

## Verification
- 17 files: py_compile ✅
- 5 import chains: ✅
- 0 failures

## Changes by Category
| Category | Count |
|----------|-------|
| P0 Fatal | 6 |
| P1 Logic | 10 |
| P2 Redundancy | 11 |
| P3 Style | 12 |
