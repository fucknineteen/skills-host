# 大规模代码审计的并行委托模式

> 来源：2026-06-23 第二轮全量审计
> 用途：指导如何对 ≥25 个文件 / ≥15,000 行代码进行系统化并行审计

## 适用场景

- 代码库 ≥ 25 个 Python 文件
- 总行数 ≥ 15,000 行
- 需要全面审计（逻辑性、Bug、冗余、时区、安全）

## 分组策略

将文件按**功能域**分组，每组分配一个子代理：

| 组 | 文件数 | 子代理任务 |
|----|--------|-----------|
| A: 核心分析引擎 | 1 | analysis_template.py (2179行) |
| B: 社交发布+数据层 | 5 | _social_publish.py, publish_social.py, verify_social_post.py, regime_detector.py, monitor_and_sync.py |
| C: 复盘+辅助脚本 | 8 | process_reviews.py, inject_lessons.py, analysis_altcoin.py, gen_charts.py, jin10_fallback.py, massive_client.py, place_live_orders.py, _shared.py |
| D: Cron+辅助 | 5 | inject_lessons.py(scripts), jin10_mcp_guard.py, scan_daytrade_coins.py(×2), price_path_report.py |
| E: 其他辅助 | 6 | trade_journal.py, audit_draft.py(×2), review_last_post.py, save_social_post.py, verify_workflow.py, extract_social_data.py |

## 委托提示词模板

每个子代理的 prompt 应包含：
1. **角色声明**：你是代码审计专家
2. **纪律声明**：严格按照代码修改规范 skill 的铁律执行：只读不修改
3. **审计范围**：明确文件列表和行数
4. **审计维度**：逻辑性、Bug、冗余、时区、安全
5. **上次审计问题复验**：列出需要重新验证的上次问题
6. **输出格式**：P0/P1/P2/P3 等级 + 文件路径:行号 + 问题描述 + 建议修复方案

## 跨文件比对步骤

子代理返回结果后，主代理执行：
1. **去重**：同一问题被多个子代理发现 → 合并为一条
2. **验证关键发现**：对 P0/P1 问题，自行 `grep`/`read_file` 二次确认
3. **交叉引用**：检查不同组之间的数据流（如 analysis_template.py 写入 vs process_reviews.py 读取）
4. **汇总统计**：按等级分类计数

## 注意事项

- 子代理的"已验证"声明不可采信，必须自行验证
- 每个子代理的 toolsets 设为 `["file", "terminal"]`
- 子代理之间不需要通信（各自独立审计不同文件）
- 子代理完成后可设置较长 timeout（180-300 秒），因为需要读取大量文件

## 实战效果

2026-06-23 第二轮审计使用 4 路子代理并行，总耗时 ~160 秒，发现 44 个问题（6 P0 / 11 P1 / 15 P2 / 12 P3）。
