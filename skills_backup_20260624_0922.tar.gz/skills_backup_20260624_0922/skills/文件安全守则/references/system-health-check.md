# 全流程健康检查模式

> 适用场景：定期检查脚本/导入/Cron/路径是否全部正常

## 检查清单

| 检查项 | 方法 | 预期 |
|--------|------|------|
| 语法/Import | `python3 -c "import xxx"` 逐脚本 | 20/20 PASS |
| 交叉引用 | grep import 路径是否可解析 | 无 `ModuleNotFoundError` |
| 文件存在性 | 检查 `scripts/` 子目录中文件 | 无断链/缺失 |
| Cron 状态 | `hermes cronjob list` | 全部 enabled=true, last_status=ok |
| 硬编码路径 | grep 绝对路径 → `ls` 验证 | 全部存在 |
| 配置文件 | 检查 `.env` / `config.json` 是否存在 | 就位 |
| 符号链接 | `find -type l -! -exec test -e {} \; -print` | 无断链 |

## 快捷执行

```bash
cd /root/.hermes/trade_review

# 1. 语法检查（全量）
for f in analysis_template.py _social_publish.py publish_social.py process_reviews.py verify_social_post.py regime_detector.py monitor_and_sync.py jin10_fallback.py inject_lessons.py price_path_report.py _shared.py massive_client.py; do
    python3 -c "import ${f%.py}" 2>&1 && echo "✅ $f" || echo "❌ $f"
done

# 2. 断链检查
find /root/.hermes/trade_review -type l -! -exec test -e {} \; -print

# 3. Cron 检查
hermes cronjob list

# 4. DB 完整性（如果 check_db_integrity.py 可用）
python3 monitor_and_sync.py BTC ETH SOL DOGE
```

## 已知持久问题

- `trade_review/scripts/check_db_integrity.py` → 符号链接断裂（目标目录已删除）
- `trade_review/scripts/verify_workflow.py` L94 → 硬编码旧路径 `/root/.hermes/skills/research/trade-review-workflow/SKILL.md`（实际在 `分析/加密货币纯分析/SKILL.md`）

## 多轮全量审计模式 🆕 2026-06-22 (五轮验证)

> 实践证明：大规模代码库修复需要**多轮递进式审计**，而非仅两轮。
> 本次会话五轮审计共发现 ~343 个 Bug（含 3 个修复过程中自创的 NEW Bug）。

### 审计原则

1. **全量不跳跃** — 读取 ALL 文件 ALL 行，不「只审计几个关键位置」
2. **多轮递进** — 首轮架构层面，后续深入底层计算/图表/辅助脚本
3. **并行委托** — 用 `delegate_task` 分批并行，每批 3 个子代理
4. **严重度排序** — P0→P1→P2→P3，逐级修复
5. **每修复验证** — `py_compile` + 跨文件一致性比对
6. **修复=全修** — 不提供选择题，全部逐项修复

### 每轮流程

```
① delegate_task x3（按文件分组并行审计）
② 汇总发现 → 按 P0/P1/P2/P3 分类
③ delegate_task xN（按文件分组并行修复）
④ py_compile 全量语法验证
⑤ 进入下一轮
```

### 五轮 Bug 密度趋势

| 轮次 | 发现 | P0 致命 | 特征 |
|:--:|:--:|:--:|------|
| R1 | 170 | 11 | 架构缺陷 + 跨文件一致性 |
| R2 | 25 | 1 | R1 修复残留 |
| R3 | 53 | 11 | **底层计算函数全错**（ema/rsi/adx/macd） |
| R4 | 43 | 9 | 深层残留 + **R3 新引入 2 个** |
| R5 | 52 | 7 | 分散残留 + **R4 新引入 1 个** |

### 修复过程中自创 Bug 的常见模式

| 模式 | 示例 | 轮次 |
|------|------|:--:|
| **参数变更调用处未同步** | 删 `session_vp` 参数 → `calc_sl_tp` 5→6 参数不匹配 | R3→R4 |
| **新增代码用未定义变量** | `save_candles` 告警用 `tf` → 参数名是 `timeframe` → NameError | R4→R5 |
| **多修复覆盖同一逻辑时漏修一处** | `float('?')` 保护：修了 2 处漏了第 3 处 `_pos_quick` | R4→R5 |
| **数据流修复不彻底** | `near_support` 修了 `_format_coin_section` 但 wrapper 不传播 | R4→R5 |

### 跨文件一致性检查清单

每次修复后必须逐项比对：

| 检查项 | 涉及文件 | 比对方法 |
|--------|---------|---------|
| 仓位判定条件 | `_format_coin_section` / wrapper / `_pos_quick` / `extract_direction` | 逐条件对照 |
| SL/TP 算法 | stdout / analyses.json / social_analyses.json / 社交文案 | 同币种同时间比对 |
| V 反保护逻辑 | near_bottom + 8 根 4H 反弹检测 | 所有判定位置均有 |
| 字段写入/读取 | 写了哪些字段 → 谁读了 → 键名是否一致 | grep 跨文件验证 |
| coin 格式 | `BTC` vs `BTCUSDT` | 统一为 `BTC` |

### 语法验证命令

每次修改完成后对全部核心脚本运行：
```bash
for f in _shared.py analysis_template.py _social_publish.py publish_social.py \
         verify_social_post.py process_reviews.py monitor_and_sync.py \
         jin10_fallback.py regime_detector.py inject_lessons.py; do
    python3 -m py_compile "$f" && echo "✅ $f" || echo "❌ $f"
done
```

### 常见 Bug 分类速查

| 类别 | 检测方法 |
|------|---------|
| 数据顺序反转 | 检查函数签名注释 vs 调用方 SQL `ORDER BY` |
| falsy 值陷阱 | 搜 `if val` 确认布尔短路意图 |
| 字段名漂移 | Cross-file grep 验证 JSON 键名 |
| 时区混淆 | 搜 `fromisoformat` + `timedelta` + `replace(tzinfo=None)` |
| 崩溃防护缺失 | 搜 `fetchone()[` / `next()` / `[0]` / `[-1]` 确认都有守卫 |
| `except Exception: pass` | grep 后逐个评估是否需要日志 |
