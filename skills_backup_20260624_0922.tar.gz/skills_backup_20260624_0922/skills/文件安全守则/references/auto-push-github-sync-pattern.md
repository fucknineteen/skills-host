# auto_push_github.sh 同步映射模式

> 最后更新：2026-06-21（中文目录重命名 + 白名单模式）

## 白名单模式（2026-06-21 新增）

脚本在 `git pull` 后立即执行 `git ls-files` 构建白名单。`safe_copy()` 函数检查目标路径是否在白名单中——**只有远程仓库已有的文件才会被更新，新文件不自动上传**。

```bash
WHITELIST=$(mktemp)
git ls-files > "$WHITELIST"

safe_copy() {
    local src="$1"
    local dest="$2"
    local rel="${dest#$MIRROR/}"
    if grep -qFx "$rel" "$WHITELIST"; then
        cp "$src" "$dest"
    fi
}
```

**效果**：
- 已跟踪文件的修改 → 自动推送
- 新文件（不在远程仓库中）→ 不复制、不提交、不推送
- `git add -A` 保持不变，但因没有新文件被复制，不会引入新条目

---

## 中文目录结构（2026-06-21 重命名）

所有顶层目录已从英文改为中文：

| 旧名 | 新名 |
|------|------|
| `analysis/` | `分析/` |
| `social/` | `社交/` |
| `cron/` | `定时任务/` |
| `devops/` | `运维/` |
| `trading-tutorials/` | `交易教程/` |

脚本内所有目标路径已同步更新。

---

## 同步映射清单（2026-06-21 最新）

### 定时任务脚本 → `定时任务/`
| 本地路径 | 仓库路径 |
|----------|----------|
| `~/.hermes/scripts/sync_klines_cron.sh` | `定时任务/sync_klines_cron.sh` |
| `~/.hermes/scripts/cron_review_process.sh` | `定时任务/cron_review_process.sh` |
| `~/.hermes/scripts/regime_update.sh` | `定时任务/regime_update.sh` |
| `~/.hermes/scripts/guard_jin10_token.sh` | `定时任务/guard_jin10_token.sh` |
| `~/.hermes/scripts/refresh_jin10_cache.sh` | `定时任务/refresh_jin10_cache.sh` |

### 加密货币纯分析 → `分析/加密货币纯分析/scripts/`
| 本地路径 | 仓库路径 |
|----------|----------|
| `trade_review/monitor_and_sync.py` | `分析/加密货币纯分析/scripts/monitor_and_sync.py` |
| `trade_review/process_reviews.py` | `分析/加密货币纯分析/scripts/process_reviews.py` |
| `trade_review/analysis_template.py` | `分析/加密货币纯分析/scripts/analysis_template.py` |
| `trade_review/regime_detector.py` | `分析/加密货币纯分析/scripts/regime_detector.py` |
| `trade_review/_shared.py` | `分析/加密货币纯分析/scripts/_shared.py` |
| `trade_review/jin10_fallback.py` | `分析/加密货币纯分析/scripts/jin10_fallback.py` |
| `trade_review/massive_client.py` | `分析/加密货币纯分析/scripts/massive_client.py` |

### 社交动态发布 → `社交/社交动态发布/scripts/`
| 本地路径 | 仓库路径 |
|----------|----------|
| `trade_review/publish_social.py` | `社交/社交动态发布/scripts/publish_social.py` |
| `trade_review/verify_social_post.py` | `社交/社交动态发布/scripts/verify_social_post.py` |
| `trade_review/_social_publish.py` | `社交/社交动态发布/scripts/_social_publish.py` |
| `trade_review/scripts/gen_charts.py` | `社交/社交动态发布/scripts/gen_charts.py` |
| `trade_review/scripts/save_social_post.py` | `社交/社交动态发布/scripts/save_social_post.py` |
| `trade_review/scripts/review_last_post.py` | `社交/社交动态发布/scripts/review_last_post.py` |

### 山寨币分析 → `分析/山寨币庄控分析/scripts/`
| 本地路径 | 仓库路径 |
|----------|----------|
| `trade_review/scripts/analysis_altcoin.py` | `分析/山寨币庄控分析/scripts/analysis_altcoin.py` |
| `trade_review/scripts/review_altcoin.py` | `分析/山寨币庄控分析/scripts/review_altcoin.py` |
| `trade_review/scripts/scan_daytrade_coins.py` | `分析/山寨币庄控分析/scripts/scan_daytrade_coins.py` |

### 辅助脚本
| 本地路径 | 仓库路径 |
|----------|----------|
| `trade_review/inject_lessons.py` | `分析/加密货币纯分析/scripts/inject_lessons.py` |
| `trade_review/price_path_report.py` | `社交/社交动态发布/scripts/price_path_report.py` |
| `trade_review/scripts/verify_workflow.py` | `社交/社交动态发布/scripts/verify_workflow.py` |

### 明确排除
| 文件 | 原因 |
|------|------|
| `place_live_orders.py` | 含 API 密钥 |
| `check_db_integrity.py` | 已删除（断链，源文件不存在，2026-06-21 清理） |

---

## 审计方法

```bash
# 列出仓库跟踪文件
cd /root/.hermes/skills-host-mirror && git ls-files

# 对照本地脚本检查
diff <(git ls-files -- '定时任务/' '分析/' '社交/') <(echo "期望列表")
```

---

## 已修复：check_db_integrity.py 符号链接断裂（2026-06-21）

该文件是符号链接指向已删除目录，`sync_klines_cron.sh` 每小时静默失败。
修复：删除死链 + 从 `sync_klines_cron.sh` 和 `auto_push_github.sh` 中清除引用。
教训：清理旧 skill 目录时同步检查所有 cron 脚本和符号链接。\n\n## Git 远程回退工作流

当需要回退远程仓库到历史版本（但保留本地文件不变）时：

```bash
# 1. 先恢复本地到最新（因为 reset 会影响工作区）
cd /root/.hermes/skills-host-mirror
git reflog                          # 找最新提交的 hash
git reset --hard <latest_hash>      # 恢复到最新（保留本地文件）

# 2. 基于目标提交创建临时分支
git checkout -b revert-temp <target_commit>

# 3. 强制推送到远程
git push --force origin revert-temp:master

# 4. 暂停 auto_push cron（防止立刻重新推送覆盖）
hermes cronjob pause <auto_push_job_id>

# 5. 切回 master 并对齐远程
git checkout master
git reset --hard origin/master
git branch -D revert-temp
```

**关键坑**：
- `git reset --hard` 会同时改本地工作区——用户通常只想回退远程，无意改本地文件
- 回退后必须暂停 `auto_push_github.sh` cron，否则 5 分钟内会被重新推送覆盖
- `git reflog` 可以恢复被 reset 掉的本地提交
