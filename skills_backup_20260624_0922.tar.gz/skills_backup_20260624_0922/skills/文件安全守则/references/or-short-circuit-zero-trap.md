# Python `or` 短路吞零陷阱

> 发现于 2026-06-23 第三轮审计。提取 helper 函数时引入，第三轮发现并修复。

## 陷阱

```python
# ❌ 陷阱：x or y 当 x=0 时回退到 y
rsi = analysis.get('rsi_14') or analysis.get('rsi_4h', 50)
# rsi_14=0 → 0 or 50 → 返回 50！
# 实际应该返回 0（RSI=0 是极端超卖，合法值）
```

**Python 的真值判断**: `0`、`0.0`、`False`、`None`、`''`、`[]`、`{}` 均为 falsy，`or` 会短路跳过。

在交易/金融领域，以下值可以是 0 但**语义合法**：

| 字段 | 0 的含义 | 误判后果 |
|------|---------|---------|
| RSI | 极端超卖 | 用默认值 50 替代 → 超卖保护完全失效 |
| FG (恐惧贪婪) | 极度恐惧 | 当作"无数据"→ V反保护跳过 |
| MACD_h | 零轴 | 当作"无数据"→ 方向判定错误 |
| funding_rate | 费率中性 | 当作"无数据"→ 订单流分析偏差 |

## 正确模式

```python
# ✅ 方案A：is not None 显式检查（推荐）
rsi = analysis.get('rsi_14')
if rsi is not None:
    return rsi
return analysis.get('rsi_4h', 50)

# ✅ 方案B：三目表达式
rsi = analysis.get('rsi_14')
return rsi if rsi is not None else analysis.get('rsi_4h', 50)
```

## 本会话实例 (2026-06-23 R3)

| 文件 | 函数 | 修复前 | 修复后 |
|------|------|--------|--------|
| `process_reviews.py` | `_extract_rsi` | `analysis.get('rsi_14') or analysis.get('rsi_4h', default)` | 显式 `is not None` 检查 |
| `process_reviews.py` | `_extract_fg` | `analysis.get('fg_val') or analysis.get('macro_external', {}).get('fg_actual')` | 显式 `is not None` 检查 |

## 与 `.get(key, default)` 陷阱的区别

| 陷阱 | 触发条件 | 例子 |
|------|---------|------|
| `.get(key, default)` | key 存在但值为 `None` | `d.get('atr', 0.02)` → None |
| `x or y` | x 为任意 falsy 值（含 0） | `0 or 50` → 50 |

两者叠加时危害最大：先 `.get()` 拿到 None，再 `or` 把 0 也吞掉。

## 审计检查清单

重构成提取函数时，任何 `or` 回退链必须追问：
- [ ] 上游字段是否可能合法为 0？
- [ ] 如果是，`or` 是否会吞掉该 0？
- [ ] 是否可以用 `is not None` 替代 `or`？
- [ ] 是否所有调用点都使用了统一的提取函数？
