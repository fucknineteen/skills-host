# 全量审计→全量修复完整周期 (2026-06-23)

## 审计规模
- 22 Python 脚本 + 9 Cron 作业 + 若干 Shell 包装
- 发现 29 项问题（6致命/12高优/11低优）
- 修复 24 项，确认 3 项已在之前修复，2 项为审计误报

## 审计方法

### 三线并行审计（子代理模式）
使用 `delegate_task` 将 3 个最大的脚本（process_reviews.py 1069行, analysis_template.py 2183行, publish_social.py + _social_publish.py 467+629行）同时派发给子代理审计，父代理审计其余 18 个小型脚本。

**效率**: 3个子代理并行运行约110秒，单代理串行审计需要约7分钟。

### 审计清单（逐文件）
每个脚本检查：
1. 逻辑正确性（数据流、判定逻辑、教训/结论生成）
2. 字段完整性（JSON 写入 vs 消费方期望）
3. 空值/NoneType 处理（.get()陷阱、or短路）
4. 时区处理（BJT 使用一致性）
5. 死代码（未赋值字段、冗余赋值、未使用参数）
6. Cron 依赖（作业指向的文件是否可运行）

### 交叉验证
- 对照已知陷阱列表逐项核查修复状态（不要信文档，要看代码）
- 验证 Cron 实际运行输出（cron/output/ 日志文件）
- 验证实际数据文件（.regime_cache.json, .lesson_context.txt）

## 修复方法

### 优先级排序
```
🔴 致命（数据正确性） → 🟡 高优（健壮性） → 🟢 低优（代码质量）
```

### 最小补丁原则
每个修复仅改动最小必要行数，不顺手优化、不重构。

### 修复后验证链
```
语法验证(py_compile) → Import链验证 → 功能测试 → 端到端验证
```

## 本周期发现的典型Bug模式

### 1. Patch工具的 `\n` 字面量转义
当 new_string 中使用 `\n` 时，patch 写入字面量反斜杠-n 而非换行符。

### 2. 双文件同步缺失
cron 指向 `/root/.hermes/scripts/` 的脚本，修复 `/root/.hermes/trade_review/` 中的同名文件不会生效。

### 3. 审计文档的误判
审计报告标注"已修复"的 Bug（如 C5 爆仓价方向）经实际代码校验确认早已正确。

### 4. 删除变量声明导致 NameError
标记 `macro_alert` 为 DEAD 并删除赋值行，但下游 `if not macro_alert:` 仍存在 → NameError。

### 5. 教训去重的维度不足
ID-based + 元组去重对跨文件同内容教训无效 → 需增加纯文本归一化去重。

## 修复结果统计

| 文件 | 修复项 |
|------|--------|
| inject_lessons.py (×2位置) | sys.path + 三级去重 |
| process_reviews.py | find_analysis 标准化 + str(None) + sentiment 防护 + levels 区分 |
| analysis_template.py | ticker.vol 字段映射 + DEAD 标记 + 冗余删除 |
| publish_social.py | order_flow 写入 + 跨日边界修复 |
| _social_publish.py | 支撑阻力语义 + vp_data 兼容 + SOL 去重 |
| gen_charts.py | fg_val 未定义 |
| regime_update.sh | stderr 日志化 |
| GitHub auto-push | 恢复暂停的 cron 作业 |
