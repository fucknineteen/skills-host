# Deleted Skills Inventory

These skills were previously installed but are no longer present in `~/.hermes/skills/`.

## crypto-trading-analysis
- **Purpose:** Core cryptocurrency analysis framework — 4-dimension analysis (macro/technical/capital/conclusion), Wyckoff phase detection (`wyckoff_detect()`), K-line pattern recognition (`detect_kline_patterns()`), VP/OF (`session_vp()` + `cvd_proxy()`), position sizing guidance (`calc_position()`)
- **Previous path:** `~/.hermes/skills/crypto-trading-analysis/` (primary); duplicate at `~/.hermes/skills/research/crypto-trading-analysis/`
- **Size:** 105KB, ~1290 lines
- **Usage:** 541 uses, 459 patches (most heavily used custom skill, created 2026-05-31, last used 2026-06-18 04:17 UTC)
- **Sub-files:** `scripts/check_db_integrity.py` — referenced by `sync_klines_cron.sh` L22 cron wrapper
- **Referenced in:** Obsidian vault (`交易体系总规范.md`, `工作流审计2026-06-17.md`, `交易体系总览.md`), `.usage.json`
- **Status:** RECOVERED — deleted June 17, 2026. Rebuilt June 18, 2026 from Obsidian audit report + `analysis_template.py` source at `~/.hermes/skills/crypto-trading-analysis/SKILL.md`. Original 105KB/1290 lines; rebuilt 11KB (stripped overlap with `trade-review-workflow`, kept analysis-specific thresholds/formulas/COIN_LESSONS). Three-skill crypto suite now complete: `crypto-trading-analysis` + `trade-review-workflow` + `social-dynamic`.
- **Lesson:** Same as social-dynamic — `research/` subdirectory was vulnerable to bulk cleanup. Skills MUST be at top-level `~/.hermes/skills/<name>/`.

## social-dynamic
- **Purpose:** Social media post publishing workflow (sync→analysis→review→draft→verify→post)
- **Previous path:** `~/.hermes/skills/social-media/social-dynamic/SKILL.md` (nested in subdirectory)
- **Referenced in:** USER.md line 1 ("发动态严格按 social-dynamic skill 流程"), MEMORY.md line 13
- **Status:** RECOVERED — deleted June 17, 2026. Rebuilt initially, then fully rewritten June 18, 2026 at `~/.hermes/skills/social-dynamic/SKILL.md` with: publish_social.py as recommended entry, 7-step breakdown with tolerances table, data verification source table, 10 hard constraints, 4 pitfalls, and correct review_last_post.py path behavior.
- **Lesson:** Custom skills must be at `~/.hermes/skills/<name>/` top level, NOT nested. Also: skills governing a live pipeline should document both the recommended path and deprecated alternatives with explicit bug annotations.

## xuanxue-divination (v2.1.0)
- **Purpose:** Metaphysical/divination analysis via SkillOpt
- **Referenced in:** MEMORY.md line 23 ("xuanxue-divination optimized to v2.1.0 using it (2026-06-18)")
- **Status:** DELETED — not in hub, not recoverable. Was a custom/local skill.
- **Note:** Installed via SkillOpt (skillopt) which treats SKILL.md as trainable external state.

## How to detect deleted skills

1. Run `hermes skills list` — shows currently installed
2. Compare against memory references — if a skill is mentioned in MEMORY.md or USER.md but not in the list, it's likely deleted
3. Check `.hub/audit.log` for INSTALL/DELETE records
4. Check `trade-review-workflow/SKILL.md` — it references all core scripts
