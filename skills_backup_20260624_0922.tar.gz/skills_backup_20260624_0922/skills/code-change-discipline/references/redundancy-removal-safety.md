# 冗余清除安全性三级分类
> 来源：2026-06-23 第二轮审计

## 🟢 零风险(立即可删)
- 死导入(unused import) — grep确认无引用
- 孤儿文件 — 不在git白名单的旧版本
- 未使用参数 — 函数签名中从未引用的参数
- 重复注释/变量 — 复制粘贴遗留

## 🟡 需验证后清除
- 内联重复代码 — 提取为共享函数后replace_all验证
- 魔数重复 — 提取为常量
- ⚠️ replace_all陷阱: 变量名差异(ev_str vs events_str)导致只替换部分

## 🔴 不可清除(有意设计)
- 接口差异: _shared.calc_rsi(列表) vs analysis_template.calc_rsi(标量)
- 算法差异: gen_charts RSI(numpy) vs 其他实现
- 目录差异: inject_lessons双份(sys.path hack)