# 跨工作流全量审计方法论 (2026-06-23)

> 来源：社交动态发布 + 加密货币纯分析 双工作流 16 Bug 审计修复实战

## 审计步骤（可复用）

### 1. 并行加载所有 Skill 文档
同时 `skill_view` 所有相关 workflow skill，识别：
- 字段映射表差异（如 `close` vs `last_close`）
- 步骤合同与实际代码的差异（如"超时→停止"但代码是"继续"）
- 模板边界冲突（如 `v5.0` vs `v5.1`）

### 2. 并行读取所有核心脚本
一次性读取全部脚本（本次6个主脚本 + 3个辅助脚本），避免串行等待。
读取时注意 `truncated` 标记，超过500行的文件用 `offset` 分段读取。

### 3. 交叉对比三组关系
| 对比组 | 检查项 |
|--------|--------|
| Skill文档 ↔ 代码 | 合同要求是否被代码强制执行？字段名是否一致？ |
| 写入方 ↔ 读取方 | 写入的字段键名 = 读取的字段键名？如 `session_vp(coin, conn)` 中 coin 格式 |
| 同一判定多处实现 | wrapper position / extract_direction / btc_dir_label 三者逻辑是否等价？ |

### 4. 按严重度分级报告
🔴 致命 → 🟠 高 → 🟡 中 → 🟢 代码质量

### 5. 批量修复 + 全量验证
- 每次并行 patch 3-4 处独立修复
- 全部完成后 `py_compile` 验证所有修改文件
- `import` 链测试：确认跨文件导入仍正常
- 新函数边界测试（如 `parse_iso_timestamp` 的空串/None/T分隔/空格分隔）

## 高频 Bug 模式速查

### 模式 A：合同无代码强制执行
SKILL.md 写"若失败→立即停止"，但代码是 `except: return ''` 继续执行。
**检查**: 搜索 SKILL.md 中所有"停止"/"终止"关键词 → grep 对应代码的异常处理。

### 模式 B：数据被后续代码覆盖
L350 从 JSON 读取值 → L395 用 `calc_xxx()` 重算并覆盖 → JSON 值浪费且可能不一致。
**检查**: 搜索同一变量被赋值两次的位置，确认第二次是否条件覆盖还是无条件覆盖。

### 模式 C：多站判定逻辑不等价
同一方向判定在 3 处实现（wrapper/extract_direction/draft），参数来源不同。
**检查**: 逐行比对三处判定的条件表达式。

### 模式 D：字段名链不一致
函数参数传 `'BTCUSDT'` → DB 查询期望 `'BTC'` → SQL 查不到数据。
**检查**: 追踪每个函数参数的来源格式，对比接收方的期望格式。

### 模式 E：时间戳解析假设单一格式
`fromisoformat()` 只支持 `T` 分隔符（Python < 3.11），空格分隔会抛异常。
**修复**: 创建 `parse_iso_timestamp()` 兼容多格式。

### 模式 F：异常回退值导致排序错乱
`except: fg_candidates.append((datetime.min, record))` → datetime.min 在排序中位置不可预测。
**修复**: 解析失败 → `continue` 跳过。

## 验证模板

```python
# 1. 语法验证
python3 -m py_compile file1.py file2.py ...

# 2. 导入链验证
python3 -c "
import sys; sys.path.insert(0, '...')
from module import symbol1, symbol2
print('OK')
"

# 3. 新函数边界测试
```
