# 修复引入的回归模式

> 来源：11 轮全量审计，累计修复 ~400 个 Bug 的实战数据
> 适用：每次修复后自查是否引入以下回归

---

## 模式一：新增代码引入未导入的模块

**典型场景**：修复时调用标准库函数，但忘了加 `import`。

**实例**：
```python
# R8 修复：rstrip('0') 用 re.sub 替代
p_str = re.sub(r'0+$', '', price) if '.' in price else price  # ← re 未 import → NameError
```
**根因**：模块顶部 `import os, sqlite3, json, subprocess, sys, math, time` 不含 `re`。
**预防**：任何新增模块调用，必须确认 import 存在。`py_compile` 可以捕获此问题，但有 8 小时延迟（中间 4 轮审计未触发该代码路径）。

---

## 模式二：修复只覆盖了部分实例

**典型场景**：同一 Bug 模式在多处出现，修复了主位置但漏了其他位置。

**实例（FG=0 truthiness）**：
```python
# R1 修复：publish_social.py  → if _fg_val is not None ✓
# R8 修复：analysis_template.py → if fg_val is not None ✓
# R9 发现：_social_publish.py   → if fg_val and fg_val < 25 ✗（漏修）
```
**根因**：修复后未全局 grep 相同模式。
**预防**：修复一个 truthiness 问题后，全项目搜索 `if fg_val:` / `if val and` / `if result and` 模式。

---

## 模式三：参数删除后调用方未同步

**典型场景**：删除函数参数后，调用方仍传入多余参数。

**实例（calc_sl_tp session_vp 删除）**：
```python
# R3 修复：def calc_sl_tp(entry, near_s, near_r, atr, pos_label):  # 5 参数
# R4 发现：calc_sl_tp(entry, lows, highs, atr_4h_val, pos_dir, svp)  # 仍传 6 个 → TypeError
```
**根因**：修改签名后只改了函数定义，未 grep 调用方。
**预防**：任何签名变更，必须搜索函数名然后逐调用点核对参数数量。

---

## 模式四：数据索引方向混淆

**典型场景**：`candles_1h[-1]` 取"最新"还是"最旧"取决于数据排序方向。修复时容易搞反。

**实例（SOS 检测）**：
```python
# candles_1h 是 ASC 顺序（[0]=最旧，[-1]=最新）
# R7 修复：candles_1h[-1] → candles_1h[0]  # 以为在修，实际引入新错
# R8 修复：candles_1h[0]  → candles_1h[-1] # 正确
```
**根因**：修复前未阅读 `get_klines()` 中的 `ORDER BY` 子句。
**预防**：任何索引变更，必须先确认数据排序方向（ASC → `[0]`=最旧, DESC → `[0]`=最新）。

---

## 模式五：模块级常量随时间过期

**典型场景**：`NOW_MS = int(time.time()*1000)` 在模块加载时计算一次，后续不再更新。

**实例**：
```python
# 模块顶部：
NOW_BJ = datetime.now(BJT)  # import 时固定

# 8 小时后调用：
hours = (NOW_BJ - event_time).total_seconds() / 3600  # 一直用 8 小时前的"现在"
```
**根因**：`NOW_*` 作为模块级常量，import 后不再变化。
**预防**：任何需要"当前时间"的场景，用 `_now_bj()` / `_now_ms()` 函数而非模块级变量。

---

## 模式六：Python 字符串方法的意外副作用

**典型场景**：`str.rstrip('0')` 不是"去掉小数尾零"，而是"去掉所有结尾的 0 字符"。

**实例**：
```python
price = '10000'
price.rstrip('0')  # → '1'（灾难！）
```
**根因**：`rstrip` 是字符级剥离，不是语义级。
**预防**：处理价格/数字字符串时用 `re.sub(r'\.?0+$', '', s)` 而非 `rstrip`。

---

## 模式七：`dict.get(key, default)` 不保护 key 存在但值为 None

**实例**：
```python
d = {'fg_label': None}
d.get('fg_label', '')  # → None（key 存在，default 不生效！）
d.get('fg_label', '').upper()  # → AttributeError
```
**预防**：`.get()` 后如果要对值做方法调用，加 `or ''`：`(d.get('fg_label') or '').upper()`。

---

## 检查清单

每次修复后自查：
- [ ] 新增函数/库调用 → `import` 是否存在？
- [ ] 修改了签名 → 所有调用点参数数是否匹配？
- [ ] 修改了索引 → 数据排序方向是否正确？
- [ ] 修改了 truthiness 判断 → 同模式其他位置是否也需修复？
- [ ] 用了 `.get(key, default)` → 后面是否有 `.upper()`/`.strip()` 等方法调用？
- [ ] `py_compile` 通过了吗？
