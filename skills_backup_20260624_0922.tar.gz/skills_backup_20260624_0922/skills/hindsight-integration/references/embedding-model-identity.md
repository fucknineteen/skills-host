# Embedding Model Identity: shibing624/text2vec-base-chinese vs hfl/chinese-macbert-base

**Date**: 2026-06-19

`shibing624/text2vec-base-chinese` is a renamed/finetuned variant of `hfl/chinese-macbert-base`. Both share:

| Field | shibing624 | hfl/macbert | Match |
|-------|-----------|-------------|-------|
| model_type | bert | bert | ✓ |
| hidden_size | 768 | 768 | ✓ |
| num_hidden_layers | 12 | 12 | ✓ |
| num_attention_heads | 12 | 12 | ✓ |
| max_position_embeddings | 512 | 512 | ✓ |
| vocab_size | 21128 | 21128 | ✓ |
| _name_or_path | hfl/chinese-macbert-base | N/A | (shibing624 wraps macbert) |

**Conclusion**: They are the same model. The `shibing624` repo is just a wrapper that sets `_name_or_path` to `hfl/chinese-macbert-base`. Hindsight config with either name will load the same weights.
