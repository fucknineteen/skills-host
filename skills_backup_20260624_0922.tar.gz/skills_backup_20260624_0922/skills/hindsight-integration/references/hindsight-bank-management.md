# Hindsight Bank Management

## Delete vs Clear

- **Clear all memories**: `curl -X DELETE http://localhost:8888/v1/default/banks/{bank_id}/memories` — empties the bank but keeps it
- **Delete bank entirely**: `curl -X DELETE http://localhost:8888/v1/default/banks/{bank_id}` — removes bank and all data

## Listing Banks

```bash
curl -sf http://localhost:8888/v1/default/banks
```

Returns: bank_id, name, disposition, mission, fact_count, last_document_at

## Creating a Bank

```bash
curl -sf -X POST http://localhost:8888/v1/default/banks \
  -H 'Content-Type: application/json' \
  -d '{"bank_id":"hermes","name":"hermes","mission":"Hermes Agent 对话记忆库"}'
```

## Writing to a Specific Bank

```bash
curl -sf -X POST http://localhost:8888/v1/default/banks/{bank_id}/memories \
  -H 'Content-Type: application/json' \
  -d '{"items":[{"content":"text","tags":["tag1"]}]} '
```

## Verification

```bash
curl -sf http://localhost:8888/v1/default/banks/{bank_id}/memories/list
```
