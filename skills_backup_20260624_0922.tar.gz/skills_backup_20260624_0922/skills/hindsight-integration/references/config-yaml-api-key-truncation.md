# config.yaml API Key Truncation Pattern

## Problem
When programmatically writing API keys into `~/.hermes/config.yaml`, keys can get truncated if the regex/string substitution doesn't capture the full value.

## Symptoms
- `hermes chat` with `provider=custom` returns `APIConnectionError: Connection error`
- API key length in config.yaml < expected length (e.g., 48 vs 51 chars)
- Gateway works fine (uses different config path) but CLI chat fails

## Root Causes
1. **Regex capture incomplete**: `re.sub(r'(api_key:\s*)sk-[^\s]+', ...)` may truncate if the key contains whitespace-like chars
2. **Variable interpolation loss**: Using string formatting that drops characters
3. **YAML serialization**: Long keys may be truncated during YAML write

## Fix Procedure
1. Get full key from original source (Docker env, backup file, apihub portal)
2. Verify key length: `echo -n "key" | wc -c` (should be 51 for Agnes keys)
3. Use Python for reliable write (NOT sed):
   ```python
   p = '/root/.hermes/config.yaml'
   with open(p, 'r') as f: content = f.read()
   content = content.replace('OLD_KEY', 'NEW_FULL_KEY')
   with open(p, 'w') as f: f.write(content)
   ```
4. Verify after write: `grep api_key config.yaml | head -1 | cut -d: -f2 | tr -d ' ' | wc -c`

## Prevention
- Always compare key length before and after write
- Prefer `sed` or Python `replace()` over regex for exact key substitution
- Keep backup: `cp config.yaml config.yaml.bak.$(date +%Y%m%d_%H%M%S)`
