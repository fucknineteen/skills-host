# Hindsight Docker 部署手册

## 前置条件

- Docker 已安装
- Hindsight 镜像（`docker pull` 或离线 `docker load -i hindsight.tar`）

## 启动命令

### Linux/Mac
```bash
docker run -d --name hindsight \
  -p 8888:8888 -p 9999:9999 \
  -e HINDSIGHT_API_LLM_PROVIDER=deepseek \
  -e HINDSIGHT_API_LLM_API_KEY=*** \
  -e HINDSIGHT_API_LLM_MODEL=deepseek-v4-flash \
  -e HF_ENDPOINT=https://hf-mirror.com \
  -e HINDSIGHT_API_EMBEDDINGS_LOCAL_MODEL=shibing624/text2vec-base-chinese \
  -v $HOME/.hindsight-docker:/home/hindsight/.pg0 \
  ghcr.io/vectorize-io/hindsight:latest
```

### Windows PowerShell
```powershell
docker run -d --name hindsight `
  -p 8888:8888 -p 9999:9999 `
  -e HINDSIGHT_API_LLM_PROVIDER=deepseek `
  -e HINDSIGHT_API_LLM_API_KEY=*** `
  -e HINDSIGHT_API_LLM_MODEL=deepseek-v4-flash `
  -e HF_ENDPOINT=https://hf-mirror.com `
  -e HINDSIGHT_API_EMBEDDINGS_LOCAL_MODEL=shibing624/text2vec-base-chinese `
  -v "$HOME\.hindsight-docker:/home/hindsight/.pg0" `
  ghcr.io/vectorize-io/hindsight:latest
```

## 日常管理

```bash
docker stop hindsight      # 停止
docker start hindsight      # 启动
docker logs [-f] hindsight  # 查看日志
docker rm -f hindsight      # 删除（数据不丢）
```

## 端口说明

| 端口 | 用途 |
|------|------|
| 8888 | API（Hermes 通过此端口通信） |
| 9999 | Web UI（Control Plane，记忆管理界面） |

## 验证

```bash
curl http://localhost:8888/health
# Browser: http://localhost:9999
```

## 数据持久化

数据存储在 `-v` 挂载的本地目录：`$HOME/.hindsight-docker`
包含嵌入式 PostgreSQL 的数据文件。容器删除重建后数据仍在。

## 环境变量说明

| 变量 | 必填 | 说明 |
|------|------|------|
| HINDSIGHT_API_LLM_PROVIDER | 是 | LLM 提供商 |
| HINDSIGHT_API_LLM_API_KEY | 是 | LLM API 密钥 |
| HINDSIGHT_API_LLM_MODEL | 是 | 模型名称 |
| HINDSIGHT_API_EMBEDDINGS_LOCAL_MODEL | 否 | 本地 Embedding 模型（默认 BAAI/bge-small-en-v1.5） |
| HF_ENDPOINT | 否 | HuggingFace 镜像源，国内用户填 `https://hf-mirror.com` |

> LLM 相关变量是给 Hindsight 内部做实体提取用的，不是 Hermes 的对话模型。

## 支持的 LLM Provider

| Provider | HINDSIGHT_API_LLM_PROVIDER | 推荐模型 | 说明 |
|----------|---------------------------|----------|------|
| DeepSeek | deepseek | deepseek-v4-flash | 国内直连，价格低 |
| MiniMax | minimax | 按需选择 | 国内原生支持 |
| OpenAI | openai | gpt-4o-mini | 需能访问 OpenAI API |
| Groq | groq | gpt-oss-20b | 免费额度，速度快 |
| OpenRouter | openrouter | 按需选择 | 聚合多家模型 |
| Anthropic | anthropic | claude-haiku | 价格较高 |
| Google Gemini | gemini | gemini-2.0-flash | 需 Google API Key |
| Ollama | ollama | 本地模型 | 纯本地，需显卡 |
| LM Studio | lmstudio | 本地模型 | GUI 方式管理本地模型 |

### 通过 OpenAI 兼容模式接入

配置方式（以通义千问为例）：
```bash
-e HINDSIGHT_API_LLM_PROVIDER=openai \
-e HINDSIGHT_API_LLM_API_KEY=*** \
-e HINDSIGHT_API_LLM_MODEL=qwen-turbo \
-e HINDSIGHT_API_LLM_BASE_URL=https://dashscope.aliyuncs.com/compatible-mode/v1
```

要求：模型必须支持结构化输出（structured output / function calling）。

## 用 Agnes API 作为 Hindsight LLM

```bash
-e HINDSIGHT_API_LLM_PROVIDER=openai \
-e HINDSIGHT_API_LLM_MODEL=agnes-2.0-flash \
-e HINDSIGHT_API_BASE_URL=https://apihub.agnes-ai.com/v1 \
-e HINDSIGHT_API_LLM_API_KEY=***
```

> ⚠️ Agnes API 不支持 embedding 模型，Hindsight 必须用 `HINDSIGHT_API_EMBEDDINGS_PROVIDER=local`。
> ⚠️ Agnes key 在 config.yaml 中可能被截断，需从网关运行时或 apihub.agnes-ai.com 获取完整 key。