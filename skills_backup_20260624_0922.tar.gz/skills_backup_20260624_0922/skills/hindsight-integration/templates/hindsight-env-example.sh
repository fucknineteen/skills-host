#!/bin/bash
# Hindsight Docker start script with --env-file (avoids API key truncation)
# Usage: ./hindsight-start.sh
# Prerequisites:
#   1. Edit /root/.hindsight.env and fill in the FULL API key
#   2. Data directory: /root/.hindsight-docker (bind-mounted, persists across recreates)

set -e

ENV_FILE="/root/.hindsight.env"
DATA_DIR="/root/.hindsight-docker"
IMAGE="ghcr.io/vectorize-io/hindsight:latest"

# Validate env file exists
if [ ! -f "$ENV_FILE" ]; then
    echo "❌ Env file not found: $ENV_FILE"
    echo "   Create it with:"
    echo "   cat > $ENV_FILE << 'EOF'"
    echo "   HINDSIGHT_API_LLM_API_KEY=your-full-key-here"
    echo "   HINDSIGHT_API_LLM_PROVIDER=openai"
    echo "   HINDSIGHT_API_LLM_MODEL=agnes-2.0-flash"
    echo "   HINDSIGHT_API_BASE_URL=https://apihub.agnes-ai.com/v1"
    echo "   HINDSIGHT_API_EMBEDDINGS_PROVIDER=local"
    echo "   HINDSIGHT_API_DATABASE_URL=pg0"
    echo "   HINDSIGHT_API_RERANKER_PROVIDER=rrf"
    echo "   HINDSIGHT_API_EMBEDDINGS_LOCAL_MODEL=/home/hindsight/.cache/sentence-transformers/text2vec"
    echo "   EOF"
    echo "   chmod 600 $ENV_FILE"
    exit 1
fi

# Stop and remove existing container (data is preserved in bind mount)
echo "🔄 Stopping existing container..."
docker stop hindsight 2>/dev/null || true
docker rm hindsight 2>/dev/null || true

# Start new container with --env-file
echo "🚀 Starting Hindsight with --env-file..."
docker run -d \
  --name hindsight \
  --env-file "$ENV_FILE" \
  -p 8888:8888 \
  -p 9999:9999 \
  -v "$DATA_DIR:/home/hindsight/.pg0" \
  -v "$DATA_DIR/hf-cache/text2vec:/home/hindsight/.cache/sentence-transformers/text2vec" \
  "$IMAGE"

echo "⏳ Waiting for API to be healthy..."
sleep 15

# Verify health
if curl -sf http://localhost:8888/health > /dev/null; then
    echo "✅ Hindsight is running!"
    echo "   API:     http://localhost:8888"
    echo "   Control: http://localhost:9999"
    
    # Verify API key length inside container
    KEY_LEN=$(docker exec hindsight printenv HINDSIGHT_API_LLM_API_KEY | wc -c)
    if [ "$KEY_LEN" -ge 50 ]; then
        echo "   API key length: ${KEY_LEN} chars ✅"
    else
        echo "   ⚠️  API key length: ${KEY_LEN} chars — may be truncated!"
        echo "   Fix: Check $ENV_FILE has the FULL key, then restart container."
    fi
else
    echo "❌ Health check failed. Check logs:"
    echo "   docker logs hindsight"
    exit 1
fi
