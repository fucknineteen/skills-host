# audit_draft.py 使用手册

> 版本：v2 深修版（2026-06-22）
> 位置：`trade_review/scripts/audit_draft.py` & 技能内 `scripts/audit_draft.py`（同步副本）

## 功能

核验器（`verify_social_post.py`）只覆盖 11 个结构化字段（价格/SR/FG/RR）。叙述段落中的 K线收盘价、MACD 值、RSI、VP、DXY、VIX 等裸数字处于核验盲区。

`audit_draft.py` 提取文案中所有数字 → 在 JSON 数据源（`social_analyses.json` + `regime_cache.json`）中查来源 → 分组报告匹配状态。

## 用法

```bash
cd /root/.hermes/trade_review

# 社交动态文案审计（默认）
python3 scripts/audit_draft.py --social /tmp/social_draft.txt

# 纯分析结论审计
python3 scripts/audit_draft.py --pure /tmp/analysis.txt

# 自动检测数据源
python3 scripts/audit_draft.py /tmp/draft.txt
```

## 输出分组

| 分组 | 含义 | 示例 |
|------|------|------|
| ✅ 精确匹配 | 数字在 JSON 中精确命中 | `63,936 → session_vp.val (63936.0)` |
| ✅ 语义匹配 | 上下文关键词（DXY/收在/POC）引导到正确字段 | `100.85 → dimensions.macro_external.dxy` |
| 🧮 推导百分比 | 从 K线 open/close 计算涨跌幅，±1pp 容差 | `-1.2% → 4H.last_close vs 4H.last_o (-1.4)` |
| ⚠️ 近似匹配 | 无上下文偏好的全局近似匹配，偏差 <3%（价格）或 <1.5（指标） | `42 → indicators.4H.rsi (41.64)` |
| ❌ 未找到 | 在任何 JSON 字段中都不存在 | `63188 ← 无来源`（真实收盘价 64192） |

## 语义上下文映射

脚本内置 20+ 条上下文关键词→JSON 字段路径映射。当数字附近的文本匹配关键词时，优先在对应字段中查找：

| 文案关键词 | 匹配字段 |
|-----------|---------|
| DXY | `dimensions.macro_external.dxy` |
| VIX | `dimensions.macro_external.vix` |
| 10Y | `dimensions.macro_external.yield10` |
| BTC.D | `dimensions.macro_external.btc_dominance` |
| FG | `fg_val` |
| POC | `session_vp.poc` |
| VAH | `session_vp.vah` |
| VAL | `session_vp.val` |
| 收在 / 收盘 | `indicators.1D.last_close` |
| MACD 1D | `indicators.1D.macd_h` |
| MACD 4H | `indicators.4H.macd_h` |
| MACD 1H | `indicators.1H.macd_h` |
| RSI 4H | `indicators.4H.rsi` |
| ADX 4H | `indicators.4H.adx` |
| 费率 | `funding_rate_pct` |
| 支撑 | `levels_4h.lows[0]` |
| 阻力 | `levels_4h.highs[0]` |

## 语义 Override 机制

当上下文有关键词提示时，**只在语义字段内搜索**。即使全局碰巧有更近的数字（如 BB 下轨 63185.5 巧合匹配 63188），也不会抢走语义字段的匹配权。这杜绝了 `63188 → 5m BB 下轨` 的假匹配。

## 最近匹配优先

当上下文中存在多个时间框架（如 "1D十字星" 和 "4H大阴线" 同时出现），脚本选择离数字最近的时间框架而非第一个匹配：
- `"1D十字星收在63188，4H大阴线-1.2%"` → `-1.2%` 推导用 4H（距离 8 字符）而非 1D（距离 21 字符）
- `"POC $64,202 | VAH $64,442 | VAL $63,936"` → `64,442` 匹配 VAH（距离 6）而非 POC（距离 8）

## 已知局限

1. **涨跌幅推导需上下文同时含「币名+时间框架+阴/阳/涨跌」**。纯 "RSI=42" 不会触发推导
2. **百分比符号 `%` 需要在数字后紧跟**。`-0.0027%` 会被提取，`-0.0027`（无%）不会
3. **费率百分比**（如 `-0.0027%`）不会被推导逻辑处理——它会在语义匹配中查找 `funding_rate_pct` 字段
4. **无千分位逗号的 4-6 位数字**（如 63188）单独由 Pattern 1b 提取——如果数字是 3 位或不含逗号的 7 位以上，可能漏掉
