# `_social_publish.py` 逻辑审计 — 未修复 Bug 清单

> 审计日期：2026-06-22（与五轮审计同日）
> 审计范围：`_social_publish.py` 全文件（494行），重点关注 wrapper position / extract_direction / generate_social_draft / flash_news / calc_sl_tp / social_analyses.json 字段
> 状态：共 16 个 bug，均未修复

---

## Bug 1: Wrapper 仓位逻辑与 `_format_coin_section` 不一致（3 处）

五轮审计 #4 和 #6 声称已修复 wrapper 的 near_bottom→偏多 和 rsi+MACD 做空路径，但当前代码中仍然缺失。

### Bug 1a — 缺失 `near_bottom` → 偏多 独立分支
- **代码位置**：`analyze_single_coin()` L160
- **现状**：仅 `'强'→偏多 | '弱'→偏空 | 其他→观望(等确认)+L1捷径`
- **_format_coin_section (L1297-1298)**：有 `elif a.get('near_bottom'): pos_dir = '试多'`，当共振为 🟡分歧 但 near_bottom=True 时仍给出试多
- **影响**：near_bottom=True + resonance=🟡分歧 → wrapper 输出 `观望（等确认）` 而非 `偏多`

### Bug 1b — 缺失 `(rsi_1d>65 and macd_h_4h<-50)` → 偏空 条件
- **代码位置**：Wrapper L160
- **_format_coin_section (L1293)**：`'弱' in resonance or (rsi_1d > 65 and macd_4h_val < -50)` → 试空
- **影响**：当 rsi_1d>65 + macd_h_4h<-50 但 resonance=🟡分歧 时，wrapper 不输出偏空

### Bug 1c — 缺失 `(near_bottom and macd>-50 and rsi_1h<45)` → 偏多 组合条件
- **_format_coin_section (L1291)**：`'强' or (near_bottom and macd_4h>-50 and rsi_1h<45)` → 试多
- **影响**：near_bottom + 温和MACD + 低RSI_1h 的组合做多信号被 wrapper 丢弃

---

## Bug 2: `extract_direction()` 缺陷（2 处）

### Bug 2a — 完全不检查 `near_bottom` 和 V反保护
- **代码位置**：L224-234
- **影响**：resonance='🔴偏弱' + near_bottom=True → 仓位是 `观望（near_bottom保护）`，但 `extract_direction()` 返回 `"做空"`
- **调用链**：在 `step_save()` (publish_social.py L170-171) 保存方向标签时使用 → 存储的标签与仓位矛盾

### Bug 2b — `macd_h < -50` 可覆盖强共振
- **代码位置**：L232 `elif '弱' in str(resonance) or macd_h < -50:`
- **影响**：resonance='🟢偏强' + macd_h=-60 → 返回 `"做空"`，与强共振立场冲突
- **修复方向**：改为仅在共振非强时才以 macd_h 为辅

---

## Bug 3: `generate_social_draft()` 数据提取/叙事错误（4 处）

### Bug 3a — 标题始终显示"极度恐惧"无视 FG 值
- **代码位置**：L312 `elif btc_macd4 > 0: title = f'...极度恐惧中谁在默默吃货'` / L313 `else: title = f'...极度恐惧——散户割肉时庄家在干嘛'`
- **影响**：FG=80（极度贪婪）时标题仍写"极度恐惧"
- **修复方向**：根据 fg_val 动态选择叙事词（极度恐惧/恐惧/中性/贪婪）

### Bug 3b — 💬 尾句与 regime 自相矛盾
- **代码位置**：L466 `if btc_dir_label == '偏空': lines.append(f'💬 {regime}共振偏弱...')` / L469 `else: lines.append(f'💬 {regime}共振偏强...')`
- **影响**：position='偏空' 来自 L1 捷径 (resonance='🟡分歧') → 输出 `"🟡分歧共振偏弱"` — 分歧≠偏弱
- **同理**：position='偏多' 但 resonance='🟡分歧' → 输出 `"🟡分歧共振偏强"`

### Bug 3c — SL/TP 使用的 `levels_4h` 与 `_format_coin_section` 数据源不同
- **代码位置**：`generate_social_draft` L270-273 用 `levels_4h`（20 根 4H K线）
- **_format_coin_section** L1229-1249 用动态计算的 `near_support/near_resistance`（8 根 K线 + ATR 过滤）
- **影响**：同一时刻社交文案的止损/止盈与完整分析输出数值不同

### Bug 3d — ETH 威科夫阶段替换遗漏 `(Phase A->B)` 处理
- **代码位置**：L343 `eth_clean = eth_wy_phase.replace(' (Phase E)', ' E').replace(' (Phase D->E)', ' D→E')`
- **BTC 同类替换 (L325)** 包括 `' (Phase A->B)' → ' A→B'`，ETH 漏了

---

## Bug 4: 快讯（Flash News）过滤缺陷（2 处）

### Bug 4a — 加密关键词列表严重不完整
- **代码位置**：L427-430 `crypto_kw`
- **缺失**：USDT, USDC, SOL, XRP, DOGE, LTC, ADA, BNB, AVAX, MATIC, ARB, OP, SUI, NEAR, DOT, LINK, UNI, AAVE, TRON 等
- **影响**：相关币种的快讯被过滤掉

### Bug 4b — 黑名单无法排除借"美联储/加息/美元"混入的传统财经新闻
- **代码位置**：L432-434 黑名单仅排除商品/钢铁/棕榈类
- **问题**：白名单中 `'加息','降息','美元','通胀'` 会匹配 A股/港股/日经 等传统财经快讯 → 非加密新闻混入
- **修复方向**：增加 `'上证','深证','港股','A股','创业板','科创板','沪深'` 等黑名单词

---

## Bug 5: SL/TP 计算缺陷（2 处）

### Bug 5a — 入场价丢失时 `calc_sl_tp` 返回 (0,0,'?') 导致文案误判为"观望"
- **代码位置**：L457-464 仅当 `btc_dir_label != '观望' and btc_pf and btc_sl_val and btc_tp_val` 才显示 SL/TP
- **触发路径**：Ticker API失败+DB回退出`?` → btc_pf=0 → calc_sl_tp返回(0,0,'?') → btc_sl_val=0 falsy → 回退到 L460 `"BTC 观望 | 空仓等风"`
- **矛盾**：此时 btc_dir_label 可能为 `'偏多'`（来自强共振），文案却显示"观望"
- **五轮审计 #24** 已修复 calc_sl_tp 的负 entry 守卫，但此问题仍未解决

### Bug 5b — `levels_4h` 为空列表时 `calc_sl_tp` 静默失败
- **代码位置**：L239 `not near_s or not near_r` — 空列表 `[]` 为 falsy
- **影响**：无 4H levels 数据时完全无法生成 SL/TP，且无任何告警

---

## Bug 6: 与 `social_analyses.json` 的字段名不匹配（3 处）

### Bug 6a — `near_bottom` 和 `bottom_note` 未写入 social_analyses.json
- **publish_social.py** L295-320 record 字典缺失这两个字段
- **analysis_template.py** analyses.json (L2069-2070) 包含
- **影响**：下游读取 social_analyses.json 的工具无法获取 near_bottom 信息

### Bug 6b — per-coin `macro_external` 始终为空字典
- **Wrapper L215**：`me = _rc.get('macro_external', {})` 从 regime_cache **顶层** 读取
- **regime_detector.py L1937**：存储在 `dimensions['macro_external']` **嵌套内**
- **影响**：`result['macro_external']` 恒为 `{}`，写入 social_analyses.json 的该字段永远为空
- **文档已记录**：data-provenance-map.md 注明 "social_analyses.json 的 macro_external 字段始终为 {}"

### Bug 6c — coin 字段值不一致（`BTC` vs `BTCUSDT`）
- **social_analyses.json**：存储为 `"BTCUSDT"` / `"ETHUSDT"` (publish_social.py L297)
- **analyses.json**：存储为 `"BTC"` / `"ETH"` (analysis_template.py L2052)
- **影响**：`process_reviews.py` L775-790 合并两者时可能产生重复记录

---

## 修复优先级建议

| 优先级 | Bug | 理由 |
|:--:|-----|------|
| 🔴 P0 | 1a, 1b, 1c | Wrapper 仓位与 _format_coin_section 不一致 → 社交文案方向可能错误 |
| 🔴 P0 | 3a, 3b | 叙事自相矛盾 → 发布即丢脸 |
| 🟠 P1 | 2a, 2b | 保存的方向标签错误 → 复盘数据污染 |
| 🟠 P1 | 5a, 5b | SL/TP 静默失败 → 用户看不到仓位信息 |
| 🟡 P2 | 3c, 3d, 4a, 4b | 数据源/关键词不完整 → 影响较小 |
| 🟡 P2 | 6a, 6b, 6c | 字段兼容性 → 已部分文档化 |
