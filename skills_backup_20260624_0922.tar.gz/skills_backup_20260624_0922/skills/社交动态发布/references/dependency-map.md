# 脚本依赖图谱 — 回退时必须协调

> 最后更新：2026-06-22  
> 触发场景：回退一个文件时必须连带回退其依赖链

## 关键依赖链

```
publish_social.py
  ├── imports calc_sl_tp ← _social_publish.py (module-level)
  ├── imports generate_social_draft ← _social_publish.py
  ├── imports analyze_single_coin ← _social_publish.py (wrapper)
  │     └── imports analyze_single_coin ← analysis_template.py (base)
  └── calls verify_social_post ← subprocess

verify_social_post.py
  ├── reads social_analyses.json (data source)
  └── 字段名依赖: levels_4h.lows/highs (新版) vs support/resistance (旧版)

_social_publish.py
  ├── provides calc_sl_tp (refactored only, not in b1d5752)
  ├── provides generate_social_draft
  └── import chain: analysis_template → 11 helper functions

analysis_template.py
  └── 由 _social_publish.py wrapper 导入

process_reviews.py
  └── 独立脚本，无直接 import 依赖
```

## 回退时的断裂点

| 操作 | 断裂症状 | 根因 |
|------|---------|------|
| 单独回退 `_social_publish.py` → b1d5752 | `ImportError: cannot import name 'calc_sl_tp'` | `publish_social.py` 导入的 `calc_sl_tp` 在 b1d5752 中不存在（它是内联 `_calc_sl_tp_pair`） |
| 单独回退 `verify_social_post.py` → b1d5752 | 核验 ❌ 10 项不匹配 | 旧版验证器读 `support`/`resistance`，新版 `social_analyses.json` 用 `levels_4h.lows`/`highs` |

## 回退规则

1. **回退任何文件时，整套 5+2 一起回退**（见 SKILL.md 10.24）
2. 如果只回退 `_social_publish.py` 但保留 `publish_social.py` 新版 → 必须在 `_social_publish.py` 补 `calc_sl_tp` 模块级函数（或用内联 `_sl_tp` 替代）
3. 回退后 `verify_social_post.py` 与新版 `social_analyses.json` 格式不兼容是正常现象（10.6 已知坑）
