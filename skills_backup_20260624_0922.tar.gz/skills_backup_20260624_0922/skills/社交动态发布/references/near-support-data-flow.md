# near_support / near_resistance 数据链路修复

## 问题

`analyze_single_coin()` wrapper 计算 `near_support`/`near_resistance`（基于 ATR 带宽筛选最近支撑阻力），但：
1. `publish_social.py` 的 record 构建未写入这两个字段 → `social_analyses.json` 缺失
2. `generate_social_draft()` fallback 到 `levels_4h`（任意高点）→ 阻力位错误
3. `verify_social_post.py` 也读 `levels_4h` → 核验失败

## 修复要点

### 1. publish_social.py — record 构建
```python
'record' = {
    ...
    'near_support': a.get('near_support', []),   # 新增
    'near_resistance': a.get('near_resistance', []),  # 新增
    ...
}
```

### 2. _social_publish.py — generate_social_draft
```python
btc_near_s = btc.get('near_support', []) or btc.get('levels_4h', {}).get('lows', [])
btc_near_r = btc.get('near_resistance', []) or btc.get('levels_4h', {}).get('highs', [])
# 如果 near_* 缺失但有 sl_val/tp_val，直接用
if not btc_near_s or not btc_near_r:
    s_btc = f'{int(btc_sl_val)}' if btc_sl_val else '?'
    r_btc = f'{int(btc_tp_val)}' if btc_tp_val else '?'
```

### 3. verify_social_post.py — 核验真值
```python
support = rec.get('near_support', []) or rec.get('levels_4h', {}).get('lows', [])
resistance = rec.get('near_resistance', []) or rec.get('levels_4h', {}).get('highs', [])
```

## 关键原则

**`near_support`/`near_resistance` 是权威数据源**（ATR 带宽筛选的最近支撑阻力），`levels_4h` 是旧数据源（任意高点）。三者必须同步更新：
- 写入 social_analyses.json
- generate_social_draft 读取
- verify_social_post 核验

任何一处不一致都会导致核验失败或文案错误。
