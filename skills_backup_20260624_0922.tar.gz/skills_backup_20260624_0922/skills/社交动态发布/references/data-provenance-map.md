# 社交动态文案 → 数据源映射表

> 最后更新：2026-06-22
> 用途：手动核验文案中的每个数字时，按此表溯源到正确的 JSON 文件 + 字段路径。

## 两个数据源

| 文件 | 内容 | 何时更新 |
|------|------|----------|
| `social_analyses.json` | 技术指标、VP、威科夫、支撑阻力、快讯、K线形态、仓位 | 每次 `publish_social.py` 运行时覆盖 |
| `.regime_cache.json` | 宏观外部数据（DXY/VIX/10Y/BTC.D/FG）+ 订单流（费率/Taker比） | `regime_detector` 写入，TTL 由脚本控制 |

## 完整字段映射

### 🕐 头部行

| 文案字段 | 源文件 | JSON 路径 |
|----------|--------|-----------|
| BTC 价格 | social_analyses.json | `[BTC记录].ticker.last` |
| ETH 价格 | social_analyses.json | `[ETH记录].ticker.last` |
| FG 值 | social_analyses.json | `[FG记录].fg_val` |
| FG 标签 | social_analyses.json | `[FG记录].fg_label` |

### 💡 大资金段

| 文案字段 | 源文件 | JSON 路径 |
|----------|--------|-----------|
| 威科夫阶段 | social_analyses.json | `wyckoff_data.phase` |
| 置信度 | social_analyses.json | `wyckoff_data.confidence` |
| 区间范围 | social_analyses.json | `wyckoff_data.detail`（raw string，解析得） |
| 回升% | social_analyses.json | `wyckoff_data.detail`（同上） |
| VP POC | social_analyses.json | `session_vp.poc` |

### 📐 盘面段

| 文案字段 | 源文件 | JSON 路径 |
|----------|--------|-----------|
| 日线 RSI | social_analyses.json | `indicators.1D.rsi`（`.0f` 取整） |
| 日线趋势 | social_analyses.json | `indicators.1D.trend` |
| 4H RSI | social_analyses.json | `indicators.4H.rsi`（`.0f`） |
| 4H MACD_h | social_analyses.json | `indicators.4H.macd_h`（`.0f`，正值=扩张，负值=收缩） |
| 4H ADX | social_analyses.json | `indicators.4H.adx`（`.0f`） |
| 4H 趋势 | social_analyses.json | `indicators.4H.trend` |
| 1H RSI | social_analyses.json | `indicators.1H.rsi`（`.0f`） |
| 1H MACD_h | social_analyses.json | `indicators.1H.macd_h`（`.0f`） |
| 1H 趋势 | social_analyses.json | `indicators.1H.trend` |
| 共振标签 | social_analyses.json | `resonance` |

### 📊 钱堆段

| 文案字段 | 源文件 | JSON 路径 |
|----------|--------|-----------|
| VP POC | social_analyses.json | `session_vp.poc` |
| VP VAH | social_analyses.json | `session_vp.vah` |
| VP VAL | social_analyses.json | `session_vp.val` |
| **费率** | **.regime_cache.json** | `dimensions.order_flow.funding_rate_pct` |
| **Taker 买卖比** | **.regime_cache.json** | `dimensions.order_flow.taker_buy_ratio` |

> ⚠️ `social_analyses.json` 的 `funding_rate_pct` 字段可能是 `null`（OKX API 51001 错误时）。费率真值在 `.regime_cache.json`。

### 🌍 宏观段

| 文案字段 | 源文件 | JSON 路径 |
|----------|--------|-----------|
| FG | **.regime_cache.json** | `dimensions.macro_external.fg_actual` |
| DXY | **.regime_cache.json** | `dimensions.macro_external.dxy`（`.1f` 取整） |
| VIX | **.regime_cache.json** | `dimensions.macro_external.vix` |
| VIX Δ% | **.regime_cache.json** | `dimensions.macro_external.vix_change_pct`（`.1f`） |
| 10Y | **.regime_cache.json** | `dimensions.macro_external.yield10` |
| BTC.D | **.regime_cache.json** | `dimensions.macro_external.btc_dominance` |
| 财经日历 | social_analyses.json | `calendar_events`（取 star≥4 的前 2-3 条） |

> ⚠️ `social_analyses.json` 的 `macro_external` 字段始终为 `{}`。宏观数据全部来自 `.regime_cache.json`。

### 📍 支撑阻力

| 文案字段 | 源文件 | JSON 路径 |
|----------|--------|-----------|
| S1 | social_analyses.json | `levels_4h.lows[0]`（`.0f`） |
| S2 | social_analyses.json | `levels_4h.lows[1]`（`.0f`） |
| R1 | social_analyses.json | `levels_4h.highs[0]`（`.0f`） |
| R2 | social_analyses.json | `levels_4h.highs[1]`（`.0f`） |

### 🎯 仓位段

| 文案字段 | 源文件 | JSON 路径 |
|----------|--------|-----------|
| 方向 | social_analyses.json | `position` |
| 入场价 | social_analyses.json | `entry_price` |
| 止损 | social_analyses.json | `sl_val` |
| 止盈 | social_analyses.json | `tp_val` |
| RR | social_analyses.json | `rr_str` |

### 📰 快讯段

| 文案字段 | 源文件 | JSON 路径 |
|----------|--------|-----------|
| 快讯内容 | social_analyses.json | `flash_news[i].content` |
| 快讯得分 | social_analyses.json | `flash_news[i].score` |
| 快讯时间 | social_analyses.json | `flash_news[i].time` |

> 过滤规则：白名单（38 关键词）+ 黑名单（20 排除词），取 top 3。详见 SKILL.md §10.28。

## 核验脚本覆盖盲区

`verify_social_post.py` 只读 `social_analyses.json`，因此以下字段**不被核验脚本覆盖**，需手动比对：

| 段落 | 不受覆盖的字段 | 手动溯源目标 |
|------|---------------|-------------|
| 📊 钱堆 | 费率、Taker买卖比 | `.regime_cache.json` → `order_flow` |
| 🌍 宏观 | DXY、VIX、VIX Δ、10Y、BTC.D、FG | `.regime_cache.json` → `macro_external` |

这些字段在核验脚本中属于「叙述性字段」，通过检查 JSON 真值是否在文案上下文中出现来校验（⚠️ 警告级，不阻断）。但脚本只查 `social_analyses.json`，所以宏观/费率数据的真值实际不会被找到——脚本会报 ⚠️ 但不会 ❌ 阻断。
