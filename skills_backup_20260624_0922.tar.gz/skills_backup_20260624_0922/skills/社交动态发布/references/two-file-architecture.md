# 双文件架构：analyses.json vs social_analyses.json

> 最后更新：2026-06-21（第三轮审计 P1/P2/P3 修复后）

## 分离原因

此前两个工作流共写 `analyses.json`，导致：
1. `analysis_template.py` 写入 flat_old 格式 → 被 `publish_social.py` fallback 的 full_obj 格式覆盖
2. 复盘引擎 `process_reviews.py` 的 `find_analysis()` 找不到原始分析记录 → `extract_lessons()` 因 `analysis=None` 返回空

## 当前架构

```
analysis_template.py  →  analyses.json         (flat_old，纯技术分析)
publish_social.py      →  social_analyses.json  (full_obj，社交发动态)

process_reviews.py  ←  同时读取两个文件，按 (coin, date) 去重，social 优先
```

## 文件格式对比

| 字段 | analyses.json (flat_old) | social_analyses.json (full_obj) |
|------|--------------------------|-------------------------------|
| 指标表 | `kline_table[TF].close/rsi/macd_h/adx/pct_b` | `indicators[TF].last_close/rsi/macd_h/adx/bb.pct_b` |
| 支撑/阻力 | `support[]`, `resistance[]`（顶层数组） | `levels_4h.lows[]`, `levels_4h.highs[]`（字典内嵌） |
| 底部研判 | `sentiment.spring_confirmed` | `near_bottom` (bool) |
| 共振 | `recommendation` | `resonance` (🟢/🟡/🔴) |
| 威科夫 | ❌ 不在标准字段 | `wyckoff_data.phase/confidence/detail` |
| Volume Profile | `session_vp.POC/VAH/VAL`（2026-06-21 从 vp_data 改名） | `session_vp.POC/VAH/VAL`（2026-06-21 统一） |
| K线形态 | `kline_pattern_times`（dict: name→timestamp） | `kline_patterns`（dict: `{patterns: [(tf,date,name,desc),...], summary, bars_used}`） |
| 日历 | `calendar_events[]` | `calendar_events[]` (MCP 实时) |
| 费率 | `order_flow.funding_rate_pct` | `funding_rate_pct`（顶层 float） |

## ⚠️ 关键字段映射陷阱

`verify_social_post.py` 从 `social_analyses.json` 读取数据核验文案，必须用 **full_obj 格式的字段名**，而非 flat_old 的：

| 数据 | ❌ 旧键（analyses.json flat_old） | ✅ 新键（social_analyses.json full_obj） |
|------|----------------------------------|----------------------------------------|
| 现价 | `kline_table.1H.close` | `indicators.1H.last_close` |
| RSI/MACD/ADX | `kline_table.4H.rsi/macd_h/adx` | `indicators.4H.rsi/macd_h/adx` |
| %b | `kline_table.4H.pct_b` | `indicators.4H.bb.pct_b` |
| 支撑 S1/S2 | `support[0]/support[1]` | `levels_4h.lows[0]/lows[1]` |
| 阻力 R1/R2 | `resistance[0]/resistance[1]` | `levels_4h.highs[0]/highs[1]` |
| K线形态 | `kline_pattern_times[pattern_name]` | `kline_patterns.patterns[i]`（tuple: tf, date, name, desc） |
| VP | `vp_data`（旧 analysis） | `session_vp`（统一后）+ 向后兼容 `vp_data` |

## 复盘引擎兼容

`process_reviews.py` 合并逻辑：
```python
# 1. 读 analyses.json (flat_old)
# 2. 读 social_analyses.json (full_obj)
# 3. 按 (coin, date) 去重，social 覆盖同日 analysis
# 4. extract_lessons() 兼容双格式字段映射
```

## publish_social.py 分析同步

`_social_publish.py` 的 `analyze_single_coin()` 是 **wrapper**，底层统一调用 `analysis_template.analyze_single_coin()`，保证两个工作流所有指标计算（RSI/MACD/ADX/BB/trend/label/accel/resonance）完全一致。在此基础上补充 5 个社交专用字段：

| 字段 | 来源 |
|------|------|
| `position` | 共振 + near_top 捷径 + V反保护，从 `_base_analyze` 计算的 resonance/rsi_1d/trend_1d 推导 |
| `session_vp` | `session_vp(coin, conn)` — 已从 analysis_template import |
| `wyckoff_data` | `wyckoff_detect(result_dict)` — 同上 |
| `calendar_events` | `get_jin10_key_events()` — 同上 |
| `macro_external` | 读 `regime_cache.json` |

**统一导入（2026-06-20 重构）**：`_social_publish.py` 从 `analysis_template` 导入了全部底层函数：
```python
from analysis_template import (
    session_vp, wyckoff_detect, detect_kline_patterns, get_jin10_key_events,
    is_closed, calc_rsi, calc_macd, calc_adx, calc_bollinger, calc_obv,
    candle_body_label, trend_direction, check_acceleration,
    check_extreme_oversold, check_data_event_window,
    get_rows, build_data_freshness,
    analyze_single_coin as _base_analyze,
    MACD_PARAMS, TIMEFRAMES,
)
```

此前两个文件各自定义了 11 个不同实现的底层函数，导致 `analyses.json` 和 `social_analyses.json` 中 13/22 关键字段不一致（ADX 48 vs 78、trend 上升 vs 盘整 等）。重构后删除 326 行重复代码，所有计算统一。

## 第三轮审计修复记录（2026-06-21）

| # | 文件 | 问题 | 修复 |
|---|------|------|------|
| P1 | `verify_social_post.py` L89-233 | 6 处字段名用 flat_old 键读取 full_obj | 改为 `indicators`/`levels_4h`/`kline_patterns`，`close`→`last_close`，`pct_b`→`bb.pct_b`，`kline_pattern_times`→`kline_patterns.patterns` |
| P2 | `verify_social_post.py` L286-291 + `publish_social.py` L176-361 | 回退跑 `analysis_template.py` 写 `analyses.json`，读的却是 `social_analyses.json` → 死循环 | `publish_social.py` 新增 `--verify-only` 模式（仅同步+分析+写入，跳过交互）；`run_analysis()` 改为调用 `publish_social.py --verify-only` |
| P3 | `analysis_template.py` L2072 | `vp_data` 与 `social_analyses.json` 的 `session_vp` 不一致 | 统一为 `"session_vp"`，`verify_social_post.py` L92 加 `rec.get('session_vp', rec.get('vp_data', {}))` 向后兼容 |
