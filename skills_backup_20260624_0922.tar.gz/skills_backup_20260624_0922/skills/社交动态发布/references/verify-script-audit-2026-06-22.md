# verify_social_post.py 深度审计 — 2026-06-22

> 审计范围：`/root/.hermes/trade_review/verify_social_post.py`（361行）
> 审计方法：读源码 → 读 social_analyses.json 结构 → Python 片段验证边界 → 追踪模板到核验的完整数据流 → 逐字段校对正则/键名/逻辑

---

## 一、字段名路径不匹配（3 个 Bug）

### Bug 1 — VP 字段键名大小写不匹配（VP 核验完全失效）🔴
**位置**: L182-189  
**根因**: JSON 中 `session_vp` / `vp_data` 的键名是**小写** `poc`/`vah`/`val`，代码用**大写** `'POC'`/`'VAH'`/`'VAL'` 读取。Python dict 大小写敏感，`.get('POC', 0)` 永远返回默认值 0。然后 `if vp_val:` (L186) 跳过 0。  
**影响**: POC/VAH/VAL 三项核验从未真正执行 — 即使文案写错了 VP 值也验不出。

| JSON 实际键 | 代码读法 | 返回值 | 结果 |
|---|---|---|---|
| `"poc": 64239.6` | `.get('POC', 0)` | 0 | 跳过 |
| `"vah": 64549.8` | `.get('VAH', 0)` | 0 | 跳过 |
| `"val": 63619.2` | `.get('VAL', 0)` | 0 | 跳过 |

**修复**: 改为小写 `.get('poc', 0)` / `.get('vah', 0)` / `.get('val', 0)`

### Bug 2 — macro_external 始终为空，宏观核验永不触发 🔴
**位置**: L99 `me = rec.get('macro_external', {})`，L200-213 宏观循环  
**根因**: `social_analyses.json` 所有记录的 `macro_external` 字段都是 `{}`。实际宏观数据（DXY=100.9, VIX=16.4, 10Y=4.45, BTC.D=56.2）在 `.regime_cache.json` 的 `dimensions.macro_external` 中，验证器从不读取该文件。  
**影响**: DXY/VIX/10Y/BTC.D 四项永远静默跳过。

**修复**: 要么把 regime_cache 的 macro_external 写入 social_analyses.json，要么验证器直接读取 `.regime_cache.json`。

### Bug 3 — _load_analyses 同一币种取最旧而非最新记录 🟡
**位置**: L52-65，`if coin_name not in out: out[coin_name] = r`  
**根因**: 当同一币种在 120 分钟窗口内有**多条**记录时，代码保留 JSON 数组中**最早出现**的那条（通常是最旧的），注释写「取最新」但逻辑相反。  
**影响**: 验证器可能核验已过时的数据。

**修复**: 改为 `.get(coin_name)` 后比较 timestamp，保留更新的记录。

---

## 二、正则边缘情况（6 个 Bug）

### Bug 4 — 支撑/阻力分隔符 `→` 不容忍空格 🟠
**位置**: L123, L127  
**正则**: `rf'📍\s*{coin}\s*支撑\s*([\d,.]+)→([\d,.]+)'`  
**问题**: 要求 `→` 前**不能有空格**。如果文案写成 `62222 → 61559`（带空格），匹配失败，S1/S2/R1/R2 全部报「文案提取失败」。

### Bug 5 — 阻力 regex 中 `.*?` 可跨行误匹配 🟠
**位置**: L127 `rf'📍\s*{coin}\s*.*?阻力\s*([\d,.]+)→([\d,.]+)'`  
**问题**: `.` 可跨行，`.*?` 非贪婪但若文案重排，可能匹配到错误币种的阻力。低概率但真实存在。

### Bug 6 — 入场/止损/止盈 regex 三人独立搜索，交叉币种风险 🟡
**位置**: L147-157  
**问题**: 三个 `re.search` 各自从全文开头搜索，`.*?` 可跨行。如果文案 🎯 ETH 行在 BTC 行之前，`BTC.*?入场` 可能匹配到 ETH 行的数字。

### Bug 7 — 止损/止盈字符类缺少小数点 🟡
**位置**: L150 `[\d,]`，L153 `[\d,]`  
**对比**: 入场用 `[\d,.]`（含小数点），止损止盈用 `[\d,]`（不含小数点）。当前模板格式化为整数所以不触发，但属于脆弱的隐式契约。

### Bug 8 — 观望检测 `.*?\d+` 跨行误报 🟡
**位置**: L141 `rf'🎯\s*{coin}.*?\d+'`  
**场景**: `🎯 BTC 观望 | 空仓等风` 本行无数字，但下一行 `🎯 ETH 偏多 | 入场1731` 有数字 → `.*?` 跨行匹配到 ETH 的数字 → 误报「BTC 观望但文案误加了数字」。

### Bug 9 — RR 正则硬编码 `1:` 前缀 🟡
**位置**: L156 `rf'🎯\s*{coin}.*?RR\s*1:([\d,.]+)'`  
**问题**: 格式改为 `RR 2.8` 等即失效。当前模板用 `RR 1:{rr_str}` 暂不触发。

---

## 三、观望处理完备性（3 个 Bug）

### Bug 10 — 零值舍入触发「未找到 0」误报 🟡
**位置**: L176 `if val and str(val) in post_text:`  
**场景**: `macd_h` 在 JSON 中为 -0.3，round 后为 0。`if val` 为 False → 走 else 报 `⚠️ MACD_h 4H: 文案中未找到 0`。但 0 是合法舍入结果，不应报警。同理 pct_b。

### Bug 11 — `position='观望（等确认）'` 含完整 sl_val/tp_val 但被跳过 🟠
**位置**: L139 `if '观望' in str(position)`  
**问题**: JSON 中该 position 的记录仍有完整的 entry/sl/tp/rr 字段，但因匹配 `'观望'` 被跳过核验。如果未来模板对「等确认」输出参考价位，这些字段无人核验。

### Bug 12 — position 字段缺失时静默退化 🟡
**位置**: L136 `position = rec.get('position', '')`  
**场景**: 记录缺失 position，`''` 不匹配 '观望'，走 else 分支。但 entry/sl/tp 可能也缺失 → if 守卫跳过，不崩溃也不报警。

---

## 四、盲区 — 从未被验证的数据（6 项）

### 盲区 1 — 宏观数据（DXY/VIX/10Y/BTC.D）🔴
同上 Bug 2，`social_analyses.json` 的 `macro_external` 始终为空。

### 盲区 2 — 费率（funding_rate_pct）🔴
`social_analyses.json` 所有记录的 `funding_rate_pct` 都是 `null`，`if fr_pct is not None` 守卫跳过。实际费率在 `.regime_cache.json` 的 `order_flow.funding_rate_pct`。

### 盲区 3 — 1H 时间框架指标全部死代码 🔴
**位置**: L162-167 计算了 `rsi_1h/macd_1h/adx_1h/pct_b_1h`，但 L169-174 列表**只包含 4H 值**。1H 四个值全部计算但从不校验。模板在 📐 段确实输出了 1H RSI 和 1H MACD。

### 盲区 4 — %b 模板从不输出，核验永远失败 🟠
模板（`_social_publish.py`）全文不输出 `%b` 或布林带数值。`str(pct_b_4h) in post_text` 永远为 False → 每次都产生 `⚠️ %b 4H: 文案中未找到`。

### 盲区 5 — 威科夫阶段核验关键词「威科夫」不在文案中 🟠
**位置**: L220 `_check_near(post_text, '威科夫', ...)`  
**根因**: 模板生成的文案从不出现「威科夫」三字（只在代码注释中有）。`re.search('威科夫', post_text)` 永远返回 None → 阶段核验永远报警。

### 盲区 6 — resonance/多空比/波动率/taker_buy_ratio/calendar_events 从不校验 🟡
这些字段在 JSON 中存在且模板也输出了，但验证器无对应校验。

---

## 五、误报/漏报风险（9 项）

### 误报 1 — 指标值全文子串匹配导致假阳性 🔴
**位置**: L176 `str(val) in post_text`  
**根因**: 全文无上下文子串搜索。RSI=46 会在 `"BTC $63460"` 中匹配到 `"...46..."`；MACD=-249 会在 `"63249"` 中匹配。小数值（40-99 区间）碰撞概率极高。

### 误报 2 — %b 永远触发「未找到」（同上盲区 4）🔴

### 误报 3 — 威科夫阶段永远触发「未找到」（同上盲区 5）🔴

### 漏报 1 — `add_check` 跳过零值不区分「字段缺失」和「实际值=0」🟠
**位置**: L87 `if json_val == 0: return`  
**场景**: MACD 实际为 0 → 静默跳过 → 文案无论写不写 MACD 都通得过。

### 漏报 2 — K 线形态 `replace('@', '')` 丢失空格 🟠
**位置**: L241 `p_val.replace('@', '')`  
**场景**: `'Spring@06-19 00:00'.replace('@', '')` → `'Spring06-19 00:00'`（形态名与日期之间无空格）。模板输出有空格分隔 → 匹配失败 → K 线形态核验漏报。

### 漏报 3 — `indicator` 校验 `if val` 短路导致 0 值误报 🟠
**位置**: L176 `if val and str(val) in post_text:`  
**场景**: val=0 时 `if val` 为 False → 直接报「未找到 0」。应区分「值为 0 无需校验」和「值非零但找不不到」。

### 漏报 4 — `_check_near` 对 p_name 做正则搜索未 escape 🟡
**位置**: L28（`_check_near` 内部）`re.search(keyword_regex, text)`  
**场景**: 当前形态名（Spring/LPS/SOS）不含正则特殊字符，但若未来新增含 `.` `+` `*` 的形态，正则会意外匹配或崩溃。应 `re.escape(p_name)`。

---

## 六、其他代码质量

- **FG 记录无年龄检查**（L67-76）：FG 完全跳过 `MAX_AGE_MIN`，21 天前的 FG 也会被使用。
- **FG 异常回退时间戳**（L73）：`datetime.min.replace(tzinfo=timezone.utc)` → 年份 0001，若所有记录都异常则会选出无效候选。
- **subprocess stderr 未处理**（L293）：`publish_social.py` 失败时错误信息可能混入 stdout 被忽略。
