# 全工作流审计报告 — 2026-06-22

五轮共 24 项，全部修复。修改涉及 5 个文件。

## 第一轮（14 项 — 全量初始审计）

| # | 严重度 | 文件 | 修复 |
|:--:|:--:|------|------|
| 1 | 🔴 | `_social_publish.py:258` | SR格式 `$62,222/$62,254` → `62222→62254` |
| 2 | 🔴 | `verify_social_post.py:140` | `continue` → `else:`，观望时仍验叙述字段 |
| 3 | 🔴 | `analysis_template.py:1799` | `position` 未定义 → `_pos_quick` 从共振推导 |
| 4 | 🔴 | `_social_publish.py:160` | wrapper 缺少 `near_bottom→偏多` 路径 |
| 5 | 🟠 | `analysis_template.py:1293` | stdout/JSON 做多条件不一致 → 统一 |
| 6 | 🟠 | `_social_publish.py:161` | 缺少 `rsi_1d>65+MACD<-50` 做空路径 |
| 7 | 🟠 | `verify_social_post.py:62` | USDT 币种取最早记录 → 按时间戳取最新 |
| 8 | 🟠 | `analysis_template.py:121` | `-24<=hours<=0` 死条件 → `-24<=hours<-12` |
| 9 | 🟠 | `process_reviews.py:442` | `levels_score==-1` 死分支 → 新增支撑失效 case |
| 10 | 🟡 | `publish_social.py:284` | `_calc_sl_tp_pair` 重复实现（确认，第三轮统一） |
| 11 | 🟡 | `analysis_template.py:199` | `bj_time()` 标记弃用 |
| 12 | 🟡 | `_social_publish.py:22-35` | 清理 17 个未用导入 |
| 13 | 🟡 | `process_reviews.py:93` | lessons.json 过滤空条目 |
| 14 | 🟡 | `verify_social_post.py:37` | 千分位逗号匹配断裂 → 去逗号二次匹配 |

## 第二轮（5 项 — 修复第一轮引入的回归 + 遗漏）

| # | 严重度 | 文件 | 修复 |
|:--:|:--:|------|------|
| 15 | 🔴 | `analysis_template.py:1293` | 修复 #5 后 `near_bottom` 未从 `a` 取值 → `a.get('near_bottom')` |
| 16 | 🔴 | `verify_social_post.py:161-170` | 修复 #2 时 patch 工具双重转义 `\\\\d` → regex 永不会匹配数字 |
| 17 | 🔴 | `analysis_template.py:2038` | JSON builder 缺少 `rsi_1d>65+MACD<-50` 做空路径 |
| 18 | 🟡 | `analysis_template.py:1800` | `_pos_quick` fallback 忽略 near_bottom |
| 19 | 🟡 | `_social_publish.py:152` | 修复 #6 的 MACD 阈值 `<0` vs stdout/JSON 的 `<-50` |

## 第三轮（3 项 — 端到端优化）

| # | 严重度 | 修复 |
|:--:|:--:|------|
| 20 | 🟡 | SL/TP 统一到模块级 `calc_sl_tp()`（删除 `publish_social.py` 67 行重复） |
| 21 | 🟡 | 核验器叙事字段从关键词正则 → 值匹配（消除 12 个 ⚠️ 假阳性） |
| 22 | 🟡 | `_pos_quick` 补全 L1/L1b 做空捷径 |

## 第四轮（1 项 — 集成测试发现）

| # | 严重度 | 文件 | 修复 |
|:--:|:--:|------|------|
| 23 | 🔴 | `_social_publish.py:389` | BTC 入场千分位逗号 `{int(x):,}` → `64,200` 导致 regex `[\d.]+` 截断为 `64`，核验偏差 99.9% → 移除 `:,` 格式 |

## 第五轮（1 项 — 极端值审计）

| # | 严重度 | 文件 | 修复 |
|:--:|:--:|------|------|
| 24 | 🟡 | `_social_publish.py:218` | `calc_sl_tp` 无负 entry 守卫 → 增加 `entry <= 0` 提前返回 |

## 关键陷阱经验

### patch 工具双重转义（#16）
使用 `patch()` 修改 Python raw string 中的正则（`rf'...\d...'`）时，工具可能把 `\\d` 转成 `\\\\d`，导致正则匹配字面 `\d` 而非数字。修复方法：用 `python3 << 'PYEOF'` 字节级替换。

### 方向判定 5 处同步（#20 附则）
修改做多/做空/观望条件时，必须同步：`_format_coin_section` / wrapper / JSON builder / `_pos_quick` / `extract_direction()`。

### 核验器与文案格式张力（#21）
`verify_social_post.py` 的叙述字段检查原用分析报告格式的关键词正则，社交文案是无结构化口语 → 改为值匹配（检查数字是否出现在文案中）。

### 千分位逗号破坏 regex（#23）
`{int(x):,}` 产生的 `64,200` 会被 `[\d.]+` 截断为 `64`。文案中的所有数字统一不加千分位逗号。

### 多重审计纪律
每次修改后必须从零重读文件、运行全覆盖集成测试（6 场景 + 5 极端值）、验证 5 处方向逻辑一致、检查 SL/TP 单一实现。

## 最终状态
- 语法：5/5 文件通过
- 导入链：完整无断
- 核验器：15/15+ 结构化字段通过（6 场景 0 ❌）
- 方向逻辑：5 处完全一致
- SL/TP：单一 `calc_sl_tp()` 实现
- calc_sl_tp 极端值：5/5 通过
