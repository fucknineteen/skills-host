# 从 compacted session 恢复五轮审计状态

## 背景

当模型切换导致之前的会话被 compacted，且需要恢复到某个已知版本（如五轮审计 24 项修复后的状态）时，`session_search` 可能找不到原始 diff。

## 恢复步骤

### 1. 回退到 Git 最新快照

从镜像仓库取出 b1d5752（或最新 known-good commit）：

```bash
cd /root/.hermes/skills-host-mirror
for f in \
  '社交/社交动态发布/scripts/_social_publish.py' \
  '社交/社交动态发布/scripts/publish_social.py' \
  '社交/社交动态发布/scripts/verify_social_post.py' \
  '分析/加密货币纯分析/scripts/analysis_template.py' \
  '分析/加密货币纯分析/scripts/process_reviews.py'; do
    git show b1d5752:"$f" > /root/.hermes/trade_review/$(basename "$f")
done
```

### 2. 读取审计记录

`references/code-audit-2026-06-22.md` 包含完整的 24 项修复清单，含文件、行号、代码级描述。这是比 `session_search` 更可靠的恢复来源。

### 3. 按优先级逐文件修复

因修复分布在 5 个文件中且互相依赖，需成套实施：

| 批次 | 文件 | 关键修复 | 依赖 |
|------|------|---------|------|
| ① | `_social_publish.py` | #20 (`calc_sl_tp` 模块级) + #24 (负entry守卫) | 无 |
| ② | `publish_social.py` | #10 (删除inline重复, import calc_sl_tp) | 依赖① |
| ③ | `verify_social_post.py` | #2 (continue→else:) + #7 (FG按时间戳) + #14 (千分位) + #21 (值匹配) | 无 |
| ④ | `analysis_template.py` | #3-#6,#8,#11,#12,#15,#17,#18 (方向同步等) | 依赖① |
| ⑤ | `process_reviews.py` | #9 (死分支) + #13 (空条目过滤) | 无 |

### 4. 验证

每一批完成后跑 `py_compile` 验证语法，全部完成后跑 `python3 publish_social.py BTC ETH` 端到端测试。

## 关键教训

- **审计记录是权威来源**：`references/code-audit-2026-06-22.md` 比 `session_search` 更可靠
- **成套回退**：5 个脚本 + SKILL.md 必须一起回退，单独回退 `_social_publish.py` 会因 `publish_social.py` 的 `calc_sl_tp` import 而崩溃
- **不要凭记忆**：line numbers 在不同版本间会偏移，用 `grep` 搜索代码模式定位
- **时间点歧义**：用户说「回退到 10 点半」时先追问是「原始版」还是「修改后的版本」再动手
