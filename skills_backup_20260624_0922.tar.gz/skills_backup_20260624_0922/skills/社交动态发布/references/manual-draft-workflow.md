# 手动撰写社交动态文案流程

> 最后更新：2026-06-22
> 适用场景：`generate_social_draft()` 输出不完整（缺少复盘、VP细节、快讯过长），或自动流水线核验失败时手动修复。

## 前置步骤

### 1. 同步 + 分析
```bash
cd /root/.hermes/trade_review
PYTHONPATH=/root/.hermes/trade_review python3 publish_social.py --verify-only BTC ETH
```
这会更新 `social_analyses.json`。

### 2. 复盘上条
```bash
PYTHONPATH=/root/.hermes/trade_review python3 scripts/review_last_post.py --save
```
**注意**：`--verify-only` 模式不调用复盘，必须单独运行。否则文案中"上条复盘"段落为空。

### 3. 清理旧FG记录（防核验假阳性）
```bash
cd /root/.hermes/trade_review
python3 -c "
import json
with open('social_analyses.json') as f:
    data = json.load(f)
fg_indices = [i for i, r in enumerate(data) if r.get('coin') == 'FG']
for idx in sorted(fg_indices[:-1], reverse=True):
    del data[idx]
with open('social_analyses.json', 'w') as f:
    json.dump(data, f, ensure_ascii=False, indent=2)
"
```

## 数据提取模板

从 `social_analyses.json` 提取关键数据（以BTC为例）：

```python
import json
with open('social_analyses.json') as f:
    data = json.load(f)

btc = eth = None
for e in data:
    if e.get('coin') == 'BTCUSDT': btc = e
    elif e.get('coin') == 'ETHUSDT': eth = e

# BTC
btc_price = btc.get('ticker', {}).get('last')  # 63430.4
btc_position = btc.get('position')  # 观望（等确认）
btc_resonance = btc.get('resonance')  # 🟡分歧
btc_levels = btc.get('levels_4h', {})
btc_support = btc_levels.get('lows', [])[:2]  # [62222.2, 62253.6]
btc_resistance = btc_levels.get('highs', [])[:2]  # [66426.6, 66246.8]
btc_svp = btc.get('session_vp', {})  # VP数据
btc_ind = btc.get('indicators', {})  # 指标

# 宏观数据（从 regime_cache）
with open('.regime_cache.json') as f:
    rc = json.load(f)
dim = rc.get('dimensions', {})
fg_val = dim['macro_external'].get('fg_actual')  # 20
dxy = dim['macro_external'].get('dxy')  # 100.85
vix = dim['macro_external'].get('vix')  # 16.4
```

## 文案格式要求（核验器兼容）

| 字段 | 格式 | 示例 |
|------|------|------|
| 价格 | 无千分位逗号，无$符号 | `63430` |
| 支撑阻力 | `→` 分隔，无$符号 | `62222→62254` |
| FG值 | `FG:20` | `FG:20(Extreme Fear)` |
| 🎯行（观望） | 不加🎯前缀 | `BTC 观望 | 空仓等风` |

## 核验
```bash
python3 verify_social_post.py "完整文案文本"
```

## 参考：2026-06-22 实际文案
见 `/tmp/social_draft_v2.txt`（已通过11/11核验）。
