#!/usr/bin/env python3
"""
社交动态文案数据提取脚本。
从 social_analyses.json 中提取最新BTC/ETH数据，输出文案所需的所有数字。
用法：python3 scripts/extract_social_data.py
"""
import json, os, sys

# ⚠️ P3-5: Hardcoded paths — these are intentional for the social skill's
# standalone operation. Consider using _shared.TRADE_DIR if social skill
# is ever moved into trade_review/ directory.
ANALYSES_FILE = '/root/.hermes/trade_review/social_analyses.json'
REGIME_FILE = '/root/.hermes/trade_review/.regime_cache.json'

if not os.path.exists(ANALYSES_FILE):
    print('❌ social_analyses.json 不存在，请先运行 publish_social.py --verify-only BTC ETH')
    sys.exit(1)

with open(ANALYSES_FILE) as f:
    data = json.load(f)

# 取最新 BTCUSDT/ETHUSDT 记录
btc = eth = None
for e in reversed(data):
    if e.get('coin') == 'BTCUSDT' and btc is None:
        btc = e
    elif e.get('coin') == 'ETHUSDT' and eth is None:
        eth = e

for coin, d in [('BTC', btc), ('ETH', eth)]:
    if not d:
        print(f'❌ {coin}: 无数据')
        continue
    ind = d.get('indicators', {})
    vp = d.get('session_vp', {})
    wy = d.get('wyckoff_data', {})
    lv = d.get('levels_4h', {})
    tk = d.get('ticker', {})

    print(f'=== {coin} ===')
    print(f'  现价: {tk.get("last", "?")}')
    for tf in ['1D', '4H', '1H']:
        i = ind.get(tf, {})
        print(f'  {tf}: close={i.get("last_close","?")} trend={i.get("trend","?")} '
              f'RSI={i.get("rsi",0):.0f} MACD_h={i.get("macd_h",0):.0f} '
              f'ADX={i.get("adx",0):.0f} label={i.get("label","?")}')
    print(f'  VP: POC={vp.get("poc","?")} VAH={vp.get("vah","?")} VAL={vp.get("val","?")}')
    print(f'  Wyckoff: phase={wy.get("phase","?")} conf={wy.get("confidence","?")}')
    print(f'  Levels: lows[:2]={lv.get("lows",[])[:2]} highs[:2]={lv.get("highs",[])[:2]}')
    print(f'  resonance: {d.get("resonance","?")} | position: {d.get("position","?")}')
    print(f'  funding_rate_pct: {d.get("funding_rate_pct","?")}')
    print()

# 宏观数据
if os.path.exists(REGIME_FILE):
    with open(REGIME_FILE) as f:
        rc = json.load(f)
    dim = rc.get('dimensions', {})
    me = dim.get('macro_external', {})
    of = dim.get('order_flow', {})
    print('=== 宏观 (regime_cache) ===')
    print(f'  FG: {me.get("fg_actual","?")} ({me.get("fg_label","?")})')
    print(f'  DXY: {me.get("dxy","?")} | VIX: {me.get("vix","?")} | 10Y: {me.get("yield10","?")} | BTC.D: {me.get("btc_dominance","?")}')
    print(f'  FR: {of.get("funding_rate_pct","?")} | Taker: {of.get("taker_buy_ratio","?")}')
