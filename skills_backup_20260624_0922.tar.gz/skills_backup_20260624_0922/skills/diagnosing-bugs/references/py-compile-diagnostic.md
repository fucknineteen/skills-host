# py_compile 诊断语法错误

## 何时使用

当脚本产生空/错误数据但无报错信息时，可能是：
1. 语法错误导致模块无法导入
2. 调试语句放在字典字面量内部
3. try-except 吞掉了异常

## 诊断命令

```bash
# 1. 语法检查
python -c "import py_compile; py_compile.compile('path/to/file.py', doraise=True)"

# 2. 模块导入测试
python -c "import sys; sys.path.insert(0, 'path/to/dir'); import module_name"

# 3. 查找特定行号
python -c "
import py_compile
try:
    py_compile.compile('path/to/file.py', doraise=True)
except py_compile.PyCompileError as e:
    print(f'行{e.lineno}: {e.msg}')
"
```

## 典型症状

| 症状 | 可能原因 |
|------|---------|
| 数据始终为空 {} | 变量被覆盖 / 语法错误 / try-except 吞异常 |
| 模块导入失败 | 语法错误 / 循环导入 / 路径错误 |
| 无报错但数据不对 | 字段名映射错误 / 数据源切换 |
| 偶尔成功偶尔失败 | 竞态条件 / 缓存过期 |

## 排查顺序

1. `py_compile` → 确认无语法错误
2. `import module` → 确认能导入
3. 检查数据源文件是否存在且有数据
4. 搜索变量同名覆盖（`grep -n 'var = ' file.py`）
5. 检查 try-except 块是否吞了异常
