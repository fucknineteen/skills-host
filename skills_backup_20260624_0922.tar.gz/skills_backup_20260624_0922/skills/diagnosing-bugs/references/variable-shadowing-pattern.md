# 变量覆盖导致的静默数据丢失

## 场景

从数据源 A（如 regime_result）提取数据到变量 X，随后代码用数据源 B（如 dict `a`）的值**覆盖** X，但数据源 B 中不存在对应的键，导致 X 被重置为空对象。

## 症状

- 上游数据源有完整数据（regime_cache.json 中 order_flow 包含 funding_rate_pct, fr_pos_ratio, taker_buy_ratio 等）
- 下游输出数据（analyses.json）中该字段始终为空 `{}`
- 代码审查时容易遗漏，因为覆盖逻辑看起来"合理"（从 a 中提取 order_spread/order_offset）

## 根因模式

```python
# 第1步：从 regime_result 提取 order_flow（正确）
order_flow = {}
if regime_result:
    of_data = regime_result.get('dimensions', {}).get('order_flow', {})
    order_flow = {'funding_rate_pct': ..., 'detail': ..., ...}

# 第2步：从 a 中提取 order_flow（覆盖！）
order_flow = {}  # ← 重置！之前的数据丢了
if 'order_spread' in a:
    order_flow = {'spread': ..., 'offset': ...}
```

## 修复

```python
# 用 update() 合并而非赋值覆盖
if 'order_spread' in a:
    order_flow.update({
        'spread': a.get('order_spread', ''),
        'offset': a.get('order_offset', ''),
    })
```

## 检测

- 搜索代码中同一变量名在同一作用域内被赋值两次以上
- 第二次赋值是 `var = {}` 或 `var = some_dict` 而非 `var.update()` 或 `var |=`
- 检查第二次赋值的条件分支是否总是满足（即 `if 'key' in source` 中的 key 是否真的存在）
