# 三层复盘引擎 — 已知陷阱全量状态

> 最后更新: 2026-06-23（四轮审计后）  
> 状态: **全部 23 项已修复 ✅**

## 致命 (3/3 ✅)

| # | 描述 | 修复日期 | 修复方式 |
|---|------|---------|---------|
| 5 | near_bottom 在 social_analyses.json 中缺失 | 2026-06-23 | publish_social.py L388 写入字段 |
| 6 | regime=None 静默丢失教训 | 2026-06-22 | `regime = 'unknown'` 兜底 |
| 7 | 3根K线 SOS 检测 max([]) 崩溃 | 2026-06-22 | 长度检查 >=4 |

## 高/中优先级 (8/8 ✅)

| # | 描述 | 修复日期 | 修复方式 |
|---|------|---------|---------|
| 8 | find_analysis 格式混杂 | 2026-06-23 R1 | flat_old→full_obj 标准化 |
| 9 | 12h 事件检测用 lessons_warnings | 2026-06-22 | 统一 get_key_events() |
| 10 | 72h 缺少多头误判教训 | 2026-06-22 | 增加 bullish+跌>3% 分支 |
| 11 | 去重 str(None) 误判 | 2026-06-23 R1 | `r.get(k) or '待复盘'` |
| 12 | verdict_map 缺 (flat, up/down) | 已修复 | 增加横盘偏多/偏空 |
| 13 | 6h 事件标注覆盖 | 已修复 | 列表收集+join |
| 14 | near_bottom/spring 变量混淆 | 已修复 | 分离变量+独立 detail |
| 15 | levels_score 不区分原因 | 2026-06-23 R1 | 区分"价位缺失"/"价位未触及" |

## 低优先级 (6/6 ✅)

| # | 描述 | 状态 |
|---|------|------|
| - | parse_timestamp 硬编码 | 改用 BJT 常量 |
| - | RSI=0/FG=0 falsy | 使用 `is not None` 检查 |
| - | classify_price_path first_close | 确认正确 (closes[0]) |
| - | detect_direction 死代码 | 已清理 |
| - | walrus operator | 已移除 |
| - | 归档截断 | 使用 OKX 时间 (now_utc) |

## 2026-06-23 新增保护

**`process_reviews.py` 新增 helper (L17-53)**:
- `_extract_near_bottom(analysis)` — 统一提取，3 调用点
- `_extract_rsi(analysis)` — `is not None` 保护零值，3 调用点
- `_extract_fg(analysis)` — `is not None` 保护零值，3 调用点
- `KNOWN_EVENT_KEYWORDS` — 事件常量，4 调用点

**`analysis_template.py` 新增**:
- `detect_v_reversal(closed_4h, ticker_last)` — V反统一，4 调用点

## 历史陷阱 (2026-06-19/20, 4/4 ✅)

| # | 描述 | 状态 |
|---|------|------|
| 1 | FG/REVIEW 污染 reviews.json | ✅ SKIP_COINS 过滤 |
| 2 | "待复盘" 哨兵值误判 | ✅ 代码逻辑正确 |
| 3 | order_flow 语法错误 | ✅ 已修复 |
| 4 | analyses.json 覆盖 | ✅ 双文件分离 |
