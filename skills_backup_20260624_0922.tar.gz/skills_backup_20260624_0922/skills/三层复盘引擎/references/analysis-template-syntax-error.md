# analysis_template.py 语法错误与 order_flow 覆盖 Bug — ✅ 已修复

**发现时间**: 2026-06-19 22:00  
**修复时间**: 2026-06-19 22:35  
**状态**: ✅ 已修复

## 问题 1：SyntaxError — 调试 print 在字典内部

**文件**: `analysis_template.py`  
**行号**: L2183（已删除）

```python
# 修复前（错误）
                # Order flow
            print(f'DEBUG record order_flow={order_flow}', file=sys.stderr)  # ← 语法错误！
                "order_flow": order_flow,
```

`print()` 在字典字面量内部 → SyntaxError: ':' expected after dictionary key

## 问题 2：order_flow 二次覆盖

**文件**: `analysis_template.py`  
**行号**: L1989-2002（第一次提取），L2041-2047（覆盖，已修复）

**修复后 L2041-2047**:
```python
# 合并而非覆盖
if 'order_spread' in a:
    order_flow.update({
        'spread': a.get('order_spread', ''),
        'offset': a.get('order_offset', ''),
    })
```

**修复后 L1989-2002**（删除了残留的调试 print）:
```python
order_flow = {}
if regime_result:
    regime_dim = regime_result.get('dimensions', {})
    of_data = regime_dim.get('order_flow', {})
    if isinstance(of_data, dict):
        order_flow = {
            'funding_rate_pct': of_data.get('funding_rate_pct', ''),
            'fr_pos_ratio': of_data.get('fr_pos_ratio', ''),
            'fr_avg_8d': of_data.get('fr_avg_8d', ''),
            'taker_buy_ratio': of_data.get('taker_buy_ratio', ''),
            'detail': of_data.get('detail', ''),
        }
```

## 验证结果

修复后运行 `analysis_template.py BTC ETH`：
- ✅ 语法检查通过
- ✅ 模块导入成功
- ✅ analyses.json 中 order_flow 写入完整数据（funding_rate_pct, fr_pos_ratio, fr_avg_8d, taker_buy_ratio, detail）
- ✅ macro_external 和 calendar_events 也正常写入

## 遗留问题

- publish_social.py 有独立的 analyses.json 写入逻辑（full_obj 格式），不含 order_flow。两个脚本同时写入同一文件，schema 不同。长期应统一写入路径。
- try-except 吞异常（L2240）是防御性设计，当前不影响功能，但未来排查问题时可能掩盖真正错误。
