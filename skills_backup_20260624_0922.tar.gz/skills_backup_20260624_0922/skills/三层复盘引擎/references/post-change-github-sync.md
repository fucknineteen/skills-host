# 代码修改后 GitHub 同步验证

> 2026-06-20 工作总结

## 背景

修改工作流脚本 / skill 文档后，GitHub mirror（`skills-host-mirror`）未必自动同步到最新。`auto_push_github.sh` cron 每 5 分钟同步一次，但如果文件路径不在同步列表里（如 skill SKILL.md），需要手动检查。

## 验证流程

```bash
# 1. 拉取 GitHub 最新
cd /root/.hermes/skills-host-mirror
git pull --ff-only origin master

# 2. 逐文件对比本地 ↔ mirror
# 脚本类（auto_push 覆盖的）
diff /root/.hermes/trade_review/analysis_template.py \
     /root/.hermes/skills-host-mirror/crypto-analysis-workflow/scripts/analysis_template.py

diff /root/.hermes/trade_review/_social_publish.py \
     /root/.hermes/skills-host-mirror/social-posting-workflow/scripts/_social_publish.py

# Skill 文档（auto_push 不覆盖的）
diff /root/.hermes/skills/analysis/crypto-analysis-workflow/SKILL.md \
     /root/.hermes/skills-host-mirror/crypto-analysis-workflow/SKILL.md

diff /root/.hermes/skills/social/social-posting-workflow/SKILL.md \
     /root/.hermes/skills-host-mirror/social-posting-workflow/SKILL.md

# 3. 如有不一致 → 手动 cp + commit + push
cp /path/to/local/file /root/.hermes/skills-host-mirror/target/path/
cd /root/.hermes/skills-host-mirror
git add -A
git commit -m "sync: 更新描述"
git push origin master
```

## 一键对比脚本

```bash
cd /root/.hermes/skills-host-mirror && git pull --ff-only origin master

MIRROR="/root/.hermes/skills-host-mirror"
TRADE="/root/.hermes/trade_review"
SCRIPTS="/root/.hermes/scripts"

mismatches=0
for pair in \
    "$SCRIPTS/sync_klines_cron.sh:$MIRROR/cron/sync_klines_cron.sh" \
    "$TRADE/analysis_template.py:$MIRROR/crypto-analysis-workflow/scripts/analysis_template.py" \
    "$TRADE/_social_publish.py:$MIRROR/social-posting-workflow/scripts/_social_publish.py" \
    # ... 添加其他需要对比的文件
do
    local="${pair%%:*}"
    remote="${pair##*:}"
    if ! diff -q "$local" "$remote" > /dev/null 2>&1; then
        echo "❌ $(basename $local) 不一致"
        mismatches=$((mismatches+1))
    fi
done
echo "总不一致: $mismatches"
```

## auto_push 覆盖范围

`auto_push_github.sh` 自动同步的文件：

| 本地路径 | → | Mirror 路径 |
|----------|--|-------------|
| `~/.hermes/scripts/*.sh` | → | `cron/*.sh` |
| `trade_review/monitor_and_sync.py` 等 5 个 | → | `crypto-analysis-workflow/scripts/` |
| `trade_review/publish_social.py` 等 5 个 | → | `social-posting-workflow/scripts/` |
| `trade_review/scripts/review_last_post.py` | → | `social-posting-workflow/scripts/` |

**不在覆盖范围内**的需要手动同步：
- Skill SKILL.md 文件
- Skill references 目录
- 其他非脚本文件
