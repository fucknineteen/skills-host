# analyses.json 分析记录丢失 → 12h 复盘无教训 Bug

> 2026-06-20 发现：BTC 06-17 08:17 分析在 12h 复盘时 analysis 为 None，导致 extract_lessons() 返回空。

## 影响范围

- `process_reviews.py` 的 `do_12h_review()` → `extract_lessons()` 
- 还影响：6h 的 Spring 检测、12h 的 wyckoff 打分、72h 的 near_bottom 验证

## 复现路径

1. `analysis_template.py` 在 06-17 08:17 生成 BTC 分析 → 写入 `analyses.json`
2. `process_reviews.py` Step 0 同步到 `reviews.json`（此时 analysis 存在）
3. 在 12h 复盘触发前（~20:17），`publish_social.py` 或新一轮 `analysis_template.py` 运行
4. `analyses.json` 中 08:17 的 BTC 记录被覆盖/删除
5. 12h 复盘触发时 `find_analysis()` 找不到匹配 → 返回 None
6. `extract_lessons(analysis=None)` → `if analysis is None: return []`

## 实际案例

```
复盘 #27 — BTC 06-17 08:17 分析 | 入场价 65,648.7
├─ 6h: 横盘震荡 (正确)
├─ 12h: +0/3 (道氏:0/威科夫:0/价位:0)
│   └─ lessons: []  ← 应为 3 条（方向未确认 + 信号未确认 + 价位未触及）
└─ 72h: +1/4 (3D bearish 正确)
    └─ new_lessons: []  ← 方向正确，near_bottom 未触发
```

当前 `analyses.json` 中仅存 BTC 06-17 20:55 记录（entry=64777），08:17 记录已消失。

## 根因

`analyses.json` 是共享文件，被两个脚本以不同策略写入：
- `analysis_template.py` → 追加/覆盖同币种记录（flat_old 格式）
- `publish_social.py` → 写入新记录 + FG/REVIEW 标记（full_obj 格式）

当同币种在同一天有多次分析时，后来的写入会覆盖先前的。`reviews.json` 在 Step 0 同步时拿到了 analysis 引用，但 12h 后再查 `find_analysis()` 时数据已不在了。

## 修复方案

**方案 A（推荐）：Step 0 同步时嵌入 analysis 快照**

在 `process_reviews.py` Step 0 创建 review 记录时，把关键分析字段作为快照存入 review 自身：

```python
entry = {
    'coin': coin,
    'timestamp': ts,
    'entry_price': entry_price,
    'review_6h': '待复盘',
    'review_12h': '待复盘',
    'review_72h': '待复盘',
    'completed': False,
    # 分析快照（复盘时直接用，不再查 analyses.json）
    '_analysis': {
        'support': a.get('support', []),
        'resistance': a.get('resistance', []),
        'rsi_14': a.get('rsi_14', 0),
        'near_bottom': a.get('near_bottom', False),
        'sentiment': a.get('sentiment', {}),
        'macro': a.get('macro', {}),
        'levels_4h': a.get('levels_4h', {}),
    }
}
```

复盘时优先用 `review['_analysis']`，fallback 到 `find_analysis()`。

**方案 B：analyses.json 改为追加模式（不推荐）**

同币种同一天保留多条记录，`find_analysis()` 取最近一条。但这会增加文件体积，且复盘需要的是「分析发出时」的上下文，取最近一条可能对不上。

## 状态

- ✅ **已修复 (2026-06-20)** — `analyses.json` 与 `social_analyses.json` **分离**：
  - `analysis_template.py` → `analyses.json`（flat_old，纯技术分析）
  - `publish_social.py` → `social_analyses.json`（full_obj，社交发动态数据）
  - `process_reviews.py` 读取时合并两个文件，按 (coin, date) 去重，social 优先
  - `_social_publish.py` 的 `analyze_single_coin()` 已补全威科夫/VP/形态/日历模块（从 `analysis_template` 导入 `session_vp`/`wyckoff_detect`/`detect_kline_patterns`/`get_jin10_key_events`）
  - `publish_social.py` 已移除对 `analysis_template.py` 的子进程调用，消除双重分析冗余
- 影响：所有币种，特别是在分析频繁的交易日 — 已根除
