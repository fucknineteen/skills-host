# 方向判定：K线数据 vs 文本关键词

> 2026-06-19 重构：三层复盘引擎方向判定从文本关键词匹配改为K线客观数据。

## 问题

旧版 `process_reviews.py` 使用 `detect_direction(trend_string)` 对 `analyses.json` 中的 `trend_1h/trend_4h/trend_3d` 文本做关键词匹配：

```python
# ❌ 旧版
has_bear = any(w in trend_lower for w in BEARISH_WORDS)  # ['bearish', '空头', '看空', '下跌', 'oversold', ...]
if trend_lower.startswith('bearish_'):
    return 'bearish'
```

**缺陷**：
1. **语义歧义**：`'bearish_recovering'` 包含 `bearish` 被判为看空，但 `recovering` 实际是反弹
2. **过度匹配**：`'bearish_oversold'` 被判为看空，但 oversold 本身就是看反弹的信号
3. **数据缺失**：`trend_1h='?'` 时无法判定
4. **analyses.json 缺少结构化字段**：`record` 字典只写文本描述，没有 `scores.direction`、`near_bottom` 等

## 解决方案

### 1. `detect_direction_from_klines(candles, entry_price)` — 6h/12h 使用

基于窗口内最高/最低价判定：
- `window_high > entry × 1.02` 且无向下突破 → bullish
- `window_low < entry × 0.98` 且无向上突破 → bearish
- 双向波动 → 看收盘价相对入场价位置
- ±2% 以内 → flat

### 2. 72h 复盘同样使用 `detect_direction_from_klines()` — 统一1H数据源

> 2026-06-19 追加：原设计72h使用 `detect_direction_from_4h()` 从4H收盘序列判定，后改为与6h/12h一致的1H K线判定。

72h复盘不再查询4H表，而是：
- 从77h窗口拉取1H K线（limit=80）
- 用 `detect_direction_from_klines(candles_1h, entry_price)` 判定方向
- 77h窗口按1H K线切分为3段（每段~25h），计算day1/day2/day3收盘价

### 3. 威科夫SOS客观检测

```python
last_vol = candles[-1][5]
prev_vols = [c[5] for c in candles[-4:-1]]
avg_vol = sum(prev_vols) / len(prev_vols)
if last_vol > avg_vol * 1.5 and close > open:
    prev_high = max(c[2] for c in candles[-4:-1])
    if close > prev_high:
        # SOS confirmed
```

## 遗留

- `detect_direction()` 保留为 deprecated（向后兼容），不再被任何复盘函数调用
- `_build_trend_string()` 已删除
- `detect_direction_from_4h()` 已删除 — 72h复盘已统一使用1H K线判定
- 未来可在 `analysis_template.py` 中将 `near_bottom` 等写入 `analyses.json` 结构化字段
