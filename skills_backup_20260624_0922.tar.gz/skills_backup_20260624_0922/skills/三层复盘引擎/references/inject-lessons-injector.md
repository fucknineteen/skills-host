# 教训上下文注入器 — inject_lessons.py

> 来源: trade-review-workflow skill, 2026-06-20 创建
> 位置: /root/.hermes/trade_review/inject_lessons.py (生产)
> 副本: /root/.hermes/scripts/inject_lessons.py (cron 可执行)
> Cron: :05 每小时, no_agent, deliver=local

## 作用

轻量闭环的核心 — 将复盘教训反馈到下次分析的上下文。

## 数据流

```
lessons.json (复盘直接写入, 可能为空)
    +
regimes/{regime}_lessons.json (按行情类型归档, 109条在牛市回调)
    ↓
inject_lessons.py 汇总
    ↓
.lesson_context.txt (14天内教训 + 历史统计)
    ↓
crypto-analysis-workflow §3.6 强制加载
```

## 输出格式

```
## 📚 近期教训（14天内）
以下教训来自复盘引擎，分析时请注意避免同类错误：

- [BTC] 方向误判 [牛市回调]: RSI<20+FG<15环境做空是系统性错误...
- [ETH] 信号未确认 [牛市回调]: 威科夫信号在12h窗口内未得到确认...

📊 历史教训统计（>14天）：方向误判×3, 事件遗漏×1, ...
```

## 设计决策

- **按行情分文件**: 不同行情规律互斥，混存丢失上下文
- **14天窗口**: 近期教训逐条展示，历史教训只统计分布
- **只输出不修改**: 不写入任何数据文件，纯读取+格式化
- **空教训时静默**: 无教训时写入占位文件，不阻塞分析流程
