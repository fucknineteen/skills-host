# Cron Jobs 参考

所有定时任务脚本。由 Hermes Agent cronjob 引擎管理。

## 活跃任务

| 任务 | 脚本 | 频率 | 说明 |
|------|------|------|------|
| 🔄 K线同步 | `sync_klines_cron.sh` | 每小时 :00 | OKX API 增量同步全周期K线 |
| 📊 三层复盘 | `cron_review_process.sh` | 每小时 :03 | 对 analyses.json 执行 6h/12h/72h 复盘 |
| 📈 宏观检测 | `regime_update.sh` | 每小时 :02 | 更新 regime_cache |
| 📅 金十日历 | `refresh_jin10_cache.sh` | 每6小时 | 刷新财经日历缓存 |
| 🛡 金十守护 | `guard_jin10_token.sh` | 每10分钟 | MCP token 有效性监控 |
| 🔁 GitHub同步 | `auto_push_github.sh` | 每5分钟 | 文件变更自动推送到 fucknineteen/skills-host |

## 与三层复盘的关系

`cron_review_process.sh` 是 `process_reviews.py` 的 cron 包装器，每小时 :03 触发一次。运行逻辑：
1. 读 `reviews.json`，对新记录创建 `"待复盘"` 占位
2. 计算 elapsed 小时，满足 6h/12h/72h 阈值则执行对应层级复盘
3. stdout 有输出时交付用户（无待复盘则静默）

## 脚本位置

- 生产环境：`/root/.hermes/scripts/`
- GitHub 备份：[skills-host/cron/](https://github.com/fucknineteen/skills-host/tree/master/cron)

## GitHub 自动同步机制

`auto_push_github.sh`（cron `*/5 * * * *`）维护本地镜像 `/root/.hermes/skills-host-mirror/`，将本地脚本映射推送到 GitHub：

| 本地路径 | GitHub 路径 |
|----------|------------|
| `~/.hermes/scripts/*.sh` | `cron/*.sh` |
| `~/.hermes/trade_review/monitor_and_sync.py`, `process_reviews.py` 等 | `crypto-analysis-workflow/scripts/*.py` |
| `~/.hermes/trade_review/publish_social.py`, `verify_social_post.py` 等 | `social-posting-workflow/scripts/*.py` |

工作流：`git pull --ff-only` → cp 映射文件 → `git diff` 检测变更 → `git commit && push`。无变更时静默（stdout 为空，cron no_agent 不交付）。
