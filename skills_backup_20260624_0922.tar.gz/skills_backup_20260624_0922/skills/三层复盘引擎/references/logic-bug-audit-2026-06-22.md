# process_reviews.py 全量逻辑 Bug 审计 (2026-06-22)

> 审计范围：1031 行全部代码 + _shared.py
> 聚焦：双格式数据提取、时区正确性、教训提取与保存、复盘状态机、缺失字段边界

---

## 致命 Bug（需立即修复）

### 🔴 Bug: social_analyses.json 实际数据中缺少 near_bottom 字段
**位置**: L569-573, L677-681, L380-381
**现象**: 全文搜索 social_analyses.json 结果为 0。数据格式兼容矩阵声称 full_obj 有 near_bottom，但实际写入未包含此字段。
**影响**: full_obj 来源的所有复盘丢失 near_bottom 相关教训和 72h 严重失败检测。
**修复方向**: 检查 publish_social.py 写入逻辑，确认 near_bottom 是否正确写入 social_analyses.json。

### 🔴 Bug: save_lessons_regime_aware regime=None 时静默丢失教训
**位置**: L55-83 + L86-102
**触发链**: get_current_regime() 返回 None → L56 `if regime:` False → 跳过追加到 regime 文件 → L86-102 从已有 regime 文件重建 lessons.json → 本次教训不在任何 regime 文件中 → 下次运行时被覆盖丢失。
**影响**: 数据丢失。
**修复**: regime=None 时仍将教训写入 lessons.json（不依赖 regime 文件重建），或创建一个 `_unknown_lessons.json` 兜底。

### 🔴 Bug: 3根K线时 SOS 检测 max([]) 崩溃
**位置**: L395-404
**触发**: `len(candles_1h) == 3` 时，`candles_1h[-4:-1]` 为空列表，`max([])` 抛出 ValueError。
**修复**: 长度检查改为 `>= 4` 或增加 `if prev_vols` 守卫。

---

## 高优先级 Bug

### 🟡 Bug: find_analysis 合并后可能返回错误格式分析
**位置**: L226-241 + L786-790
**现象**: `find_analysis` 仅按 coin 过滤+时间差排序，合并池中 flat_old 和 full_obj 并存时可能返回格式不匹配的记录。
**影响**: macro 事件检测、Spring、support/resistance 全部失效。

### 🟡 Bug: do_12h_review 用 lessons_warnings 充当 key_events
**位置**: L456-463
**现象**: full_obj 无 `macro.key_events` 时降级为 `lessons_warnings`，但后者是教训警告文本，不含日历事件关键词。
**影响**: full_obj 事件检测几乎完全失效。

### 🟡 Bug: 72h 缺少多头误判方向的教训
**位置**: L700-711
**现象**: `trend_3d_score == -1` 只检查 `orig_3d_dir == 'bearish' and net_pct > 3`，漏掉 `orig_3d_dir == 'bullish' and net_pct < -3`。
**影响**: 多头误判的 72h 深度教训丢失。

---

## 中等优先级 Bug

### 🟡 Bug: 6h 事件标注只保留最后一条匹配
**位置**: L299-304 —— 循环中 event_note 每次被覆盖而非追加。
**修复**: 改为 `event_note += f" [数据事件: {ev_str}]"`。

### 🟡 Bug: near_bottom 赋值给 spring 变量后文案写"Spring确认有效"
**位置**: L380-385 —— `spring = analysis.get('near_bottom', False)` 但 detail 文本写 Spring。
**修复**: 区分两个变量，detail 文本按实际信号来源写。

### 🟡 Bug: 去重排序 key 中 str(None) 误计为"已完成"
**位置**: L816-820 —— `'待复盘' not in str(None)` → True，字段缺失被当作已复盘。
**修复**: `str(r.get(k, '待复盘'))`。

### 🟡 Bug: verdict_map 缺少 (flat, up) 和 (flat, down) 组合
**位置**: L273-279 —— flat 方向+市场实际移动≥2% 落入 default '横盘震荡'，不记错误。
**修复**: 补加 `('flat', 'up'): ('需关注', ...)` 和 `('flat', 'down'): ('需关注', ...)`。

### 🟡 Bug: extract_lessons levels_score=0 不区分"无价位数据"与"价位未触及"
**位置**: L559-565 —— 两种不同的根本原因生成同一条教训。
**修复**: 根据 supports/resistances 是否为空分支。

### 🟡 Bug: find_analysis 不可解析时间戳的记录排到最前
**位置**: L238-240 —— `parse_timestamp(...) or review_dt` 使损坏记录时间差为 0。
**修复**: 过滤不可解析的记录，或给一个很大的时间差。

### 🟡 Bug: regime 文件初始化被静默跳过
**位置**: L42-52 —— 异常捕获 `except Exception: pass` + 仅在 modified=True 时调用。
**修复**: 解耦初始化逻辑，首次运行无条件执行。

---

## 低优先级 Bug

### 🟢 Bug: 归档截断用 datetime.now() 而非 OKX 时间
**位置**: L991 —— 应用 `now_utc` 保持一致。

### 🟢 Bug: parse_timestamp 硬编码 timedelta(hours=8)
**位置**: L141 —— 应统一用 BJT 常量。

### 🟢 Bug: extract_lessons 中 RSI=0/FG=0 falsy 跳过检测
**位置**: L524 —— `if rsi` 在值为 0 时为 False。

### 🟢 Bug: dedup_lessons 仅按 lesson 文本去重
**位置**: L747-754 —— 同文本不同 category 的教训被去重（低触发概率）。

### 🟢 Bug: classify_price_path 中 first_close 取开盘价
**位置**: _shared.py L48 —— 变量名 misleading，存储值错误。

### 🟢 Bug: detect_direction 死代码中空头优先 bias
**位置**: L194-199 —— 已废弃但仍在代码中。

### 🟢 Bug: walrus operator 需 Python 3.8+
**位置**: L787 —— Ubuntu 18.04 默认 Python 3.6 无法运行。

### 🟢 Bug: total>=2 跳过维度级教训
**位置**: L514-516 —— 总分掩盖个别维度不足。

---

## 已确认无 Bug 的设计

- ✅ `review.update(result)` 后 12h 不设 `completed`（72h 才设）—— 正确
- ✅ `lessons` 累积 + `dedup_lessons` 内联去重 —— 正确
- ✅ `get_okx_server_time()` 用于所有复盘时间判断 —— 正确
- ✅ `BJT` 时区转换一致 —— 正确
- ✅ `SKIP_COINS = {'FG', 'REVIEW'}` 过滤 —— 正确
- ✅ `review_6h == '待复盘'` 哨兵值检查 —— 正确
