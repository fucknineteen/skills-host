# Data File Schemas

## social_posts.json

Array of post records:
```json
{
  "id": 12,
  "time": "2026-06-16 04:14 BJ",
  "btc_price": 65723,
  "eth_price": 1725,
  "btc_direction": "做多 回踩65000-65300入场 SL 64500 TP 67250/69500 RR 1:3.3",
  "eth_direction": "做多 回踩1780-1810入场 SL 1760 TP 1850/1900 RR 1:1.8",
  "fg": 20,
  "regime": "牛市回调",
  "text": "社交动态文案..."
}
```

Fields: `id`(auto-increment), `time`(BJ), `btc_price`, `eth_price`, `btc_direction`, `eth_direction`, `fg`, `regime`, `text`
Backup: `.bak` → `.bak5`

## analyses.json

Array of analysis records:
```json
{
  "timestamp": "2026-06-03T12:38:17.432212",
  "coin": "BTCUSDT",
  "coin_type": "large",
  "trigger": "manual",
  "entry_price": 66375,
  "trend_1h": "bearish_recovering",
  "trend_1h_detail": "新低65398后反弹至66375...",
  "trend_4h": "bearish_oversold",
  "trend_4h_detail": "...",
  "trend_3d": "bearish",
  "trend_3d_detail": "...",
  "support": [...],
  "resistance": [...],
  "recommendation": "...",
  "risk": "...",
  "macro": {...},
  "scores": {...}
}
```

Fields: `timestamp`, `coin`, `coin_type`, `trigger`, `entry_price`, `trend_*` + `_detail`, `support`, `resistance`, `recommendation`, `risk`, `macro`, `scores`

## social_reviews.json

Array of review records:
```json
{
  "post_id": 1,
  "post": { /* full social_posts.json entry */ },
  "btc_verdict": "🟡 横盘",
  "btc_change_pct": 0.94,
  "btc_high": 66976.4,
  "btc_low": 65612.9,
  "eth_verdict": "✅ 正确",
  "eth_change_pct": 4.96,
  "eth_high": 1822.1,
  "eth_low": 1785.0,
  "reviewed_at": "2026-06-17T...",
  "time": "2026-06-16 04:14 BJ"
}
```

Fields: `post_id`, `post`(full object), `btc_verdict`, `btc_change_pct`, `btc_high`, `btc_low`, `eth_verdict`, `eth_change_pct`, `eth_high`, `eth_low`, `reviewed_at`, `time`

## okx_klines.db — klines table

| Column | Type | Description |
|--------|------|-------------|
| coin | TEXT | BTC/ETH/SOL/DOGE/LAB |
| timeframe | TEXT | 5m/15m/30m/1H/4H/1D/1W |
| ts | INTEGER | Unix timestamp (milliseconds) |
| open | REAL | Open price |
| high | REAL | High price |
| low | REAL | Low price |
| close | REAL | Close price |
| volume | REAL | Trade volume |
| vol_ccy | REAL | Quote currency volume |
| updated_at | TEXT | Sync timestamp |

## okx_klines.db — sync_log table

| Column | Type | Description |
|--------|------|-------------|
| coin | TEXT | Coin symbol |
| timeframe | TEXT | Timeframe |
| last_ts | INTEGER | Last synced timestamp (ms) |
| count | INTEGER | Number of candles synced |
| synced_at | TEXT | Sync completion timestamp |

## okx_live_config.json

```json
{
  "apiKey": "...",
  "secretKey": "...",
  "passphrase": "...",
  "base_url": "https://www.okx.com",
  "proxy": "",
  "demo": false
}
```

## _shared.py

```python
from datetime import timezone, timedelta
BJT = timezone(timedelta(hours=8), 'Asia/Shanghai')
TRADE_DIR = '/root/.hermes/trade_review'
DB_PATH = f'{TRADE_DIR}/okx_klines.db'
```
