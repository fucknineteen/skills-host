# 工作流架构审计 (2026-06-19)

## 文件规模

| 文件 | 行数 | 大小 |
|------|------|------|
| analysis_template.py | 2007 | 84 KB |
| regime_detector.py | 2321 | 90 KB |
| process_reviews.py | 915 | 37 KB |
| _social_publish.py | 607 | 25 KB |
| monitor_and_sync.py | 523 | 20 KB |
| scripts/analysis_altcoin.py | 483 | 20 KB |
| scripts/gen_charts.py | 366 | 20 KB |
| place_live_orders.py | 380 | 13 KB |
| scripts/scan_daytrade_coins.py | 330 | 11 KB |
| verify_social_post.py | 222 | 7 KB |
| publish_social.py | 254 | 9 KB |
| jin10_fallback.py | 279 | 10 KB |
| massive_client.py | 284 | 8 KB |
| scripts/review_last_post.py | 279 | 10 KB |
| scripts/verify_workflow.py | 420 | 16 KB |

总文件数: 75 | 总大小: 8.9 MB

## 重复函数审计

`_social_publish.py` 与 `analysis_template.py` 重叠函数（23/25）:
- `_retry`, `fetch_fear_greed`, `fetch_okx_ticker`, `fetch_okx_funding`
- `get_regime_result`, `is_closed`, `_fmt_price`
- `calc_rsi`, `calc_macd`, `calc_adx`, `calc_bollinger`, `calc_obv`
- `candle_body_label`, `trend_direction`, `check_acceleration`
- `check_extreme_oversold`, `check_data_event_window`
- `get_rows`, `get_db_coins`, `build_data_freshness`
- `analyze_single_coin`, `extract_direction`, `generate_social_draft`

**注意**: `select_chart_style` 仅在 `_social_publish.py` 中（608行版本），`analysis_template.py` 中可能有不同实现。

## 备份膨胀

- `backup/20260618_222233/`: ~80MB (15+ files)
- `backup/20260618_222319/`: ~80MB (15+ files)
- 无自动清理机制，随时间持续增长

## 孤立文件

- `scripts/check_db_integrity.py`: 文件已删除，backup 中仍有副本
- `okx_klines.db.bak`: 7.3MB 数据库备份
- `social_reviews.json.bak`: 1.1KB 备份
- `strategy_bot.log.old`: 6.3MB
- `strategy_bot.log.old_bak`: 3.7MB

## 推荐修复顺序

1. **P0**: 从 `analysis_template.py` 删除已迁移到 `_social_publish.py` 的23个函数，标记 `--social` 为 deprecated
2. **P1**: 清理 `backup/` 目录，保留最近1个备份
3. **P1**: 删除 `okx_klines.db.bak` 和日志归档
4. ~~**P2**: 统一 `detect_direction` 实现~~ → **已完成 (2026-06-19)**
   - `process_reviews.py` 已改用 `detect_direction_from_klines()` 客观K线判定
   - `review_last_post.py` 已使用 ±2% 阈值客观判定
   - 三个复盘层级全部统一使用1H K线数据，不再依赖4H或文本关键词
   - `detect_direction()` 保留为 deprecated 向后兼容
   - `detect_direction_from_4h()` 已删除
   - `_build_trend_string()` 已删除
5. ~~**P2**: 价格路径分类~~ → **已完成 (2026-06-19)**
   - `classify_price_path()` 已内嵌至 `process_reviews.py`
   - 三层复盘输出均携带路径信息
   - 独立脚本 `price_path_report.py` + `review_path_enhancer.py` 可用
   - `review_last_post.py` 已自带 `path_type` 输出，社交动态复盘自动携带
