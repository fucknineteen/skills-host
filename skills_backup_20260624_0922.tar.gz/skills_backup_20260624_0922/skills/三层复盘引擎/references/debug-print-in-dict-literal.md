# Debug Print in Dict Literal Trap

## Problem
Debug `print()` statements accidentally placed inside dictionary literals cause SyntaxError:

```python
# WRONG — print() inside dict literal
record = {
    "field1": value1,
    print("DEBUG:", value1),  # SyntaxError!
    "field2": value2,
}
```

## Pattern
This happens when adding debug prints mid-refactor without checking placement scope.

## Fix
Remove debug prints from dict literals. Use stderr logging outside the dict construction block.
