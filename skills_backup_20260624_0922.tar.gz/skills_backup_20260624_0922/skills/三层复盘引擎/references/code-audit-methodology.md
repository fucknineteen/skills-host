# 代码审计方法论

## 审计流程
1. 全量读取目标文件，不跳行
2. 交叉引用：搜索同名函数/变量在多个文件中的出现
3. 统计重复：AST 解析提取函数签名，对比重叠
4. 检查死代码：未使用变量、import、函数
5. 检查大小：日志文件、备份目录、pycache 占用
6. 分组报告：Bug→冗余→清理，按严重度排列

## 常见冗余模式
- 工具函数重复：get_klines(), classify_price_path() 等在多个文件中各自实现
- 大文件复制：analysis_template.py (84KB) 与 _social_publish.py (25KB) 有 23 个同名函数
- 备份膨胀：backup/ 目录无自动清理，.bak 文件未轮转
- 日志堆积：strategy_bot.log.old (6MB), strategy_bot.log.old_bak (4MB)

## 修复原则
- 工具函数统一提取到 _shared.py 或独立 utils.py
- 大文件间的重复函数：确认 source of truth，另一个改为 import
- 备份目录：保留最新一个，其余清理