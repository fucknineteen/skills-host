# 社交动态发布管道拆分 (2026-06-18)

## 背景

`analysis_template.py` 是一个 1988 行的单体脚本，同时承担两个职责：
1. **技术分析**（主功能）— 拉K线、算指标、输出报告
2. **社交动态一键发布**（`--social` 标志触发）— 5步流水线

## 旧管道的问题

`analysis_template.py` 第 1936-1984 行的 `--social` 管道存在以下 bug：

| Bug | 位置 | 影响 |
|-----|------|------|
| 核验失败被吞 | `check=False` | 文案有错误数据仍入库 |
| 配图固定 Style 1 | 硬编码 `--style '1'` | 不分场景都出营销K线图 |
| 无用户审核 | 全自动 | 用户无法看到/编辑草稿 |
| 文案比模板 v5.1 简略 | `generate_social_draft()` | 缺少VP POC/VAH/VAL部分 |

## 拆分方案

### 新建文件
- `_social_publish.py` — 文案生成库（从 analysis_template.py 提取 ~400 行核心函数）
- `publish_social.py` — 7步流水线编排器（~200 行）

### 提取的函数
- `fetch_fear_greed()` — 恐惧贪婪指数
- `fetch_okx_ticker()` / `fetch_okx_funding()` — OKX 行情/费率
- `get_regime_result()` — 行情检测器
- `calc_rsi()` / `calc_macd()` / `calc_adx()` / `calc_bollinger()` — 指标计算
- `analyze_single_coin()` — 单币种完整分析
- `generate_social_draft()` — 文案生成
- `select_chart_style()` — 自动配图风格选择

### 修复
1. `verify_social_post.py` 失败时 `sys.exit(1)` 中断流程
2. `select_chart_style()` 根据分析结果自动选 Style 1-4
3. 新增用户审核步骤（Step 5.5）
