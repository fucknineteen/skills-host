# GitHub 自动推送：脚本变更同步

> 2026-06-20 建立。当本地脚本更新时，自动推送到 `fucknineteen/skills-host`。

## 架构

```
本地脚本文件                             GitHub (fucknineteen/skills-host)
─────────────                           ──────────────────────────────
~/.hermes/scripts/*.sh          →       cron/*.sh
~/.hermes/trade_review/*.py     →       crypto-analysis-workflow/scripts/*.py
                                       social-posting-workflow/scripts/*.py
~/.hermes/trade_review/scripts/ →       social-posting-workflow/scripts/
```

## 组件

| 组件 | 路径 | 作用 |
|------|------|------|
| 本地镜像 | `/root/.hermes/skills-host-mirror/` | GitHub 仓库的本地 clone（master 分支） |
| 同步脚本 | `/root/.hermes/scripts/auto_push_github.sh` | 复制文件到镜像 → git diff → commit + push |
| cron 任务 | `ed590dfe6c34` | 每 5 分钟运行一次（`*/5 * * * *`），`no_agent=true`，`deliver=local` |

## 同步脚本逻辑

```bash
# 1. git pull --ff-only（先拉取最新）
# 2. 逐个文件 cp 到镜像对应路径
# 3. git diff --quiet（无变更则静默退出）
# 4. git add -A && git commit && git push origin master
```

## 映射清单

### cron 脚本 → cron/
- sync_klines_cron.sh
- cron_review_process.sh
- regime_update.sh
- guard_jin10_token.sh
- refresh_jin10_cache.sh

### 分析脚本 → crypto-analysis-workflow/scripts/
- monitor_and_sync.py
- process_reviews.py
- analysis_template.py
- regime_detector.py
- _shared.py

### 社交脚本 → social-posting-workflow/scripts/
- publish_social.py
- verify_social_post.py
- gen_charts.py
- save_social_post.py
- _social_publish.py
- review_last_post.py（来源：trade_review/scripts/）

## SSH 认证

使用 `~/.ssh/id_ed25519`，已验证认证成功：
```
ssh -T git@github.com → Hi fucknineteen!
```

## 注意事项

- 目标分支是 `master`（非 `main`）
- `deliver=local` 意味着推送结果不发送给用户（静默）
- 无变更时 stdout 为空，完全静默
