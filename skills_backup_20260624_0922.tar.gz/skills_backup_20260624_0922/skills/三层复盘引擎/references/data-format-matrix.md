# analyses.json 格式兼容矩阵

> 2026-06-19 审计发现：analyses.json 中有两种不兼容格式并存，导致 process_reviews.py 复盘质量降级。

## 两种格式对比

| 字段 | flat_old (analysis_template.py) | full_obj (publish_social.py) |
|------|------|------|
| coin | `BTCUSDT` | `BTCUSDT` |
| entry_price | ✅ | ✅ (计算字段) |
| support[] | ✅ | ❌ → `levels_4h.lows[]` |
| resistance[] | ✅ | ❌ → `levels_4h.highs[]` |
| rsi_14 | ✅ | ❌ → `rsi_4h` |
| macro.key_events | ✅ | ❌ (无此字段) |
| sentiment.spring_confirmed | ✅ (部分) | ❌ (无此字段) |
| near_bottom | ❌ | ❌ (⚠️ 2026-06-22 审计: 实际数据中不存在此字段) |
| ticker.last | ❌ → `ticker_price` | ✅ |
| sl_val/tp_val/rr_str | ❌ | ✅ |
| funding | ❌ → `sentiment.funding_rate` | ✅ |
| indicators (全部TF) | ❌ | ✅ |
| resonance | ❌ → `recommendation` | ✅ |

## process_reviews.py 读取字段 vs 格式兼容性

| 读取代码 | 用到的层级 | flat_old | full_obj |
|------|------|:---:|:---:|
| `analysis.get('support', [])` | 6h/12h | ✅ | ❌ |
| `analysis.get('resistance', [])` | 12h | ✅ | ❌ |
| `analysis.get('macro', {}).get('key_events', [])` | 6h/12h/72h | ✅ | ❌ |
| `analysis.get('sentiment', {}).get('spring_confirmed', False)` | 6h/12h | ✅ | ❌ |
| `analysis.get('rsi_14', 0)` | 72h/extract_lessons | ✅ | ❌ |
| `analysis.get('near_bottom', False)` | 72h | ❌ | ❌ ⚠️ 2026-06-22 审计: social_analyses.json 实际不含此字段 |

### 降级影响

当 `publish_social.py` 当日写入后，process_reviews.py 的复盘结果：
- **6h**: Spring 检测失效（`spring_low=0`），事件标注缺失
- **12h**: 价位打分=0（无 support/resistance），威科夫打分=0（无 spring_confirmed），事件检测=空
- **72h**: ⚠️ 2026-06-22 审计: near_bottom 检测也失效（字段缺失），RSI 极端超卖检测失效（降级到 rsi_4h），事件豁免失效（无 macro 字段）

## 临时缓解

当前 `analysis_template.py` 也同步写入 `reviews.json`（L1903-1914），且写入格式为 flat_old。
只要 `analysis_template.py` 在 `publish_social.py` 之后运行，会覆盖 analyses.json 中的币种记录为 flat_old 格式（不覆盖 FG/REVIEW），复盘数据源恢复。

但这不是可靠保证——如果用户只跑 publish_social.py 不跑 analysis_template.py，当日复盘将降级。
