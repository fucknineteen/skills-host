# prefill_messages_file 自动加载 skill 机制

## 背景

Hermes Agent 没有内置的"新会话自动加载 skill"配置项。skills 的加载是靠 agent 在 turn 开始时扫描 available_skills 然后按需加载的。

## 解决方案

通过 `prefill_messages_file` 配置，在新会话启动时自动注入提示。

### 配置步骤

1. 创建提示文件（如 `~/.hermes/startup_skills.txt`）：
```
[SYSTEM] 请加载 skill: response-accuracy，确保分析结论与数据源一致。
```

2. 在 `~/.hermes/config.yaml` 中设置：
```yaml
prefill_messages_file: '~/.hermes/startup_skills.txt'
```

### 效果

每次新会话开始时，系统会自动注入该文件内容作为首条消息，提示 agent 加载指定 skill。

### 局限性

这只是一个**提示注入**，skill 仍需 agent 主动加载。配合 skill 内部的铁律约束才能有效防止凭记忆写结论的问题。

### 写法要点（2026-06-22 确认）

- **推荐写法：** `[SYSTEM] 请加载 skill: xxx` — 通用可靠，不依赖命令注册
- **不推荐写法：** `/bug-fix-protocol` — 只有该 skill 注册了对应 slash command 时才有效
- **多条加载：** 每行一个 `[SYSTEM] 请加载 skill: xxx`，或用 `以下 skills：` 列表格式
- 当前配置：`config.yaml` 第343行 `prefill_messages_file: ~/.hermes/startup_skills.txt`
- 当前文件内容见 `~/.hermes/startup_skills.txt`

### 常见误区（2026-06-22 确认）

- ❌ **写 `/command` 格式期望自动触发 skill** — `prefill_messages_file` 只是注入文本，模型收到 `/bug-fix-protocol` 后能否触发取决于该 skill 是否注册了此 slash command。大多数 skill 没有注册命令，所以写了也白写。
- ❌ **以为写入 skill 目录就能自动加载** — Hermes 不会自动加载 skill，必须通过提示让模型主动选择加载。`prefill_messages_file` 是最可靠的自动化方式。
- ✅ **正确做法：** 写 `[SYSTEM] 请加载 skill: xxx` 的自然语言提示，模型会主动加载指定 skill。

### 相关文件

- `~/.hermes/startup_skills.txt` — 预注入提示文件
- `~/.hermes/config.yaml` — prefill_messages_file 配置项
