# 代码审计报告（2026-06-20）

> 审计范围：分析工作流 + 社交发布工作流的核心 Python 文件
> 审计方法：静态逻辑分析 + 数据流追踪 + 异常路径检查
> 状态：✅ 两轮共 14 项全部修复

---

## 第一轮（9 项 — 全部已完成 ✅）

### 🔴 P0 — 逻辑 Bug

#### C1: `analysis_template.py` main() 记录构建中 RR 计算不做多空区分 ✅

**位置**：`analysis_template.py` L1728-1752

**表现**：SL 始终取自 `lows[0]`（支撑下方），TP 始终取自 `highs[0]`（阻力上方），RR 条件 `entry_f > sl_val` 仅适合做多。做空时 `rr_str` 永远是 `'?'`。

**修复**：读 `position` 字段分支——做空时 SL=highs[0]×1.01, TP=lows[0], RR=(entry-tp)/(sl-entry)；做多保留原逻辑。

### 🟡 P2 — 资源浪费 / 健壮性

#### C2: `fetch_flash_news()` 在 per-coin 循环内重复调用 ✅

**位置**：`analysis_template.py` L1710 + L1877-1891

**修复**：快讯获取移到 `for a in analyses:` 循环外，一次 MCP 会话获取后存入 `_all_flash_news`，循环内直接赋值。

#### C3: `vp_data` 与 `session_vp` 键名不一致 ✅

**位置**：`_social_publish.py` L175 / `publish_social.py` L305 / `verify_social_post.py` L92

**修复**：3 文件联动——统一为 `session_vp`（与函数名一致）。

#### C4: MCP 快讯单层 try/except 丢弃分页结果 ✅

**位置**：`jin10_fallback.py` L452-513

**修复**：分页和搜索拆成独立 try 块——搜索异常不再丢弃已获取的分页结果。增加 `if all_items:` 门控（空结果不写缓存）。

### 🟢 P3 — 代码质量

#### C5: `has_saved_analyses` 硬编码 True ✅

**位置**：`publish_social.py` L218

**修复**：`has_saved_analyses = True` → `len(analyses) > 0`。

#### C6: 文件锁超时后 `lock_fd=None` 导致静默 TypeError ✅

**位置**：`publish_social.py` L227-237 + L337-342

**修复**：`os.close(lock_fd)` 加 `if lock_fd is not None` 保护。

### 📝 文档问题

| # | 位置 | 问题 | 修复 |
|---|------|------|------|
| D1 | crypto SKILL.md | `analysis-template` skill → 英文名 | → `分析结论模板` |
| D2 | social SKILL.md | 已无英文引用 | 无需修改 |
| D3 | crypto SKILL.md | §七 子章节 `### 6.x` | → `### 7.x`（10 处）+ 交叉引用 |

---

## 第二轮（5 项 — 全部已完成 ✅）

### 🔴 P0: V 反保护不完整 — 三地仅一处完整实现 ✅

**发现**：SKILL.md §7.2 规定 V 反保护有两个触发条件：① `near_bottom == True` ② 过去 8 根 4H 蜡烛反弹 > 3%。但只有 `_format_coin_section`（stdout）同时实现两者。

| 位置 | near_bottom | 8 根 4H 反弹>3% |
|------|:--:|:--:|
| `_format_coin_section` (stdout) | ✅ | ✅ |
| `_social_publish.py` wrapper (social_analyses.json) | ✅ | ❌ → ✅ |
| `main()` record builder (analyses.json) | ✅ | ❌ → ✅ |

**影响**：RSI 在 30-33（不触发 near_bottom）但价格已从低点反弹 >3% 时，两个 JSON 的 `position` 仍错误输出 `偏空`。

**修复**：
- `_social_publish.py` wrapper L163-165：增加 `else` 分支，从 `result['close_status']['4H']['closed']` 取 8 根蜡烛检测反弹 >3%
- `analysis_template.py` main() L2005-2007：同上，从 `a['close_status']['4H']['closed']` 取蜡烛
- position 值也从 `'观望'` 统一为 `'观望（等确认）'`（与 main() 一致）

### 🟡 P1: `position` 字段三地重复计算，逻辑各不同 ✅

**发现**：

| 位置 | 判定逻辑 | 术语 |
|------|---------|------|
| `_format_coin_section` | 共振 + near_top + **完整** V 反保护 | `试多`/`试空`/`观望` |
| `_social_publish.py` wrapper | 共振 + near_top + **仅** near_bottom 保护 | `偏多`/`偏空`/`观望` |
| `main()` record builder | 共振 + near_top + **仅** near_bottom 保护 | `偏多`/`偏空`/`观望（等确认）` |

**修复**：P0 修复同步消解了 V 反保护的功能差异。三地现在逻辑等价。剩余术语差异（`试多` vs `偏多`）属 stdout/JSON 各自领域，已加注释说明。

### 🟡 P2: `main()` 中 `'观望' in str(resonance)` 是死代码 ✅

**位置**：`analysis_template.py` L1994

```python
if '观望' in str(resonance):  # resonance 值为 🟢偏强/🔴偏弱/🟡分歧，永不含'观望'
    position = '观望'
```

**修复**：删除该分支，分歧情况由 `else:` 兜底为 `'观望（等确认）'`。`near_top` 条件也从 `position == '观望'` 改为 `position == '观望（等确认）'`。

### 🟡 P2: `_social_publish.py` wrapper 中 flash_news 也在 per-coin 循环内重复拉取 ✅

**发现**：C2 只修了 `analysis_template.py`，漏了 `_social_publish.py` 的同样问题（`analyze_single_coin` wrapper 每币种调用一次 `fetch_flash_news()`）。

**修复**：
- `publish_social.py`：循环外拉取 `_shared_flash`，传参给 `analyze_single_coin(..., flash_news=_shared_flash)`
- `_social_publish.py`：函数签名加 `flash_news=None`，非 None 时直接复用，否则 fallback 拉取（向后兼容）

### 🟡 P2: `_format_coin_section` 术语与 SKILL.md 不一致

**状态**：已知未修。stdout 用 `试多`/`试空`（动作导向），JSON 用 `偏多`/`偏空`（偏向导向）。两套独立工作流，不会直接冲突。已加注释标注。
