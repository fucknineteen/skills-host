# OKX 实盘账户查询工作流

> 2026-06-21 新增 — 查询实盘账户余额/持仓/挂单的标准方法
> 2026-06-22 更新：补充 curl 直查模式和时间戳格式陷阱

## 原则

**首选**：复用 `place_live_orders.py` 的 `api_call()`，签名逻辑已充分测试。
**备选**：需要查询 `--view` 之外的数据（如实时持仓详情）时，用 curl + base64 签名直查。

## 方法一：通过 place_live_orders.py 内置命令

```bash
cd /root/.hermes/trade_review
python3 place_live_orders.py --view              # 查看挂单
python3 place_live_orders.py --view --instId BTC-USDT-SWAP  # 按品种过滤
```

## 方法二：通过 api_call() 函数

```python
import sys
sys.path.insert(0, '/root/.hermes/trade_review')
from place_live_orders import api_call

# 账户余额
bal = api_call('GET', '/api/v5/account/balance')

# 持仓（SWAP 永续合约）
pos = api_call('GET', '/api/v5/account/positions?instType=SWAP')

# 挂单
orders = api_call('GET', '/api/v5/trade/orders-pending?instType=SWAP')
```

## 方法三：curl 直查（自建签名）

当 `api_call()` 不适用或需要调试时，用 curl + HMAC 签名：

```python
import json, subprocess, hmac, hashlib, base64
from datetime import datetime, timezone

config = json.load(open('/root/.hermes/trade_review/okx_live_config.json'))
api_key = config['apiKey']
secret_key = config['secretKey']
passphrase = config['passphrase']

# 1. 先获取 OKX 服务器时间（关键！本地时间签名会 50112 报错）
r = subprocess.run([
    'curl', '-4', '-s', '--max-time', '5',
    'https://www.okx.com/api/v5/public/time'
], capture_output=True, text=True, timeout=6)
server_ts_ms = json.loads(r.stdout)['data'][0]['ts']
dt = datetime.fromtimestamp(int(server_ts_ms) / 1000, tz=timezone.utc)
ts_iso = dt.strftime('%Y-%m-%dT%H:%M:%S.') + f'{int(server_ts_ms) % 1000:03d}Z'

# 2. 构造签名
path = '/api/v5/account/positions'
method = 'GET'
body_str = ''
msg = ts_iso + method + path + body_str
sig = base64.b64encode(
    hmac.new(secret_key.encode(), msg.encode(), hashlib.sha256).digest()
).decode()

# 3. 发起请求
cmd = ['curl', '-4', '-s', '--max-time', '10',
       '-X', method,
       '-H', f'OK-ACCESS-KEY: {api_key}',
       '-H', f'OK-ACCESS-SIGN: {sig}',
       '-H', f'OK-ACCESS-TIMESTAMP: {ts_iso}',
       '-H', f'OK-ACCESS-PASSPHRASE: {passphrase}',
       '-H', 'Content-Type: application/json']
cmd.append('https://www.okx.com' + path)
r2 = subprocess.run(cmd, capture_output=True, text=True, timeout=12)
result = json.loads(r2.stdout)
```

## 输出字段说明

### 余额
- `totalEq`：总权益（USDT）
- `availEq`：可用余额
- `details[].eq`：各币种余额
- `details[].availBal`：可用余额
- `details[].cashBal`：现金余额
- `details[].upl`：未实现盈亏
- `details[].imr`：初始保证金要求
- `details[].mmr`：维持保证金要求
- `details[].notionalLever`：名义杠杆

### 持仓
- `instId`：合约代码（如 BTC-USDT-SWAP）
- `posSide`：方向（long/short）
- `pos`：持仓数量
- `avgPx`：均价
- `lever`：杠杆
- `upl`：浮盈
- `uplRatio`：浮盈比例
- `liqPx`：强平价
- `marginMode`：保证金模式

### 挂单
- `ordType`：订单类型
- `side`：买卖方向
- `px`：价格
- `sz`：数量
- `tdMode`：交易模式

## ⚠️ 陷阱

### 陷阱 1：不要用本地时间签名（50112 报错）

用 `time.gmtime()` 生成的本地时间戳签名，OKX 返回 `Invalid OK-ACCESS-TIMESTAMP`。

**正确做法**：先调用 `/api/v5/public/time` 获取服务器时间，再格式化签名。

### 陷阱 2：时间戳格式必须精确

OKX 要求 `YYYY-MM-DDTHH:MM:SS.mmmZ`（毫秒精度 + Z 后缀）。

错误格式示例：
- `2026-06-21T21:54:49`（缺毫秒和 Z）→ 50112
- `2026-06-21T21:54:49.460`（缺 Z）→ 签名不匹配
- `1782078943.958Z`（Unix 时间戳格式）→ 50112

正确格式：`2026-06-21T21:54:49.460Z`

### 陷阱 3：不要自己写 HMAC 签名（除非必要）

独立编写签名脚本（urllib + hmac/sha256/base64）查询 OKX API 容易出错。OKX 签名要求时间戳格式、请求路径拼接等细节非常严格。

**首选**：始终通过 `place_live_orders.py` 的 `api_call()` 复用。

### 陷阱 4：base64 编码签名

OKX v5 API 要求 HMAC-SHA256 签名后进行 base64 编码，不是 hex 编码。

```python
# ✅ 正确
sig = base64.b64encode(hmac.new(key, msg, hashlib.sha256).digest()).decode()

# ❌ 错误 — hex 编码不被 OKX 接受
sig = hmac.new(key, msg, hashlib.sha256).hexdigest()
```

## 配置文件

- API 密钥：`/root/.hermes/trade_review/okx_live_config.json`
- 脚本位置：`/root/.hermes/trade_review/place_live_orders.py`
