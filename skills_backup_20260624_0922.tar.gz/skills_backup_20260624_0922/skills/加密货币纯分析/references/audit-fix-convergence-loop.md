# 审计修复循环收敛方法论

> 来源：2026-06-22 7 轮全量审计（~79 Bug 全部修复）
> 核心脚本：analysis_template.py (2199行), _social_publish.py, publish_social.py, process_reviews.py 等 13 文件

## 收敛过程

| 轮次 | 级别 | 发现 | 修复 | 关键发现 |
|:--:|:--:|:--:|:--:|------|
| R1 | 🔴 | 27 | 18 | API泄露、核验器失效、ticker/ticker_full字段不匹配、事件路径断裂、5个崩溃点 |
| R2 | 🟠 | 3 | 3 | extract_direction覆盖强共振、VP键名大小写、宏观数据源缺失 |
| R3 | 🟡 | 27 | 27 | Phase替换、快讯关键词不全、SL/TP数据源不一致、coin字段BTC/BTCUSDT、死代码 |
| R4 | 🟢 | 14 | 14 | BJT统一、边界守卫、文档过时 |
| R5 | 🔴 | 5 | 5 | **`.get()` None陷阱**、kline_patterns类型错误、pipeline无异常保护 |
| R6 | 🟡 | 9 | 9 | bid/ask键名错、ADX初始化、UTAD无成交量、LPS缺趋势、布尔判断 |
| R7 | — | 0 | 0 | 终止：零残留 |

## 核心教训

### 1. `.get(key, default)` 对 None 值无效 — 第5轮才发现

这是本会话最隐蔽的 Bug：`.get('atr', cp*0.02)` 在 key 存在但值为 None 时返回 None（不是默认值）。这种模式在 `analysis_template.py` 中至少出现 5 次，只有 1 处被第 1 轮捕获。其他 4 处直到第 5 轮才被发现。

**审计检查清单**：任何 `.get(key, default)` 调用都必须追问「上游是否显式写 None？」

### 2. 修复引入回归 — extract_direction 案例

R2 修复 `extract_direction` 时，将条件从 `macd_h < -50` 改为 `('强' not in resonance and macd_h < -50)`，**但误删了末尾的 `and not near_bottom and not v_reversal` 守卫**。直到 R2 验证环节才补回。

**规则**：修改逻辑条件时，逐段对比修改前后的守卫链，确认没有遗漏。

### 3. 审计文档过时陷阱 — 5/6 "待修复"已修复

`code-audit-2026-06-22-unsolved.md` 中标注 6 项「待修复」，实际有 5 项已在代码中修复。依赖过时审计文档的代价是：第 3 轮花费大量精力「验证」不存在的 Bug。

**规则**：修复前必须 `grep` 代码确认 Bug 是否仍然存在，不可盲信审计文档。

### 4. 死函数检测 — _pos_quick 从未被调用

`_pos_quick` (42行) 是位置判定的第 4 份副本，全项目无任何 `import` 或调用。位置判定逻辑已有 `_format_coin_section`/wrapper/`main()` 三处实现。

**规则**：审计时检查每个函数是否有调用方（`grep -rn 'def func\|func(' *.py`），无调用方 = 死代码。

### 5. 并行委派3路审计模式

对于 22 脚本/10K+ 行的项目，单线审计无法在合理时间内覆盖。本会话采用 3 路并行 `delegate_task` 审计，每轮耗时 ~120-220s。分组策略：
- 子代理1: 核心分析脚本 (analysis_template, _social_publish, publish_social)
- 子代理2: 复盘核验脚本 (process_reviews, verify_social_post, inject_lessons, _shared)
- 子代理3: 数据摄入脚本 (regime_detector, jin10_fallback, monitor, massive, trade_journal)

**收敛性**：第 1 轮 ~27 个 Bug，第 7 轮 0 个。收敛速度快（7 轮解决全部问题），证明并行审计有效。

## 不应修复的项（已知局限）

| 项目 | 原因 |
|------|------|
| `ts_to_bj` 在 `_shared` 和 `monitor_and_sync` 重复 | 功能等价，合并风险 > 收益 |
| `_retry`/`fetch_fear_greed` 跨文件重复 | 各自独立维护，统一导入会引入耦合 |
| ADX 非标准实现（独立DI/ADX平滑序列） | 历史兼容，改动影响所有复盘结论 |
| resonance 依赖 emoji+汉字 字符串匹配 | 改格式成本高，暂时安全 |
| `unique = unique[-5:]` 截断模式 | 6+ 模式极少见，截断影响可忽略 |
| `except: pass` 5 处残留 | 均为合法回退（锁清理/浮点转换/时间戳解析） |
