# V062309 架构参考

## 新模块

| 模块 | 文件 | 用途 |
|------|------|------|
| 缠论引擎 | `chanlun.py` | 分型→笔→中枢→背驰→买卖点 |
| SL/TP引擎 | `sltp_engine.py` | 三层解耦：Signal→Quality→Execution |
| 回测脚本 | `backtest_signals.py` | 四种开仓方案回测对比 |
| 回测脚本 | `backtest_sltp.py` | 五种SL/TP方案回测对比 |

## 四层信号架构

```
L0  威科夫: Spring+SOS(confidence≥50) → 试多
             UTAD+price<VAH(confidence≥50) → 试空
L0.5 缠论: 底背驰→一买/二买 → 试多
             顶背驰→一卖/二卖 → 试空
L1  道氏:  1D上升+4H偏多 → 试多
             1D下降+4H偏空 → 试空
L2  共振:  RSI_4H(>55/$1 MACD_h(>0/+1) %b(>70/+1,<30/-1)
             score≥2→偏强 ≤-2→偏弱 其他→分歧
L3  兜底:  near_bottom→试多
```

## SL/TP 引擎关键参数

- SL buffer: ATR×0.3
- TP时间门控: TP2≤120天, TP3≤180天
- 信号门控: TP距>4×ATR需L0/L1触发
- Trade Space: ≥1.5×ATR
- RR分档: <1.0→0, 1.0-1.3→0.6%, 1.3-1.8→1.4%, ≥1.8→2%
- Quality adjustment: tp1+!L1 → RR×0.7

## 回测结论

开仓方案对比(BTC+ETH 1H逐根, 2.5月, SL/TP统一D_ATR20):
| 方案 | 利润因子 |
|------|---------|
| 0_当前 | 1.08 |
| 1_降门槛 | 1.13 |
| 2_加指标 | 1.08 |
| 4_趋势过滤 | **1.20** |

SL/TP方案对比:
| 方案 | 利润因子 |
|------|---------|
| A_当前(near) | 0.62 |
| B_VP | 1.05 |
| C_ATR15 | 1.05 |
| D_ATR20 | **1.08** |

## 已知Bug模式

1. min(0,val)吞零 → 用列表推导 `min(v for v in [a,b] if v>0)`
2. or短路吞零(RSI/FG=0) → 用 `is not None` 检查
3. wyckoff_data先读后写 → 提前wyckoff_detect调用
4. signal_level假阳性 → 验证完整条件非关键词存在
5. wyckoff_detect ZeroDivision → `if avg_vol>0 else 0`
6. 大段patch escape-drift → 拆分为10-15行分段
7. 备份时点 → 改动前备份，回滚前确认范围
8. 多文件未同步 → 信号层跨3文件，逐文件确认
