# 实盘开仓流程：social_posts.json → place_live_orders.py

> 2026-06-21 — 从纯分析结论直接开实盘仓的标准操作流程
> ⚠️ 本文是限价单路径。**市价单优先路径**见 [`live-trading-workflow.md`](live-trading-workflow.md)（含 SL/TP algo 订单 + 交易日志）
> 更新：新增市价单直连 API 方法（`place_live_orders.py` 仅支持限价单）

## 背景

`place_live_orders.py` 从 `social_posts.json` 读取最新一条动态的 `btc_direction`/`eth_direction` 字符串来解析入场区间、SL、TP，然后通过 OKX API 挂限价单。

当用户要求按纯分析结论直接开仓（不经过完整社交发布流程），标准做法：

## 步骤

### 1. 写入 social_posts.json

`btc_direction` 格式要求（`parse_direction()` 的 regex）：

```
偏多 入场XXXXX-YYYYY SL XXXXX TP XXXXX RR 1:X.X
```

- **入场必须是区间**（`入场64250-64260`），不是单点。`parse_direction()` 用 `r'入场([\d,]+)-([\d,]+)'` 解析
- SL/TP 用 `r'SL\s*([\d,.]+)'` / `r'TP\s*([\d,.]+)'` 解析
- 无千分位逗号

示例（Python）：
```python
new_post = {
    'id': 18,
    'time': '2026-06-21 13:25 BJ',
    'btc_price': 64255.0,
    'eth_price': 1734.0,
    'btc_direction': '偏多 入场64250-64260 SL 63221 TP 66790 RR 1:2.5',
    'eth_direction': '观望 空仓等风',
    'fg': 23,
    'regime': '横盘震荡',
    'text': '开仓理由简述'
}
posts.append(new_post)
```

### 2. 检查现有持仓/挂单

```bash
cd /root/.hermes/trade_review
python3 place_live_orders.py --view
```

### 3. 执行挂单（限价单）

```bash
python3 place_live_orders.py
```

脚本内部做的事：
1. 读 `social_posts.json` 最新一条
2. 跳过观望/偏空的 `btc_direction` / `eth_direction`
3. 从 OKX API 获取 USDT 余额
4. 跳过已有挂单的币种
5. 设 20x 全仓杠杆
6. 挂入场限价单（入场区间的下限 `entry_min`）
7. **SL/TP 不自动挂**——需等入场成交后手动挂

### 4. 成交后挂 SL/TP

脚本输出会提示：`⚠️ TP/SL conditional orders must be placed AFTER limit fills.`

需等入场单成交后，通过 OKX 界面或 API 手动挂止损止盈。

---

## 市价单（place_live_orders.py 不支持，需直接调 API）

`place_live_orders.py` **只支持限价单**，没有市价单函数。如需立刻成交：

### 步骤

```python
import sys; sys.path.insert(0, '.')
from place_live_orders import api_call

# 1. 先取消已有挂单
orders = api_call('GET', '/api/v5/trade/orders-pending?instId=BTC-USDT-SWAP')
if orders.get('data'):
    for o in orders['data']:
        api_call('POST', '/api/v5/trade/cancel-order', 
                 {'instId': 'BTC-USDT-SWAP', 'ordId': o['ordId']})

# 2. 市价买入（1张，20x 全仓）
result = api_call('POST', '/api/v5/trade/order', {
    'instId': 'BTC-USDT-SWAP',
    'tdMode': 'cross',
    'side': 'buy',
    'ordType': 'market',
    'sz': '1',
    'posSide': 'long'
})
```

### ⚠️ 关键陷阱：`api_call` body 参数

`api_call(method, path, body)` 的 `body` 参数**必须是 Python dict**，不能是 JSON 字符串。函数内部会自动 `json.dumps(body)`。

```python
# ✅ 正确
api_call('POST', path, {'instId': 'BTC-USDT-SWAP', 'sz': '1'})

# ❌ 错误
api_call('POST', path, '{"instId": "BTC-USDT-SWAP", "sz": "1"}')
```

传字符串会导致 OKX 返回 `code=50002 msg=Incorrect json data format`（double-serialized → `"\"{...}\""` 非法）。

---

## 注意事项

- `place_live_orders.py` 只会做多（`parse_direction()` 过滤掉 `偏空/做空/看空`）
- 杠杆固定 20x 全仓
- 风险规则 2%（`RISK_PCT = 0.02`），但余额太少时最低 1 张合约（可能远超 2%）
- BTC-USDT-SWAP 合约面值 0.01 BTC，最小开仓 1 张（OKX 交易所规则）
- 配置文件：`/root/.hermes/trade_review/okx_live_config.json`（`demo: false` = 实盘）

## 复用 api_call 查询实盘状态

`place_live_orders.py` 的 `api_call()` 封装了完整签名逻辑，可直接复用查询账户：

```python
import sys; sys.path.insert(0, '/root/.hermes/trade_review')
from place_live_orders import api_call

# 余额
bal = api_call('GET', '/api/v5/account/balance')
# 持仓
pos = api_call('GET', '/api/v5/account/positions?instType=SWAP')
# 挂单
orders = api_call('GET', '/api/v5/trade/orders-pending?instType=SWAP')
```

> 📖 **OKX API 签名陷阱**：自建签名时必须从 OKX 服务器获取时间戳（`/api/v5/public/time`），本地时间签名会返回 50112 错误。时间戳格式必须为 `YYYY-MM-DDTHH:MM:SS.mmmZ`（毫秒精度 + Z 后缀）。签名需 base64 编码而非 hex。详见 [`references/okx-live-account-query.md`](references/okx-live-account-query.md)。
