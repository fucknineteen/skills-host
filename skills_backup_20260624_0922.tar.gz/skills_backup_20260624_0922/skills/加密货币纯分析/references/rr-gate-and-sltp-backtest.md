# RR门禁 + SL/TP方案回测结论

> 2026-06-23

## RR门禁

方向判定(偏多/偏空)后计算RR。RR<1.0自动降级为`观望（RR过低1:{rr}，不开仓）`。

位置：`analysis_template.py` `_format_coin_section` + JSON writer + `_social_publish.py` wrapper（3处同步）。

## SL/TP 方向感知选价

`lows_near`升序/`highs_near`降序。原`[0]`取最远价位，改为`[-1]`取最近。

## 5种方案回测（B/ETH，2.5月，112信号）

| 方案 | SL来源 | 胜率 | 评|
|------|--------|------|----|
| A_当前 | 支阻±ATR×0.5 | 16% | SL太远 |
| B_VP | VAL/VAH | **22%** | 🏆最佳 |
| C_ATR15 | entry±1.5×ATR | 6% | 亏>盈 |
| D_ATR20 | entry±2×ATR | 2% | TP太远 |

**结论**：B_VP胜率最高，建议后续切。

---

## 双文件同步陷阱

`inject_lessons.py`和`gen_charts.py`存在于`/root/.hermes/scripts/`和`/root/.hermes/trade_review/`两处。cron脚本运行前者，直接运行用后者。修复时需同步两处。

修复方式：在scripts/版本开头加`sys.path.insert(0, '/root/.hermes/trade_review')`。
