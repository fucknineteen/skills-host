# 跨文件字段映射：analyses.json vs social_analyses.json

> 最后更新：2026-06-20
> 用途：开发者和 LLM 在编写跨文件消费代码时参考，避免字段名不匹配导致静默跳过。

## 背景

2026-06-20 双文件分离后，`analyses.json`（flat_old，纯分析）和 `social_analyses.json`（full_obj，社交发布）采用不同的内部命名约定。当 `verify_social_post.py` 和 `process_reviews.py` 同时消费两个文件时，字段名差异容易导致静默校验跳过。

---

## 字段对照表

### 价格/Ticker

| 用途 | analyses.json | social_analyses.json |
|------|--------------|---------------------|
| 现价 | `ticker_price` (float) | `ticker.last` (string) |
| 完整 ticker | `ticker_full` | `ticker` |

### K线数据

| 用途 | analyses.json | social_analyses.json |
|------|--------------|---------------------|
| 每TF指标表 | `kline_table.{TF}.{close/rsi/macd_h/adx/pct_b/shape/trend}` | `indicators.{TF}.{last_close/rsi/macd_h/adx/bb.pct_b/label/trend}` |
| 收盘价 | `kline_table.1H.close` | `indicators.1H.last_close` |
| RSI | `kline_table.4H.rsi` | `indicators.4H.rsi` 或 `rsi_4h` |
| MACD | `kline_table.4H.macd_h` | `indicators.4H.macd_h` 或 `macd_h_4h` |
| ADX | `kline_table.1H.adx` | `indicators.1H.adx` |
| %b | `kline_table.1H.pct_b` | `indicators.1H.bb.pct_b` 或 `pct_b` |
| K线形态 | `kline_table.1H.shape` | `indicators.1H.label` |
| 道氏 | `kline_table.1H.trend` | `indicators.1H.trend` |
| 收盘状态 | `close_status` | `close_status` ✅ 一致 |

### 支撑/阻力

| 用途 | analyses.json | social_analyses.json |
|------|--------------|---------------------|
| 支撑位列表 | `support` (float list) | `levels_4h.lows` (float list) |
| 阻力位列表 | `resistance` (float list) | `levels_4h.highs` (float list) |
| 最近支撑 | `near_support` | `levels_4h.lows[:2]` |
| 最近阻力 | `near_resistance` | `levels_4h.highs[:2]` |

### 形态/威科夫

| 用途 | analyses.json | social_analyses.json |
|------|--------------|---------------------|
| K线形态时间 | `kline_pattern_times.{Spring/LPS1/...}` | `kline_patterns` (list, 不同格式) |
| 威科夫 | `wyckoff_data` ✅ | `wyckoff_data` ✅ |
| VP数据 | `session_vp` ✅ (2026-06-20 统一) | `session_vp` ✅ |

### 仓位

| 用途 | analyses.json | social_analyses.json |
|------|--------------|---------------------|
| 方向 | `position` | `position` ✅ |
| 止损 | `sl_val` | `sl_val` ✅ |
| 止盈 | `tp_val` | `tp_val` ✅ |
| 盈亏比 | `rr_str` | `rr_str` ✅ |
| 入场价 | `entry_price` | `entry_price` ✅ |

### 宏观/消息

| 用途 | analyses.json | social_analyses.json | ⚠️ 数据源陷阱 |
|------|--------------|---------------------|--------------|
| 宏观 | `macro_external` ✅ | `macro_external` ✅ | ⚠️ `social_analyses.json` 的 `macro_external` 始终为 `{}`！实际数据在 `.regime_cache.json` 的 `dimensions.macro_external`。根因：`_social_publish.py` wrapper 从缓存顶层读取但数据嵌套在 `dimensions` 下。**核验/消费 social_analyses.json 的宏观字段时必须回退读 `.regime_cache.json`。** |
| 财经日历 | `calendar_events` | `calendar_events` ✅ | |
| 快讯 | `flash_news` | `flash_news` ✅ | |
| 订单流 | `order_flow` | N/A (social 无独立 order_flow) | ⚠️ `social_analyses.json` 的 `funding_rate_pct` 在顶层为 `null`。费率在 `order_flow.funding_rate_pct`（仅 analyses.json）或 `.regime_cache.json`。`verify_social_post.py` 读 `rec.get('funding_rate_pct')` 永远返回 None → 费率核验静默跳过。 |
| 底部信号 | `near_bottom` + `bottom_note` ✅ | `near_bottom` + `bottom_note` ✅ (2026-06-22 已补) | ⚠️ 修复前 `publish_social.py` 不写入这两个字段 → `process_reviews.py` 读 full_obj 格式的复盘永远找不到 near_bottom → Spring/威科夫检测失效。 |
| coin 字段 | `"BTC"` (裸币名) | `"BTC"` (裸币名，2026-06-22 已统一) | ⚠️ 修复前 social_analyses.json 存 `"BTCUSDT"` → `process_reviews.py` 合并时将同币种视为两条不同记录。 |

---

## 已知消费者影响

| 消费者 | 读取文件 | 受影响字段 | 状态 |
|--------|---------|-----------|------|
| `verify_social_post.py` | social_analyses.json | 已适配 `indicators`/`levels_4h`/`kline_patterns` | ✅ 2026-06-21 第三轮审计修复 |
| `gen_charts.py` Style 4 | social_analyses.json (优先) + analyses.json (回退) | `kline_table` vs `indicators`、`funding_rate_pct` 位置 | ✅ 2026-06-21 修复（双格式兼容） |
| `process_reviews.py` | 双文件合并 | `find_analysis()` 合并后 coin 字段统一 'BTCUSDT' | ✅ 正常 |
| `_format_coin_section` | 内存 dict (analysis flow) | `session_vp` | ✅ 正常 |
| `generate_social_draft` | 内存 dict (social flow) | `session_vp` | ✅ 正常 |

---

## 修复原则

1. **消费者优先判断数据来源**：读取前检查 `coin` 后缀或 `indicators` 是否存在来区分格式
2. **统一键名**：跨文件同名数据的键名应一致（如 `session_vp` 已统一）
3. **回退路径**：缺失字段应有合理的回退读取逻辑，不应静默跳过

## 双格式兼容编码模式（🆕 2026-06-21，来自 gen_charts.py 修复经验）

### 模式 1：顶层键名兼容

```python
# social_analyses.json 用 indicators，analyses.json 用 kline_table
kt = r.get('indicators') or r.get('kline_table', {})
```

### 模式 2：嵌套字段路径兼容

```python
# social_analyses.json: funding_rate_pct 在顶层
# analyses.json: funding_rate_pct 嵌套在 order_flow 内
fr = r.get('funding_rate_pct')
if fr is None:
    fr = r.get('order_flow', {}).get('funding_rate_pct', 0)
```

### 模式 3：JSON 加载先行（避免作用域错误）

```python
# ❌ 错误：先使用 records，后定义 records → UnboundLocalError
for r in records:  # 此时 records 未定义
    ...

# ... 后面才加载 ...
records = json.load(f)

# ✅ 正确：先加载 JSON，再遍历
records = []
if os.path.exists(json_path):
    try:
        with open(json_path) as f:
            records = json.load(f)
    except Exception:
        pass
for r in records:
    ...
```

### 常见坑

| 坑 | 表现 | 修复 |
|----|------|------|
| 缺少 `import json` | `NameError` 被 `except Exception: pass` 吞掉，所有 JSON 数据静默退化到默认值 | 检查 imports 列表 |
| `r.get('key', default)` 当 key 存在但值为 None | `.get('key', 0)` 仍返回 `None`（key 存在） | 用 `val = r.get('key'); if val is None: val = fallback` |
| EMA 数据不足 | 慢速 EMA(75) 需要 ≥75 根蜡烛，fetch 60 根 → 全 NaN | 增大 fetch limit 至 `max(span) + signal + margin` |
