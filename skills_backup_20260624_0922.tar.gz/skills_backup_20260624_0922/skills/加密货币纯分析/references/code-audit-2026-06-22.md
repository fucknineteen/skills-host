# 代码审计 2026-06-22 — 全量 Bug 清单

> 审计范围: 22 个 Python 脚本  
> 共计发现: ~170 个逻辑问题  
> 审计方法: delegate_task 并行委托 9 个 subagent

## P0 致命 Bug（必崩 / 数据完全错误）

| # | 文件 | 行号 | 简述 |
|---|------|------|------|
| 1 | `regime_detector.py` | L343 | `_get_recent_real_fg()` 从错误路径 `a['analysis']['macro']['fear_greed']` 读取 FG → 真实 FG 永不混合 |
| 2 | `regime_detector.py` | L1079 | `_scan_history()` 传入时间正序数据给期待最新优先的 `_extract_window_features()` → 历史类比全错 |
| 3 | `regime_detector.py` | L1785 | 蜡烛形态检测传最新优先数据，TA-Lib 期待时间正序 → D13 全错 |
| 4 | `analysis_template.py` | `_pos_quick()` | 缺 V 反保护 → `position='观望'` 但 SL/TP 按做空算 |
| 5 | `publish_social.py` | L168 | `--fg` 传入 `composite_score`(浮点) → `save_social_post.py` `int("3.5")` 崩溃 |
| 6 | `verify_social_post.py` | L182 | VP 键名大小写 — JSON 用 `poc` 代码读 `POC` → 核验完全失效 |
| 7 | `verify_social_post.py` | L176 | 指标值全文子串匹配 — RSI=46 在价格 "63460" 中误匹配 |
| 8 | `verify_social_post.py` | L220 | 威科夫阶段搜索关键词 '威科夫' 不存在于文案 |
| 9 | `process_reviews.py` | L395 | 3根K线时 SOS 检测 `max([])` → ValueError 崩溃 |
| 10 | `process_reviews.py` | L86 | regime=None 时教训只进内存 → `lessons.json` 重建时丢失 |
| 11 | `monitor_and_sync.py` | L462 | 主循环硬编码缺 `"1W"` → 1W 永不同步 |

## P1 高优（数据一致性 / 崩溃）

| # | 文件 | 简述 |
|---|------|------|
| 12 | `_social_publish.py` wrapper | 缺 `near_bottom→偏多` 独立分支 — `_format_coin_section` 有，wrapper 无 |
| 13 | `_social_publish.py` wrapper | 缺 `(rsi_1d>65 and macd_h_4h<-50)→偏空` 条件 |
| 14 | `_social_publish.py` L224 | `extract_direction()` 缺 V 反保护 → 存档方向与文案 position 矛盾 |
| 15 | `_social_publish.py` L215 | `macro_external` 始终为 `{}` — 读错层级 |
| 16 | `analysis_template.py` L1775 | main() SL/TP 用硬编码系数(×1.01) 非 ATR |
| 17 | `analysis_template.py` L729 | 趋势 bullish-only override — 缺对称 bearish 覆写 |
| 18 | `analysis_template.py` L806 | X1 检测覆写 near_bottom=False（与 V 反含义矛盾） |
| 19 | `analysis_template.py` L2066 | `risk` 字段名错误 → `risks` |
| 20 | `publish_social.py` L237 | `has_saved_analyses` 在文件写入前赋值 → 失败后核验用过期数据 |
| 21 | `publish_social.py` L224 | ticker=None 传入 `_base_analyze` → AttributeError |
| 22-29 | 合集 | 5个step不捕获TimeoutExpired / _load_analyses取最旧 / 宏观核验永不触发 / 1H指标死代码 / near_bottom字段缺失 / lessons_warnings当key_events / find_analysis损坏时间戳优先 / jin10缺逗号字符串拼接 |

## P2 中等（逻辑缺陷 / 死代码）

- `analysis_template.py`: COIN_LESSONS 全死代码 + 7段旧格式提取死代码 + LPS覆盖bug + entry用4H收盘价 + trend_3d存trend_1d
- `_social_publish.py`: 标题硬编码"极度恐惧" + 💬尾句regime矛盾 + SL/TP用levels_4h vs _format_coin_section用near_support
- `verify_social_post.py`: 正则不容忍空格 + %b永远触发"未找到" + `.*?`跨行污染
- `process_reviews.py`: 6h事件只保留最后一条 + str(None)→"已完成" + verdict缺(flat,up/down) + 72h缺多头教训
- `jin10_fallback.py`: 7处 except:pass + naive vs aware datetime比较TypeError被吞 + 空快讯缓存永不更新
- `regime_detector.py`: FRED Key硬编码 + 权重注释≠代码
- `monitor_and_sync.py`: 缺口末端盲区 + 非连续缺口误导 + 300根限制外误报 + ts_to_bj输出UTC

## P3 低优（边界 / 类型 / 代码异味）

~60 个。主要包括: flash_items None→TypeError / 共享list引用非shallow copy / `btc_pf` int() vs `eth_pf` :.0f不一致 / SIGKILL锁残留 / sqlite3.connect无异常 / RSI falsy guard / walrus operator需3.8+

## 跨文件一致性 7 类

| 问题 | 涉及文件数 | 严重度 |
|------|:---:|:---:|
| **仓位判定 4 地不同** — `_format_coin_section`/wrapper/`_pos_quick`/`extract_direction` 条件各异 | 4 | 🔴 |
| **V 反保护 2/4 缺失** — `_pos_quick` 和 `extract_direction` 无 8根4H反弹检测 | 4 | 🔴 |
| **SL/TP 三套算法** — ATR/硬编码/levels_4h 三处数值不一致 | 3 | 🟠 |
| **near_bottom 写入漂移** — analyses.json 写 / social从不写 / 复盘永远读不到 | 3 | 🟠 |
| **macro_external 层级错位** — regime_detector写嵌套 / wrapper读顶层 → 永远{} | 4 | 🟠 |
| **费率三源不一致** — social_analyses/null / 文案用regime缓存 / 核验读JSON顶层 | 3 | 🟡 |
| **coin格式分裂** — "BTC" vs "BTCUSDT" → merge可能误判 | 3 | 🟡 |

## 审计方法改进

本审计使用 `delegate_task` 并行委托模式（9 个 subagent，3 批次），详解见 `文件安全守则` skill 的 `references/parallel-delegation-audit.md`。

## 🔄 第二轮审计（修复后验证 — 2026-06-22）

第一轮全量修复后执行第二轮全量审计，发现 **25 个残留/新引入 Bug**：

### 第二轮 P1（严重残留）

| # | 文件 | 简述 |
|---|------|------|
| R1 | `_social_publish.py` wrapper | near_bottom+偏弱共振场景：wrapper 输出 `观望（保护）` 但 `_format_coin_section` 输出 `试多` — 方向相反（因 L2 仅检查 `position_raw=='观望（等确认）'` 而非所有场景） |
| R2 | `_shared.py` L71-79 | `max_rally` 永远为 0 — `running_max` 先更新再算 rally → 计算顺序错误 → 单边下跌分类失效 |
| R3 | `process_reviews.py` L350 | flat 方向 + 大波动 → `direction_detail` 为空 → 维度解释缺失 |
| R4 | `verify_social_post.py` L58 | naive datetime 与 BJT-aware 相减 → TypeError 被静默吞掉 |
| R5 | `regime_detector.py` L1829 | TA-Lib 形态检测用 `result[-2]` 跳过最新蜡烛 → 索引偏移 |

### 第二轮 P2/P3

| # | 文件 | 简述 |
|---|------|------|
| R6 | `publish_social.py` | social_analyses.json SL/TP 用 `levels_4h` 但 generate_social_draft 用 `near_support` → 两处数值不一致 |
| R7 | `publish_social.py` | `ticker['last']='?'` 时 `float('?')` → ValueError 导致整批记录丢失 |
| R8 | `_social_publish.py` | extract_direction V反检测用 4H 收盘价但 wrapper 用 ticker 实时价 → 信号不同步 |
| R9-R17 | 合集 | analysis_template 重复调用 calc_position / dead session_vp 参数 / regime路径硬编码 / 子串匹配脆弱 / process_reviews required_keys矛盾 / RSI隐式布尔 / near_bottom与spring互斥 / archive时区假设 / 6h路径未输出 / verify .1f死代码 / monitor timestamps语义 / 极端默认值 / jin10 token重复 / 分页session复用 / regime过渡回退偏多头 / ETH/BTC base else无区分 / inject ID去重对复盘教训无效 |

### 第二轮修复原则

1. **wrapper 判定逻辑完全重写** — 改为 `if/elif` 链与 `_format_coin_section`/`_pos_quick` 完全对齐
2. **SL/TP 数据源统一到 `near_support`** — publish_social.py 和 generate_social_draft 同源
3. **`float('?')` 防护** — 显式检查 `'?'` + `try/except`
4. **`max_rally` 计算顺序修复** — 先算 rally 再更新 running_max
5. **flat 方向 fallback** — 添加 else 分支补全 direction_detail
6. **datetime 时区标准化** — `fromisoformat` 后显式附加 BJT
7. **TA-Lib 索引用 `result[-1]`** — 最新蜡烛而非倒数第二
