# 架构地图 2026-06-21

## 核心脚本
analysis_template.py → analyses.json
_social_publish.py → social_analyses.json (wrapper)
publish_social.py → 7步流水线 (调用 _social_publish)
verify_social_post.py → 核验 social_analyses.json
scripts/review_last_post.py → 复盘上条 social_posts.json
scripts/save_social_post.py → 保存 social_posts.json
scripts/gen_charts.py → 配图 (读 okx_klines.db + social_analyses.json)
process_reviews.py → 三层复盘 (读 analyses.json + social_analyses.json)
inject_lessons.py → 教训注入 (.lesson_context.txt)
monitor_and_sync.py → K线同步 (OKX API → okx_klines.db)
regime_detector.py → 行情检测 (regime_index.json)
jin10_fallback.py → 金十数据源 (data/jin10_*.json)
place_live_orders.py → 实盘挂单 + api_call() 认证接口（供复用查询余额/持仓/挂单）

## 数据流向
OKX API → monitor_and_sync → okx_klines.db
analysis_template → analyses.json → process_reviews
_social_publish → social_analyses.json → publish_social + verify + gen_charts + process_reviews
save_social_post → social_posts.json → review_last_post
process_reviews → reviews.json + lessons.json → inject_lessons → .lesson_context.txt

## 孤立文件
review_path_enhancer.py, scripts/verify_workflow.py, price_path_report.py

## 实盘交易（非孤立）
place_live_orders.py — 从 social_posts.json 读取方向+入场+SL/TP，通过 OKX API 挂限价单。提供 api_call() 通用认证接口（供其他脚本复用查询余额/持仓/挂单）。详见 references/live-trading-workflow.md + live-trading-via-social-posts.md。

## 2026-06-21 修正
auto_push_github.sh 路径拆分：根目录 vs scripts/ 子目录