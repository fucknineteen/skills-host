# 实盘开仓全流程：分析 → 市价单 → SL/TP → 交易日志

> 2026-06-21 — 从纯分析结论到完整开仓+追踪的标准操作流程
> 更新：市价单优先、分步挂 SL/TP、交易日志系统

## 原则

1. **市价单优先**：限价单可能挂不上，用户要求直接市价成交
2. **分两步操作**：先开市价单，成交后再挂 SL/TP（OKX 不支持市价单同时附带条件单）
3. **交易日志追踪**：每笔开仓写入 `trade_journal.json`，平仓后计算实际盈亏比

---

## 步骤一：写入 social_posts.json（供 place_live_orders.py 读取）

`btc_direction` 格式（`parse_direction()` regex）：
```
偏多 入场XXXXX-YYYYY SL XXXXX TP XXXXX RR 1:X.X
```
- ⚠️ 入场必须是区间（如 `入场64250-64260`）
- 无千分位逗号

## 步骤二：检查持仓/挂单

```bash
cd /root/.hermes/trade_review
python3 place_live_orders.py --view --instId BTC-USDT-SWAP
```

## 步骤三：市价开仓（直连 OKX API）

`place_live_orders.py` 只支持限价单，市价单需直接调 `api_call`：

```python
import sys; sys.path.insert(0, '.')
from place_live_orders import api_call

# 市价买入（1张，20x 全仓）
result = api_call('POST', '/api/v5/trade/order', {
    'instId': 'BTC-USDT-SWAP',
    'tdMode': 'cross',
    'side': 'buy',
    'ordType': 'market',
    'sz': '1',
    'posSide': 'long'
})
```

⚠️ **关键陷阱**：`api_call(method, path, body)` 的 `body` 参数**必须是 Python dict**（非 JSON 字符串），函数内部自动 `json.dumps`。

## 步骤四：挂止损止盈

成交后分两次调用 `order-algo` API（OKX 不允许市价单直接附带条件单）：

```python
# 止损（价格触发 → 市价平仓）
api_call('POST', '/api/v5/trade/order-algo', {
    'instId': 'BTC-USDT-SWAP',
    'tdMode': 'cross',
    'side': 'sell',
    'ordType': 'conditional',
    'sz': '1',
    'posSide': 'long',
    'slTriggerPx': '63221',
    'slOrdPx': '-1',      # -1 = 市价
})

# 止盈
api_call('POST', '/api/v5/trade/order-algo', {
    'instId': 'BTC-USDT-SWAP',
    'tdMode': 'cross',
    'side': 'sell',
    'ordType': 'conditional',
    'sz': '1',
    'posSide': 'long',
    'tpTriggerPx': '66790',
    'tpOrdPx': '-1',
})
```

## 步骤五：写入交易日志

```bash
# 手工编辑 trade_journal.json 追加新记录，或写脚本
```

日志结构：
```json
{
  "id": 1,
  "coin": "BTC-USDT-SWAP",
  "direction": "long",
  "entry_price": 64268,
  "stop_loss": 63221,
  "take_profit": 66790,
  "contracts": 1,
  "leverage": 20,
  "rr_planned": 2.41,
  "balance_usdt": 73.84,
  "status": "open"
}
```

## 步骤六：平仓时更新日志

```bash
python3 trade_journal.py --close <trade_id> <close_price> [tp|sl|manual]
```

---
## 配置文件

- OKX 实盘密钥：`/root/.hermes/trade_review/okx_live_config.json`（`demo: false`）
- 交易日志：`/root/.hermes/trade_review/trade_journal.json`
- 日志工具：`/root/.hermes/trade_review/trade_journal.py`

## 查看统计

```bash
python3 trade_journal.py --stats
```

输出：胜率、平均盈利/亏损、累计盈亏、计划RR vs 实际RR、盈亏比（盈$/亏$）

---

## 复用 api_call 查询实盘状态

`place_live_orders.py` 的 `api_call(method, path, body)` 是封装好的 OKX 认证接口，可从任意脚本复用查询账户状态：

```python
import sys; sys.path.insert(0, '/root/.hermes/trade_review')
from place_live_orders import api_call

# 账户余额
bal = api_call('GET', '/api/v5/account/balance')

# 持仓
pos = api_call('GET', '/api/v5/account/positions?instType=SWAP')

# 挂单
orders = api_call('GET', '/api/v5/trade/orders-pending?instType=SWAP')
```

⚠️ `api_call` 内部会调用 `load_config()` 读取 `okx_live_config.json`，无需手动处理签名。

---

## 重要约束

- BTC-USDT-SWAP 合约面值 0.01 BTC，最小开仓 1 张（OKX 交易所规则）
- `calc_position_size` 的 `max(1, ...)` 强制度最小 1 张——余额少时无法缩放
- 杠杆固定 20x 全仓，风险规则 2%（`RISK_PCT = 0.02`）
- `place_live_orders.py` 只做多（`parse_direction()` 过滤 `偏空/做空/看空`）
