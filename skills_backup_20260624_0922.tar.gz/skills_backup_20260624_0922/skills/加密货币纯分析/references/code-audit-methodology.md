# 五轮全量审计方法论 & 全量 Bug 清单

> 审计会话: 2026-06-22（单次会话完成五轮）  
> 审计范围: 13 个核心 Python 脚本  
> 共计发现: ~343 个逻辑问题（P0 致命 39 个）  
> 语法验证: 全部 13/13 通过

---

## 审计方法论（已验证有效）

### 核心原则

1. **全量不跳跃** — 读取 ALL 文件 ALL 行，不「只审计几个关键位置」。用户明确要求。
2. **多轮递进** — 首轮架构层面，后续逐步深入底层计算/图表/辅助脚本。
3. **并行委托** — 用 `delegate_task` 分批并行，每批 3 个 subagent 各自读文件。
4. **严重程度排序** — P0(致命)→P1(重要)→P2(中等)→P3(轻微)，逐级修复。
5. **每次修复后验证** — `py_compile` 语法检查 + 跨文件一致性比对。
6. **修复=全修不选** — 用户说「修复」= 全部逐项修复，不给选择题。

### 每轮流程

```
① delegate_task x3（按文件分组并行审计）
② 汇总发现 → 按 P0/P1/P2/P3 分类
③ delegate_task xN（按文件分组并行修复）
④ py_compile 全量语法验证
⑤ 进入下一轮
```

### 常见 Bug 分类模式

| 类别 | 典型示例 | 检测方法 |
|------|---------|---------|
| **数据顺序反转** | EMA/RSI 传入数据方向与函数期望相反 | 检查函数签名注释 vs 调用方 SQL `ORDER BY` |
| **falsy 值陷阱** | `if val` 跳过 0/空字符串 → 合法值被漏 | 改为 `is not None` |
| **字段名漂移** | JSON 键名不一致（如 `poc` vs `POC`） | Cross-file grep 验证 |
| **跨文件逻辑不一致** | 同一判定在 3+ 处用不同条件 | 逐行对照各实现 |
| **时区混淆** | naive vs aware datetime 比较被 `except:pass` 吞 | 搜 `fromisoformat` + `timedelta` |
| **缺省值语义** | `dict.get(key, 0)` 不区分 key 缺失 vs 值为 0 | 两步检查: `key in d and d[key] is not None` |
| **崩溃防护缺失** | `fetchone()[0]` 无 None 守卫 | 搜 `fetchone()[` 确认 |
| **SL/TP 多源分歧** | ATR/硬编码/levels_4h 三处算出三个值 | 搜 `sl_val`/`tp_val` 全局 |

---

## 第一~二轮审计（架构层面 — ~195 Bug）

已有记录，见本文档前半部分（修复前版本）。

## 第三轮审计（底层计算全链路错误 — 53 Bug）

**本轮的独特价值**：深入到信号检测/图表生成/宏观评分的底层计算函数，发现这些函数的数据顺序假设与调用方不一致。

### P0 致命（11 个）

| # | 文件 | 位置 | 问题 |
|---|------|------|------|
| 1 | `monitor_and_sync.py` | `ema()` L323 | **EMA 数据顺序反向** — 函数假定 `data[0]`=最旧，但 DB 查询 `ORDER BY ts DESC`（最新在前）|
| 2 | `monitor_and_sync.py` | `calc_rsi()` L343 | **RSI 差分方向反向** — `diff = closes[i] - closes[i-1]`，最新在前时 = 旧-新 |
| 3 | `monitor_and_sync.py` | L471 | **零实体蜡烛误判锤子线** — `body=0` 时 `lower_shadow >= 0` 恒真 |
| 4 | `regime_detector.py` | `calc_macd_full()` L727 | **EMA 双重反转** — 函数逆序为旧→新，但 `ema()` 期待新→旧 |
| 5 | `analysis_template.py` | `calc_adx()` L311 | **ADX 完全算错** — 取最旧 `period` 根 + 无 Wilder 平滑 + 返回原始 DX 非 ADX |
| 6 | `analysis_template.py` | `session_vp` L1005 | **`next()` 无 default** → `StopIteration` 崩溃 |
| 7 | `process_reviews.py` | `detect_direction` L145 | **隐式返回 None** — flat 方向不返回值 |
| 8 | `process_reviews.py` | `do_72h_review` L623 | **1根K线时 IndexError** — `part3[-1][4]` 坠空列表 |
| 9 | `verify_social_post.py` | L162 | **`round(None)` TypeError** — `.get('macd_h',0)` 在键存在但值为 None 时仍返回 None |
| 10 | `review_last_post.py` | L114 | **做空结论完全反转** — `'做多错误' if '做空' in direction` 三元短路 |
| 11 | `analysis_template.py` | L1528 | **`\\n` 是字面反斜杠+n** 非换行符 → stdout 挤成一行 |

### P1 重要（12 个）

| # | 文件 | 问题 |
|---|------|------|
| 12 | `analysis_template.py` L43 | `NOW_MS` import 时固定 → `is_closed` 判断过期 |
| 13 | `analysis_template.py` L768 | trend 覆写为 '偏空' 但下游只匹配 '下降' |
| 14 | `analysis_template.py` L1829 | main() SL/TP 用 `levels_4h` vs `_format_coin_section` 用 `near_support` |
| 15 | `analysis_template.py`+`_social_publish` | `get_regime_result()` 两处重复定义 |
| 16 | `monitor_and_sync.py` L596 | 多空信号均 ≥3 只报多头 |
| 17 | `regime_detector.py` L689 | recovery 可超 100% |
| 18 | `regime_detector.py` L2058 | 多头投票 6 维 vs 空头 5 维不对称 |
| 19 | `jin10_fallback.py` L98 | SSE 拼接缺换行符（4 处） |
| 20 | `jin10_fallback.py` L293 | `try_jin10_calendar` 和 `_jin10_mcp_session` 完全重复 |
| 21 | `gen_charts.py` L62 | MACD `slow=75` vs 标准 26 |
| 22 | `inject_lessons.py` L101 | 无 `id` 字段教训无法去重 |
| 23 | `_social_publish.py` L267 | `cal_sl_tp` 对观望方向误算做多 SL/TP |

### P2/P3（~30 个）

省略详细，主要包括: `get_rows` limit 未用 / `COIN_ALIASES` 重复键 / label 过滤遗漏 / `calc_position` 爆仓不清理旧值 / `BINANCE_API_KEY` 硬编码 / 3 个未使用 imports / `FG=0` truthiness 陷阱 / `CRYPTO_KEYWORDS` 死代码 / DB 连接未关闭 / 10Y 变化误标 bp

---

## 第四轮审计（修复后验证 — 43 Bug，含 2 个 R3 新引入）

### P0 致命（9 个）

| # | 文件 | 问题 | 来源 |
|---|------|------|:--:|
| 1 | `publish_social.py` L329 | **`calc_sl_tp()` 参数 6→5 不匹配** — R3 删 `session_vp` 参但调用处未同步 | **NEW** |
| 2-4 | `_social_publish.py` L184 + `analysis_template` L1388/L2092 | **`float('?')` ValueError** — ticker fallback 返回 `'?'` | 残留 |
| 5 | `process_reviews.py` L700 | **analysis=None → AttributeError** | 残留 |
| 6 | `regime_detector.py` L1824 | **CDLHARAMI 字典键覆盖** — bull-harami 被 bear-harami 覆盖 | 残留 |
| 7 | `verify_social_post.py` L94 | **仅验 BTC/ETH，SOL/DOGE 跳过** | 残留 |
| 8-9 | `gen_charts.py` 多处 | **`fetchone()[0]` 无 None 防护** + `daily[0]` 空列表崩溃 | 残留 |

### P1 重要（16 个）

关键: 事件窗口方向反了(`-12..+48` 应为 `-48..+12`) / SOS-HHHL 用值排序非时序 / kline_patterns 硬编码 ÷9 / verify 警告格式 `'⚠️'` vs `'  ⚠️'` / jin10 SSE `l[6:]` 应为 `l[5:]`（多截 1 字符）

---

## 第五轮审计（修复后验证 — 52 Bug，含 1 个 R4 新引入）

### P0 致命（7 个）

| # | 文件 | 问题 | 来源 |
|---|------|------|:--:|
| 1 | `monitor_and_sync.py` L112-132 | **`tf`→`timeframe` NameError** — R4 save_candles 质量告警用了未定义变量 | **NEW** |
| 2 | `analysis_template.py` L1672 | **`_pos_quick` 缺 `float('?')` 保护** — R4 修其他 2 处漏此 | 残留 |
| 3-4 | `gen_charts.py` L183/L483 | **`fg_label.upper()` 崩溃** — JSON null 返回 None → `.upper()` | 残留 |
| 5 | `publish_social.py` L101 | 超长文案直接作 CLI 参数 → ARG_MAX 风险 | 残留 |
| 6 | `_social_publish.py` L351 | `fg_val=None` → 标题显示 `FG=None未知` | 残留 |
| 7 | `process_reviews.py` L97 | old lessons 缺 `type` 字段被静默丢弃 | 残留 |

### P1 重要（16 个）

关键: `near_support` 数据流断裂（wrapper 不传播）/ 大阳大阴被表格过滤 / SL/TP `int()` vs `float`/`round` 三处不一致 / 熊市反弹极性错误 / `fg_label=None` `.upper()` 崩溃

---

## 🎯 审计结论

五轮递进审计的 Bug 密度趋势：
- R1: 170（架构缺陷）→ R2: 25（残留）→ R3: 53（底层计算错）→ **R4: 43（含 2 个新引入）**→ **R5: 52（含 1 个新引入）**

**关键教训**：
1. **每轮修复都可能引入新 Bug**（参数变更不同步最为常见）
2. **底层计算函数（ema/rsi/adx/macd）的数据顺序假设必须与调用方一致**
3. **多文件同一逻辑的独立实现是 Bug 温床**（position 判定 4 处、SL/TP 3 种算法）
4. **文件格式分裂（`BTC` vs `BTCUSDT`、flat_old vs full_obj）导致数据链路断裂**
5. **`dict.get(key, default)` 不防护 `key` 存在但值为 `None`**
6. **`except Exception: pass` 或仅有 `try` 无 `except` 是调试黑洞**
