# analysis_template.py 未修复 Bug 清单 — 2026-06-22 深度审计

> 审计范围：`/root/.hermes/trade_review/analysis_template.py`（2178 行）
> 审计重点：position/direction 逻辑、共振评分、V 反保护、SL/TP、MACD 4H/1H、快讯、死代码、错误字段名
> 状态：**✅ 全部已修复 (2026-06-22 R4 完成)** — P0×1 ✅ P1×3 ✅ P2×12 ✅ P3×6 ✅
>
> ✅ 已确认修复（2026-06-22 第三轮审计验证）：
> - **Bug #1** `_pos_quick` V反保护 — L1679-1698 已实现 near_bottom + 8根4H反弹检测
> - **Bug #2** main() SL/TP ATR缓冲 — L1930-1946 已改用 `atr_4h * 0.5`
> - **Bug #4** trend bearish override — L817-819 已有 `elif macd_h < 0...trend_dir='偏空'`
> - **Bug #5-#11** 死代码 — L1925-1958 已在 R3 中删除
> - **Bug #12** risk→risks — L2066 始终用 `risks`，不存在 `risk` 字段
> - **Bug #15** LPS索引 — L2093-2100 已改为递增计数器

---

## 🔴 P0 — 严重（可导致错误交易决策）

### 1. `_pos_quick()` 缺少 V 反保护
**位置**：L1535-1555
**影响**：`main()` L1773 `position = a.get('position') or _pos_quick(a)` 用 `_pos_quick` 判定 SL/TP 方向。当 `resonance='🔴偏弱'` + `near_bottom=True` 时，`_pos_quick` 无条件返回 `'偏空'`，导致 SL/TP 按做空计算。虽然后面 L2008-2040 的 record builder 有 V 反保护会覆盖 position 字符串，但 `sl_val`/`tp_val`/`rr_str` 已在 L1775-1796 按做空算出并写入 JSON。JSON 中出现 `position='观望（V反保护）'` 但 SL/TP 是空头方向的矛盾。

**复现**：ETH resonance='🔴偏弱' + near_bottom=True → `_pos_quick` 返回 '偏空' → `'空' in '偏空'` 为 True → SL=highs[0]*1.01, TP=lows[0]（空头 SL/TP）

**修复方向**：`_pos_quick` 末尾加 V 反保护（near_bottom 检测 + 8 根 4H 反弹检测），与 `_format_coin_section` 和 main() record builder 对齐。

---

## 🟠 P1 — 高（数据一致性问题）

### 2. main() record builder SL/TP 用硬编码系数而非 ATR
**位置**：L1775-1796 vs L1316-1321
**问题**：`_format_coin_section` 的 SL 用 ATR 缓冲（`sl = highs_near[0] + atr_4h * 0.5`），但 main() record builder 写入 `analyses.json` 的 SL/TP 仍用硬编码系数：
- 做空 SL：`int(highs[0] * 1.01)` — 硬编码 1%
- 做多 SL：`int(lows[0] * 0.99)` (BTC) / `int(lows[0] * 0.985)` (others) — 硬编码 1-1.5%

**后果**：stdout 显示基于 ATR 的 SL，但 JSON 存储基于硬编码系数的 SL。两者值不同。social 流（_social_publish.py）已在 P1b 修复中改用 ATR，main() 尚未同步。

### 3. `_pos_quick` 与 main() record builder 默认值不一致
**位置**：L1555 vs L2026
**问题**：`_pos_quick` 兜底返回 `'观望'`，main() record builder 返回 `'观望（等确认）'`。如果下游代码做精确字符串比较会分歧。

### 4. 趋势方向 bullish-only override（缺 bearish 对称）
**位置**：L729-731
**问题**：道氏判定为"盘整"时，仅在 `MACD_h>0` + 价格接近 5 根高点时覆写为"偏多"，**没有 MACD_h<0 + 价格接近低点的对称覆写**。导致"盘整+MACD空+价近低"仍报"盘整"。

---

## 🟡 P2 — 中（逻辑缺陷 / 死代码 / 字段错误）

### 5. COIN_LESSONS 字典完全未被引用
**位置**：L64-88
**问题**：定义了 B1-B4/E1-E4/S1-S3 等 10 条复盘教训约束，全脚本无任何代码引用。§7.5 已标注"仅文档，代码未执行"。

### 6. 死代码：VP 旧格式提取（`vp_POC`/`vp_VAH` 等）
**位置**：L1925-1932
**问题**：检查 `a` 中的 `vp_POC`/`vp_VAH`/`vp_VAL`/`vp_bar` 键——`analyze_single_coin()` 不设置这些键（只用 `session_vp`）。每次被 L1961-1971 的正确提取完全覆盖。

### 7. 死代码：order_flow spread/offset 提取
**位置**：L1934-1939
**问题**：`a.get('order_spread')` / `a.get('order_offset')` —— `analyze_single_coin()` 不设置这些键。永假。

### 8. 死代码：wyckoff 旧格式字段提取
**位置**：L1943-1946
**问题**：遍历 `['phase','spring','range','SC','recovery','structure']` 拼 `wyckoff_` 前缀——永不命中。被 L1974 `wyckoff_detect(a)` 覆盖。

### 9. 死代码：kline_pattern 旧格式字段提取
**位置**：L1949-1953
**问题**：遍历 `['Spring','LPS1','LPS2','LPS3']` 拼 `kline_pattern_` 前缀——永不命中。被 L1985 `detect_kline_patterns(a)` 覆盖。

### 10. 死代码：data_vol / macro_alert 提取
**位置**：L1957-1958、L2001
**问题**：`'data_vol' in a` 和 `a.get('macro_alert', '')`——两个字段均不被 `analyze_single_coin()` 返回。

### 11. 死代码：f_rate_val 计算后从未使用
**位置**：L1764-1765
**问题**：从 funding dict 提取 `f_rate_val`，但后续从未写入 record 或任何输出。

### 12. 错误字段名：`risk` 应为 `risks`
**位置**：L2066
**问题**：`a.get('risk', '')` —— `analyze_single_coin()` 返回的键是 `risks`（复数）。**永远返回空字符串**。

### 13. `entry_price` 使用 4H 收盘价而非 ticker 现价
**位置**：L1755
**问题**：`entry_price = ind_4h.get('last_close', 0) or ind_1h.get('last_close', 0)` —— 用已收盘蜡烛价，可能落后现价数小时。stdout 仓位逻辑（L1315）明确用 `ticker.last`。`reviews.json` 的 `entry_price` 与 `analyses.json` 的 SL/TP 基于不同入场价。

### 14. `trend_3d` 字段命名误导
**位置**：L2060
**问题**：`"trend_3d": trend_1d` —— 存储的实际上是日线道氏方向（1D 趋势），不是 3 日趋势。命名与内容不符。

### 15. LPS 模式索引 bug：多 LPS 时只保留最后一个
**位置**：L1992-1994
**问题**：`count = len([p for p in ... if p[2] == 'LPS'])` 取 LPS 总数作键。有 2 个 LPS 时两次迭代都写 `LPS2`，第二个覆盖第一个。应使用递增计数器。
```python
# 当前代码：
count = len([p for p in kline_patterns_result['patterns'] if p[2] == 'LPS'])
kline_pattern_times[f'LPS{count}'] = f'@{time_str}'
# → 2 个 LPS 都写入 LPS2，后者覆盖前者

# 正确做法：
lps_idx = 1
for pat in patterns:
    if ptype == 'LPS':
        kline_pattern_times[f'LPS{lps_idx}'] = f'@{time_str}'
        lps_idx += 1
```

### 16. kline_patterns 重复计算
**位置**：L860（analyze_single_coin 内）+ L1985（main 重算）
**问题**：`detect_kline_patterns()` 已在 `analyze_single_coin()` 返回时计算，main() 在 L1985 完全重算——不读 `a['kline_patterns']`。

---

## 🟢 P3 — 低（边界情况 / 类型问题）

### 17. `data_selection` 默认类型错误
**位置**：L1859
**问题**：`data_selection = a.get('data_selection', {})` —— `analyze_single_coin()` 返回的是字符串（L859），默认值 `{}` 类型不匹配。应为 `''`。

### 18. `_pos_quick` RSI falsy guard
**位置**：L1541-L1542、L2013
**问题**：`rsi_1d = (...get('rsi') or 50)` —— RSI=0 时 `0 or 50` 返回 50。RSI 理论不会为 0，但模式不严谨。

### 19. `_all_flash_news` 共享 list 引用问题
**位置**：L1738、L1922
**问题**：`flash_news = _all_flash_news` —— 所有币种的 record 共享同一 list 引用。如果 downstream 代码修改了 `flash_news`，会影响其他币种的 record。应做 shallow copy。

### 20. flash_items 为 None 时潜在 TypeError
**位置**：L1738
**问题**：`for item in flash_items[:10]` —— 如果 `_fetch_flash()` 返回 `(None, ...)`，切片 `None[:10]` 触发 TypeError。外层有 try/except 兜底但不如显式判空。

### 21. X1 触发时 near_bottom 被覆盖的矛盾
**位置**：L806-811
**问题**：X1 检测 "RSI<20+FG<15 → V反概率极高"，这本身是 near_bottom 的最强信号，但代码将 `near_bottom = False`（覆盖为 False）。注释说是"复盘教训强制观望"，但与 near_bottom 的本意（底部区域）矛盾。实际上是硬编码执行了 B4 规则（但 B4 存在于死代码 COIN_LESSONS 中）。

### 22. `recommendation` 字段存 resonance 值
**位置**：L2065
**问题**：`"recommendation": a.get('resonance', '')` —— 命名是"建议"但存的是共振评级。下游消费者可能误解。

---

## 修复优先级

| 优先级 | Bug # | 影响 |
|:--:|:--:|------|
| 🔴 立即 | #1 | 做空信号 V 反时 JSON SL/TP 方向错误 |
| 🟠 近期 | #2 | 同一分析的 SL/TP 在 stdout 和 JSON 中值不同 |
| 🟠 近期 | #4 | 盘整+MACD空 未被识别为偏空 |
| 🟡 计划 | #12 | `risk` 字段永远为空（字段名错误） |
| 🟡 计划 | #15 | 多 LPS 模式只保留最后一个 |
| 🟡 计划 | #5-#11 | 死代码清理 |
