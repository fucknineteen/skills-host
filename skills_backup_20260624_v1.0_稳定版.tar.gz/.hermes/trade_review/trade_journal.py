#!/usr/bin/env python3
"""交易日志工具 — 平仓/统计/盈亏比计算"""

import json, sys, os
from datetime import datetime
from _shared import BJT
import tempfile
JOURNAL_FILE = os.path.join(os.path.dirname(__file__), 'trade_journal.json')

# Explicit contract face values (prevent substring match like WBTC matching BTC)
CONTRACT_VALUES = {
    "BTC": 0.01, "ETH": 0.1, "SOL": 1.0,
    "BNB": 1.0, "XRP": 10.0, "DOGE": 1000.0,
    "LTC": 1.0, "AVAX": 1.0, "DOT": 1.0,
    "LINK": 1.0, "MATIC": 1.0, "UNI": 1.0,
    "ADA": 100.0, "FIL": 1.0, "ATOM": 1.0,
    "TRX": 10.0, "LAB": 1.0, "ONDO": 1.0,
    "HOME": 1.0, "ZEC": 0.1, "ALLO": 1.0,
}

def load():
    if not os.path.exists(JOURNAL_FILE):
        return {'version': 1, 'trades': []}
    try:
        with open(JOURNAL_FILE) as f:
            return json.load(f)
    except (json.JSONDecodeError, IOError) as e:
        print(f"⚠️ trade_journal.json 损坏: {e}，返回空账本", file=sys.stderr)
        return {'version': 1, 'trades': []}

def save(data):
    data['updated_bj'] = datetime.now(BJT).isoformat()
    try:
        with tempfile.NamedTemporaryFile(mode='w', suffix='.json',
                                         dir=os.path.dirname(JOURNAL_FILE),
                                         delete=False, encoding='utf-8') as f:
            json.dump(data, f, indent=2, ensure_ascii=False)
            tmp_path = f.name
        os.replace(tmp_path, JOURNAL_FILE)
    except Exception as e:
        print(f"⚠️ trade_journal.json 写入失败: {e}", file=sys.stderr)

def close_trade(trade_id, close_price, reason='manual'):
    """平仓并计算实际盈亏比。reason: 'tp', 'sl', 'manual'"""
    data = load()
    now_str = datetime.now(BJT).isoformat()
    
    for t in data['trades']:
        if t['id'] == trade_id and t['status'] == 'open':
            entry = t['entry_price']
            direction = t['direction']
            contracts = t['contracts']
            ct_val = CONTRACT_VALUES.get(t['coin'])
            if ct_val is None:
                print(f'  ⚠️ 警告: {t["coin"]} 不在 CONTRACT_VALUES 中，默认使用 0.1 — PnL 可能错误', file=sys.stderr)
                ct_val = 0.1
            balance = t.get('balance_usdt', 0.0)
            
            # PnL
            if direction == 'long':
                pnl = (close_price - entry) * contracts * ct_val
            else:
                pnl = (entry - close_price) * contracts * ct_val
            
            # 实际盈亏比
            sl_risk = abs(entry - t.get('stop_loss', 0))
            if direction == 'long':
                actual_rr = (close_price - entry) / sl_risk if sl_risk > 0 else 0
            else:
                actual_rr = (entry - close_price) / sl_risk if sl_risk > 0 else 0
            
            t['status'] = 'closed'
            t['close_time_bj'] = now_str
            t['close_price'] = close_price
            t['pnl_usdt'] = round(pnl, 2)
            t['pnl_pct'] = round(pnl / balance * 100, 1) if balance > 0 else 0
            t['rr_actual'] = round(actual_rr, 2)
            t['close_reason'] = reason
            
            save(data)
            
            planned_rr = float(t.get('rr_planned', 0))
            rr_str = '实际RR: 1:{:.1f}'.format(actual_rr) if actual_rr > 0 else '负RR: {:.1f} (亏损)'.format(actual_rr)
            print('#{} 已平仓:'.format(trade_id))
            print('  方向: {} | 入场: {:.0f} -> 平仓: {:.0f}'.format(direction, entry, close_price))
            print('  盈亏: ${:+.2f} ({:+.1f}%)'.format(pnl, t['pnl_pct']))
            print('  计划RR: 1:{:.1f} | {}'.format(planned_rr, rr_str))
            print('  原因: {}'.format(reason))
            return t
    
    print('未找到持仓中的 #{}'.format(trade_id))
    return None

def stats():
    data = load()
    trades = data.get('trades', [])
    closed = [t for t in trades if t.get('status') == 'closed']
    wins = [t for t in closed if t.get('pnl_usdt', 0) > 0]
    losses = [t for t in closed if t.get('pnl_usdt', 0) <= 0]
    
    print()
    print('=== 交易统计 ===')
    print('总交易: {} | 已平仓: {} | 持仓中: {}'.format(
        len(trades), len(closed), len(trades) - len(closed)))
    
    if closed:
        print('胜: {} | 负: {} | 勝率: {:.1f}%'.format(
            len(wins), len(losses), len(wins)/len(closed)*100))
        
        avg_win = sum(t.get('pnl_usdt', 0) for t in wins) / len(wins) if wins else 0
        avg_loss = sum(t.get('pnl_usdt', 0) for t in losses) / len(losses) if losses else 0
        total_pnl = sum(t.get('pnl_usdt', 0) for t in closed)
        
        print('平均盈利: ${:+.2f} | 平均亏损: ${:+.2f}'.format(avg_win, avg_loss))
        print('累计盈亏: ${:+.2f}'.format(total_pnl))
        
        # 盈亏比
        planned_rrs = [t.get('rr_planned', 0) for t in closed]
        actual_rrs = [t.get('rr_actual', 0) for t in closed if 'rr_actual' in t]
        avg_planned = sum(planned_rrs) / len(planned_rrs) if planned_rrs else 0
        avg_actual = sum(actual_rrs) / len(actual_rrs) if actual_rrs else 0
        
        print('平均计划RR: 1:{:.1f}'.format(avg_planned))
        if actual_rrs:
            if avg_actual > 0:
                print('平均实际RR: 1:{:.1f}'.format(avg_actual))
            else:
                print('平均实际RR: {:.1f}'.format(avg_actual))
        
        # 盈亏比(盈利金额/亏损金额)
        if avg_win > 0 and avg_loss < 0:
            expectancy = abs(avg_win / avg_loss)
            print('盈亏比(盈$/亏$): {:.1f}:1'.format(expectancy))
    
    # 持仓中
    open_trades = [t for t in trades if t.get('status') == 'open']
    if open_trades:
        print()
        print('当前持仓:')
        for t in open_trades:
            tid = t['id']
            coin = t['coin']
            direction = t['direction']
            entry_p = t.get('entry_price', 0) or 0
            sl_p = t.get('stop_loss', 0) or 0
            tp_p = t.get('take_profit', 0) or 0
            rr_p = t.get('rr_planned', 0) or 0
            print('  #{} {} {} entry={:.0f} SL={:.0f} TP={:.0f} RR(计划)={:.1f}'.format(
                tid, coin, direction, entry_p, sl_p, tp_p, rr_p))
    
    # 最近平仓
    if closed:
        print()
        print('最近平仓:')
        for t in closed[-5:]:
            tid = t['id']
            coin = t['coin']
            direction = t['direction']
            pnl = t.get('pnl_usdt', 0) or 0
            pnl_pct = t.get('pnl_pct', 0) or 0
            rr_act = t.get('rr_actual')
            reason = t.get('close_reason', '?')
            if rr_act is not None:
                rr_str = '实际RR={:.1f}'.format(rr_act) if rr_act > 0 else '实际RR={:.1f}(止损)'.format(rr_act)
            else:
                rr_str = 'RR=N/A'
            print('  #{} {} {} ${:+.2f} ({:+.1f}%) {} [{}]'.format(
                tid, coin, direction, pnl, pnl_pct, rr_str, reason))

if __name__ == '__main__':
    if '--stats' in sys.argv:
        stats()
    elif '--close' in sys.argv:
        if len(sys.argv) >= 3:
            tid = int(sys.argv[2])
            price = float(sys.argv[3]) if len(sys.argv) >= 4 else 0
            if price <= 0:
                print("错误: close_price 必须 > 0", file=sys.stderr)
                sys.exit(1)
            reason = sys.argv[4] if len(sys.argv) >= 5 else 'manual'
            close_trade(tid, price, reason)
        else:
            print('Usage: python3 trade_journal.py --close <trade_id> <close_price> [tp|sl|manual]')
    else:
        print('Usage:')
        print('  python3 trade_journal.py --stats')
        print('  python3 trade_journal.py --close <trade_id> <close_price> [tp|sl|manual]')
